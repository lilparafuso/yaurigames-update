/* ============================================================
   shared.js — camada compartilhada do YauriGames
   Perfil, Yauri Coins, loja, missões, conquistas, baú, passe,
   ranking, streak, easter eggs e SALVAMENTO NO PENDRIVE.
   ============================================================ */
(function () {
  const CHAVE = 'yauri_perfil_v3';
  const PREFIXOS = /^(yauri_perfil|snake|tetris|flappy|dino_|pdq_|slimetd_|xadrez_|cidade_|termo_|sudoku_|truco_|poker_|corrida_|cruz_|caca_|cq_|yauri_upd)/;

  /* ---------- 1) Restaura o progresso gravado no pendrive (dados/progresso.js) ---------- */
  function lerTs() { try { return +localStorage.getItem('yauri_sync_ts') || 0; } catch (e) { return 0; } }
  function restaurar(obj) {
    try {
      for (const k in obj.dados) localStorage.setItem(k, obj.dados[k]);
      localStorage.setItem('yauri_sync_ts', String(obj.ts));
      return true;
    } catch (e) { return false; }
  }
  try { if (window.YAURI_SAVE && window.YAURI_SAVE.ts > lerTs()) restaurar(window.YAURI_SAVE); } catch (e) { /* ok */ }

  /* ---------- Loja: cosméticos ---------- */
  // preco -1 = item RARO (só sai de baú, passe ou conquista)
  const ITENS = [
    { id: 'tema_padrao', cat: 'tema', nome: 'Verde Clássico', preco: 0, d: { bg: '#10151c', ac: '#7dffb0' } },
    { id: 'tema_neon', cat: 'tema', nome: 'Neon', preco: 150, d: { bg: '#0b0b1a', ac: '#00ffd5' } },
    { id: 'tema_sol', cat: 'tema', nome: 'Pôr do Sol', preco: 200, d: { bg: '#2a0f1f', ac: '#ff8a3d' } },
    { id: 'tema_matrix', cat: 'tema', nome: 'Matrix', preco: 250, d: { bg: '#021a05', ac: '#00ff41' } },
    { id: 'tema_ouro', cat: 'tema', nome: 'Dourado Yauri', preco: 500, d: { bg: '#2b2108', ac: '#ffd700' } },
    { id: 'tema_galaxia', cat: 'tema', nome: '✨ Galáxia', preco: -1, d: { bg: '#0d0221', ac: '#c77dff' } },
    { id: 'tema_vapor', cat: 'tema', nome: '✨ Vaporwave', preco: -1, d: { bg: '#1a0b2e', ac: '#ff71ce' } },
    { id: 'cursor_padrao', cat: 'cursor', nome: 'Normal', preco: 0, d: { e: '' } },
    { id: 'cursor_espada', cat: 'cursor', nome: 'Espada ⚔️', preco: 80, d: { e: '⚔️' } },
    { id: 'cursor_foguete', cat: 'cursor', nome: 'Foguete 🚀', preco: 80, d: { e: '🚀' } },
    { id: 'cursor_estrela', cat: 'cursor', nome: 'Estrela ⭐', preco: 60, d: { e: '⭐' } },
    { id: 'cursor_gato', cat: 'cursor', nome: 'Gato 🐱', preco: 100, d: { e: '🐱' } },
    { id: 'cursor_coroa', cat: 'cursor', nome: 'Coroa 👑', preco: 300, d: { e: '👑' } },
    { id: 'cursor_dragao', cat: 'cursor', nome: '✨ Dragão 🐉', preco: -1, d: { e: '🐉' } },
    { id: 'cursor_diamante', cat: 'cursor', nome: '✨ Diamante 💎', preco: -1, d: { e: '💎' } },
    { id: 'snake_padrao', cat: 'snake', nome: 'Verde', preco: 0, d: { c: '#00c000', h: '#66ff66' } },
    { id: 'snake_neon', cat: 'snake', nome: 'Neon', preco: 100, d: { c: '#00ffd5', h: '#ffffff' } },
    { id: 'snake_arco', cat: 'snake', nome: 'Arco-íris', preco: 200, d: { rainbow: 1, h: '#ffffff' } },
    { id: 'snake_ouro', cat: 'snake', nome: 'Dourada', preco: 250, d: { c: '#ffd700', h: '#fff3b0' } },
    { id: 'snake_yauri', cat: 'snake', nome: 'Yauri 😎', preco: 400, d: { c: '#ff5c5c', h: '#ffffff', emoji: '😎' } },
    { id: 'snake_lava', cat: 'snake', nome: '✨ Lava 🔥', preco: -1, d: { c: '#ff4500', h: '#ffd000', emoji: '🔥' } },
    { id: 'pong_padrao', cat: 'pong', nome: 'Clássico', preco: 0, d: { bola: '#ffffff', a: '#ffffff', b: '#ffffff' } },
    { id: 'pong_neon', cat: 'pong', nome: 'Neon', preco: 100, d: { bola: '#00ffff', a: '#ff00ff', b: '#00ff88' } },
    { id: 'pong_fogo', cat: 'pong', nome: 'Fogo e Gelo', preco: 150, d: { bola: '#ffd000', a: '#ff5a00', b: '#4db8ff' } },
    { id: 'pong_yauri', cat: 'pong', nome: 'Pão de Queijo', preco: 300, d: { bola: '#ffd700', a: '#00e5ff', b: '#ff5c8a', emoji: '🧀' } },
    { id: 'pong_galaxia', cat: 'pong', nome: '✨ Galáxia', preco: -1, d: { bola: '#e0aaff', a: '#9d4edd', b: '#5a189a', emoji: '🌍' } },
    { id: 'tetris_padrao', cat: 'tetris', nome: 'Clássico', preco: 0, d: { cores: ['#00f0f0', '#f0f000', '#a000f0', '#00f000', '#f00000', '#0000f0', '#f0a000'] } },
    { id: 'tetris_pastel', cat: 'tetris', nome: 'Pastel', preco: 100, d: { cores: ['#a8e6ff', '#fff1a8', '#e0b3ff', '#b6f5c0', '#ffb3b3', '#b3c6ff', '#ffd1a8'] } },
    { id: 'tetris_neon', cat: 'tetris', nome: 'Neon', preco: 150, d: { cores: ['#00ffff', '#ffff00', '#ff00ff', '#39ff14', '#ff073a', '#4d4dff', '#ff9900'] } },
    { id: 'tetris_mono', cat: 'tetris', nome: 'Monocromático', preco: 80, d: { cores: ['#fff', '#ddd', '#bbb', '#999', '#eee', '#ccc', '#aaa'] } },
    { id: 'tetris_arco', cat: 'tetris', nome: '✨ Arco-íris', preco: -1, d: { cores: ['#ff0000', '#ff7f00', '#ffff00', '#00ff00', '#0000ff', '#4b0082', '#9400d3'] } },
    { id: 'xadrez_roxo', cat: 'xadrez', nome: 'Tabuleiro Roxo', preco: 150, d: { tema: 'roxo' } },
    { id: 'xadrez_ouro', cat: 'xadrez', nome: 'Tabuleiro Dourado', preco: 250, d: { tema: 'dourado' } },
    { id: 'td_padrao', cat: 'td', nome: 'Floresta', preco: 0, d: { chao: null } },
    { id: 'td_neon', cat: 'td', nome: 'Mapa Neon', preco: 200, d: { chao: '#14083a', trilha: '#5b2bd9', borda: '#00ffd5' } },
    { id: 'td_gelo', cat: 'td', nome: 'Mapa Gelo', preco: 200, d: { chao: '#7fa9c9', trilha: '#dff3ff', borda: '#4a7ba0' } },
    { id: 'td_lava', cat: 'td', nome: '✨ Mapa Lava', preco: -1, d: { chao: '#3a0d0d', trilha: '#ff6a00', borda: '#ffd000' } },
    { id: 'cartas_padrao', cat: 'cartas', nome: 'Verso Azul', preco: 0, d: { v1: '#1d4ed8', v2: '#93c5fd', e: '' } },
    { id: 'cartas_vermelho', cat: 'cartas', nome: 'Verso Vermelho', preco: 80, d: { v1: '#b91c1c', v2: '#fca5a5', e: '' } },
    { id: 'cartas_preto', cat: 'cartas', nome: 'Verso Preto e Ouro', preco: 200, d: { v1: '#111', v2: '#ffd700', e: '♠' } },
    { id: 'cartas_yauri', cat: 'cartas', nome: '✨ Verso Yauri', preco: -1, d: { v1: '#2d6a4f', v2: '#ffd700', e: '😎' } },
    { id: 'carro_0', cat: 'carro', nome: '🚗 Carrinho', preco: 0, d: { e: '🚗' } },
    { id: 'carro_1', cat: 'carro', nome: '🏎️ Fórmula', preco: 150, d: { e: '🏎️' } },
    { id: 'carro_2', cat: 'carro', nome: '🚓 Viatura', preco: 120, d: { e: '🚓' } },
    { id: 'carro_3', cat: 'carro', nome: '🛻 Picape', preco: 120, d: { e: '🛻' } },
    { id: 'carro_4', cat: 'carro', nome: '✨ Foguete 🚀', preco: -1, d: { e: '🚀' } },
    { id: 'av_0', cat: 'avatar', nome: '😎', preco: 0, d: { e: '😎' } },
    { id: 'av_1', cat: 'avatar', nome: '🤖', preco: 50, d: { e: '🤖' } },
    { id: 'av_2', cat: 'avatar', nome: '🧀', preco: 60, d: { e: '🧀' } },
    { id: 'av_3', cat: 'avatar', nome: '🦁', preco: 80, d: { e: '🦁' } },
    { id: 'av_4', cat: 'avatar', nome: '🐉', preco: 120, d: { e: '🐉' } },
    { id: 'av_5', cat: 'avatar', nome: '👑', preco: 250, d: { e: '👑' } },
    { id: 'av_6', cat: 'avatar', nome: '✨ 🦄', preco: -1, d: { e: '🦄' } },
    { id: 'av_7', cat: 'avatar', nome: '✨ 👽', preco: -1, d: { e: '👽' } },
    { id: 'av_8', cat: 'avatar', nome: '✨ 🔥', preco: -1, d: { e: '🔥' } },
    { id: 'tit_0', cat: 'titulo', nome: 'Novato', preco: 0, d: {} },
    { id: 'tit_1', cat: 'titulo', nome: 'Nego Malandro', preco: 150, d: {} },
    { id: 'tit_2', cat: 'titulo', nome: 'Malandro Oficializado pelo Guetto', preco: 300, d: {} },
    { id: 'tit_3', cat: 'titulo', nome: 'Senhor Supremo do Universo', preco: 800, d: {} },
    { id: 'tit_4', cat: 'titulo', nome: '✨ Lenda do IFSP', preco: -1, d: {} },
    { id: 'tit_5', cat: 'titulo', nome: '✨ Imortal de Catanduva', preco: -1, d: {} },
    { id: 'tit_6', cat: 'titulo', nome: '✨ Veterano da Temporada', preco: -1, d: {} },
  ];
  const CATS = { tema: '🎨 Tema do menu', cursor: '🖱 Cursor', avatar: '🙂 Avatar', titulo: '🏷 Título', snake: '🐍 Snake', pong: '🏓 Pong', tetris: '🧱 Tetris', xadrez: '♞ YauriChess', td: '🟢 Slime Defense', cartas: '🃏 Cartas (Truco/Poker)', carro: '🏁 Corrida' };
  const PADROES = { tema: 'tema_padrao', cursor: 'cursor_padrao', snake: 'snake_padrao', pong: 'pong_padrao', tetris: 'tetris_padrao', td: 'td_padrao', avatar: 'av_0', titulo: 'tit_0', cartas: 'cartas_padrao', carro: 'carro_0' };
  const RAROS = ITENS.filter(i => i.preco < 0).map(i => i.id);

  /* ---------- Missões diárias / desafio semanal ---------- */
  const POOL = [
    { id: 'snake', t: 'Coma 25 maçãs no Snake', ev: 'snake_comeu', alvo: 25, r: 40 },
    { id: 'tetris', t: 'Limpe 15 linhas no Tetris', ev: 'tetris_linhas', alvo: 15, r: 40 },
    { id: 'td', t: 'Estoure 150 slimes no Slime Defense', ev: 'td_estouros', alvo: 150, r: 50 },
    { id: 'xadrez', t: 'Vença 1 partida de xadrez', ev: 'xadrez_vitoria', alvo: 1, r: 60 },
    { id: 'pao', t: 'Clique 300 vezes no pão de queijo', ev: 'pao_cliques', alvo: 300, r: 35 },
    { id: 'pong', t: 'Marque 10 pontos no Pong', ev: 'pong_pontos', alvo: 10, r: 35 },
    { id: 'flappy', t: 'Faça 10 pontos no Flappy', ev: 'flappy_pontos', alvo: 10, r: 40, max: 1 },
    { id: 'memoria', t: 'Vença o Jogo da Memória', ev: 'memoria_vitoria', alvo: 1, r: 30 },
    { id: 'velha', t: 'Vença no Jogo da Velha', ev: 'velha_vitoria', alvo: 1, r: 30 },
    { id: 'l4', t: 'Vença no Ligue 4', ev: 'ligue4_vitoria', alvo: 1, r: 40 },
    { id: 'minas', t: 'Vença no Campo Minado', ev: 'minas_vitoria', alvo: 1, r: 50 },
    { id: 'breakout', t: 'Quebre 40 blocos no Breakout', ev: 'breakout_blocos', alvo: 40, r: 40 },
    { id: 'invaders', t: 'Derrube 30 invasores', ev: 'invaders_kills', alvo: 30, r: 40 },
    { id: 'dino', t: 'Corra 600m no Dino', ev: 'dino_metros', alvo: 600, r: 40, max: 1 },
    { id: 'surv', t: 'Sobreviva 2 minutos no Sobrevivente', ev: 'surv_tempo', alvo: 120, r: 50, max: 1 },
    { id: 'quiz', t: 'Acerte 8 perguntas do Quiz', ev: 'quiz_acertos', alvo: 8, r: 45 },
    { id: 'tank', t: 'Vença uma rodada de Tanques', ev: 'tanques_vitoria', alvo: 1, r: 30 },
    { id: '2048', t: 'Forme o bloco 512 no 2048', ev: '2048_bloco', alvo: 512, r: 50, max: 1 },
    { id: 'naval', t: 'Vença uma Batalha Naval', ev: 'naval_vitoria', alvo: 1, r: 45 },
    { id: 'termo', t: 'Acerte uma palavra no Termo', ev: 'termo_vitoria', alvo: 1, r: 45 },
    { id: 'sudoku', t: 'Resolva um Sudoku', ev: 'sudoku_vitoria', alvo: 1, r: 55 },
    { id: 'cruz', t: 'Complete as Palavras Cruzadas', ev: 'cruz_vitoria', alvo: 1, r: 55 },
    { id: 'truco', t: 'Vença uma partida de Truco', ev: 'truco_vitoria', alvo: 1, r: 50 },
    { id: 'poker', t: 'Quebre a CPU no Poker', ev: 'poker_vitoria', alvo: 1, r: 40 },
    { id: 'geo', t: 'Acerte 8 de 10 em um quiz de Geografia', ev: 'geo_vitoria', alvo: 1, r: 45 },
    { id: 'cq', t: 'Faça 2500 pontos no Come-Queijo', ev: 'cq_pontos', alvo: 2500, r: 45, max: 1 },
    { id: 'corrida', t: 'Termine uma Corrida em 1º lugar', ev: 'corrida_vitoria', alvo: 1, r: 50 },
  ];
  const FRASES = ['Guilherme Yauri aprova este jogo.', 'Nego malandro oficializado pelo guetto detectado.', 'Carregando a sabedoria do Senhor Supremo do Universo…', 'Dica: o professor não está olhando. Ou está?', 'Yauri Coins: a moeda mais estável do IFSP.', 'Aperte ` (crase) se o professor chegar.', 'Catanduva presente! 🏠', 'Nego frutinha não passa da fase 2.', 'Fazendo o ENEM e jogando Tetris ao mesmo tempo.', 'Sua sequência diária está de olho em você. 🔥', 'Abra o baú diário. Vai que vem raro.'];

  /* ---------- Conquistas (geradas a partir das estatísticas) ---------- */
  const TIERS = [
    ['snake_comeu', '🐍 Maçãs comidas', [100, 1000], 'maçãs'], ['tetris_linhas', '🧱 Linhas de Tetris', [50, 500], 'linhas'],
    ['td_estouros', '🟢 Slimes estourados', [500, 5000], 'slimes'], ['xadrez_vitoria', '♞ Vitórias no xadrez', [1, 10, 50], 'vitórias'],
    ['pao_cliques', '🧀 Cliques no pão', [1000, 20000], 'cliques'], ['pong_pontos', '🏓 Pontos no Pong', [50, 500], 'pontos'],
    ['flappy_pontos', '🐤 Recorde no Flappy', [10, 30], 'pontos'], ['memoria_vitoria', '🃏 Vitórias na Memória', [5, 25], 'vitórias'],
    ['velha_vitoria', '⭕ Vitórias na Velha', [5, 25], 'vitórias'], ['ligue4_vitoria', '🔴 Vitórias no Ligue 4', [5, 25], 'vitórias'],
    ['minas_vitoria', '💣 Campos limpos', [3, 20], 'vitórias'], ['breakout_blocos', '🧨 Blocos quebrados', [200, 2000], 'blocos'],
    ['invaders_kills', '👾 Invasores derrubados', [100, 1000], 'invasores'], ['dino_metros', '🦖 Recorde no Dino', [500, 2000], 'm'],
    ['surv_tempo', '🧟 Sobrevivência (seg)', [180, 600], 's'], ['quiz_acertos', '🎓 Acertos no Quiz', [50, 300], 'acertos'],
    ['tanques_vitoria', '🪖 Vitórias nos Tanques', [5, 25], 'vitórias'], ['2048_bloco', '🔢 Maior bloco no 2048', [1024, 2048], ''],
    ['naval_vitoria', '⚓ Vitórias na Batalha Naval', [3, 15], 'vitórias'], ['termo_vitoria', '🔤 Palavras acertadas no Termo', [1, 10, 50], 'palavras'],
    ['sudoku_vitoria', '🔢 Sudokus resolvidos', [1, 10], 'sudokus'], ['cruz_vitoria', '✏️ Cruzadas completas', [1, 10], 'cruzadas'],
    ['truco_vitoria', '🃏 Vitórias no Truco', [1, 10, 30], 'vitórias'], ['poker_vitoria', '♠️ Mãos ganhas no Poker', [1, 25], 'mãos'],
    ['corrida_vitoria', '🏁 Vitórias na Corrida', [1, 10], 'vitórias'], ['moedas_total', '🪙 Moedas ganhas no total', [1000, 10000, 100000], 'moedas'],
    ['streak', '🔥 Sequência de dias', [3, 7, 30], 'dias'], ['nivel', '⭐ Nível do perfil', [5, 10, 20], ''], ['queijos', '🧀 Queijos escondidos achados', [5, 20], 'queijos'],
  ];
  const SECRETAS = { konami: 'Código secreto', logo7: 'Sala secreta', yauri: 'Modo Yauri', guizin: 'Senhor Supremo', chefe: 'Modo chefe', supremo: 'Derrotou o Senhor Supremo', guizin_bot: 'Venceu o Guizin', naval: 'Almirante do Universo', pdq_premium: 'Pão de Queijo Premium', cid_ifsp: 'IFSP na cidade', cid_estadio: 'Estádio Yauri' };
  const CONQS = [];
  TIERS.forEach(([ev, nome, alvos, un]) => alvos.forEach((a, i) => CONQS.push({ id: 'a_' + ev + '_' + a, ev, nome: nome + ': ' + a + (un ? ' ' + un : ''), alvo: a, r: 20 + i * 30 + Math.min(100, Math.floor(Math.log10(a + 1) * 15)) })));

  /* ---------- Perfil ---------- */
  function novo() { return { nome: 'Guilherme Yauri', xp: 0, moedas: 100, itens: {}, eq: {}, missoes: null, conq: {}, vol: 0.6, mudo: false, v: 3, stats: {}, streak: { ult: '', n: 0 }, bau: '', passe: { mes: '', xp: 0, res: {} }, sem: null, rec: {} }; }
  function ler() {
    try {
      const v = JSON.parse(localStorage.getItem(CHAVE)); if (v && v.v === 3) return Object.assign(novo(), v);
      const o = JSON.parse(localStorage.getItem('yauri_perfil_v2')); if (o) return Object.assign(novo(), o, { v: 3 });
    } catch (e) { /* sem storage */ }
    return novo();
  }
  let P = ler();
  let SYNC_OK = null;
  function salvar() { try { localStorage.setItem(CHAVE, JSON.stringify(P)); } catch (e) { /* ignora */ } atualizarChip(); }
  const diaNum = (d) => Math.floor(new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() / 864e5);
  const hoje = () => { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); };
  const mesAtual = () => { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1); };
  function semanaAtual() { const d = new Date(); const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const dn = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - dn); const a = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return t.getUTCFullYear() + '-S' + Math.ceil(((t - a) / 864e5 + 1) / 7); }
  function semente(s) { let h = 7; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return () => (h = (h * 1664525 + 1013904223) >>> 0) / 4294967296; }
  function gerarMissoes() {
    if (!P.missoes || P.missoes.data !== hoje()) {
      const rnd = semente(hoje()); const ids = POOL.map((_, i) => i); const lista = [];
      for (let k = 0; k < 3; k++) { const i = ids.splice(Math.floor(rnd() * ids.length), 1)[0]; lista.push({ i: POOL[i].id, prog: 0, feito: 0 }); }
      P.missoes = { data: hoje(), lista };
    }
    if (!P.sem || P.sem.id !== semanaAtual()) {
      const rnd = semente(semanaAtual()); const d = POOL[Math.floor(rnd() * POOL.length)];
      P.sem = { id: semanaAtual(), i: d.id, prog: 0, feito: 0 };
    }
    if (P.passe.mes !== mesAtual()) P.passe = { mes: mesAtual(), xp: 0, res: {} };
    salvar();
  }
  const nivel = () => 1 + Math.floor(Math.sqrt(P.xp / 40));
  const item = (id) => ITENS.find(i => i.id === id);
  const tem = (id) => !!(P.itens[id] || (item(id) && item(id).preco === 0));
  const semanal = () => { const d = POOL.find(p => p.id === P.sem.i); return { d, alvo: d.alvo * 6, r: d.r * 6 }; };

  /* ---------- Toast e estilos ---------- */
  function estilo() {
    if (document.getElementById('y-css')) return;
    const s = document.createElement('style'); s.id = 'y-css';
    s.textContent = `
    #y-chip{position:fixed;right:10px;top:10px;z-index:9000;touch-action:none;background:#000c;color:#fff;border:1px solid #ffffff30;border-radius:20px;padding:5px 12px;font:700 13px system-ui,sans-serif;cursor:pointer;display:flex;gap:8px;align-items:center}
    #y-chip:hover{background:#000e;border-color:#ffd700}
    #y-toast{position:fixed;left:50%;top:14px;transform:translateX(-50%);z-index:9500;display:flex;flex-direction:column;gap:6px;align-items:center;pointer-events:none}
    #y-toast div{background:#ffd700;color:#1a1200;padding:8px 16px;border-radius:10px;font:800 14px system-ui,sans-serif;box-shadow:0 4px 14px #0008;animation:yin .3s}
    @keyframes yin{from{transform:translateY(-20px);opacity:0}}
    #y-ov{position:fixed;inset:0;background:#000b;z-index:9800;display:none;align-items:center;justify-content:center;font-family:system-ui,sans-serif;color:#fff}
    #y-ov.on{display:flex}
    #y-box{background:#1b1f27;border-radius:14px;width:min(780px,96vw);height:min(600px,93vh);display:flex;flex-direction:column;overflow:hidden;box-shadow:0 10px 50px #000}
    #y-tabs{display:flex;gap:2px;background:#12151b;padding:6px;overflow-x:auto;flex-shrink:0}
    #y-tabs button{background:transparent;border:0;color:#aab;padding:8px 10px;border-radius:8px;font-weight:700;cursor:pointer;font-size:13px;white-space:nowrap}
    #y-tabs button.on{background:#2a3140;color:#fff}#y-tabs .x{margin-left:auto}
    #y-body{flex:1;overflow-y:auto;padding:14px}
    .y-b{background:#2d6a4f;color:#fff;border:0;padding:6px 12px;border-radius:7px;font-weight:700;cursor:pointer}.y-b:disabled{opacity:.4;cursor:default}.y-b.eq{background:#555}.y-b.go{background:#b8860b}
    .y-it{display:flex;align-items:center;gap:10px;background:#242a36;border-radius:8px;padding:7px 10px;margin:4px 0}.y-it span{flex:1}
    .y-bar{height:10px;background:#12151b;border-radius:6px;overflow:hidden;margin-top:4px}.y-bar div{height:100%;background:#ffd700}
    .y-msn{background:#242a36;border-radius:8px;padding:10px;margin:6px 0}.y-msn.ok{outline:2px solid #4ade80}
    .y-chipc{display:inline-block;background:#242a36;border-radius:20px;padding:4px 10px;margin:3px;font-size:13px}.y-chipc.n{opacity:.35}
    .y-chuva{position:fixed;top:-30px;z-index:9900;color:#ffd700;font:800 18px system-ui;pointer-events:none;text-shadow:0 2px 4px #000;animation:ycai linear forwards;white-space:nowrap}
    @keyframes ycai{to{transform:translateY(110vh) rotate(20deg)}}
    #y-marca{position:fixed;z-index:9000;pointer-events:none;color:#ffffff55;font:800 14px system-ui;animation:yfade 4s forwards}
    @keyframes yfade{0%{opacity:0}20%{opacity:1}100%{opacity:0;transform:translateY(-40px)}}
    #y-chefe{position:fixed;inset:0;background:#fff;color:#222;z-index:99999;display:none;font:15px/1.6 Georgia,serif;overflow:auto}
    #y-chefe .barra{background:#1a73e8;color:#fff;padding:8px 16px;font:14px system-ui}#y-chefe .pg{max-width:760px;margin:20px auto;padding:30px;box-shadow:0 0 6px #0003}
    .y-bau{font-size:90px;text-align:center;cursor:pointer;margin:16px}.y-bau.abre{animation:ybau .6s}
    @keyframes ybau{30%{transform:rotate(-12deg) scale(1.2)}60%{transform:rotate(12deg) scale(1.3)}}
    .y-pg{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:6px}.y-pg div{background:#242a36;border-radius:8px;padding:6px;text-align:center;font-size:12px}.y-pg .ok{outline:2px solid #4ade80}.y-pg .pr{outline:2px solid #ffd700}
    #y-queijo{position:fixed;z-index:8000;font-size:14px;opacity:.18;cursor:pointer;user-select:none}#y-queijo:hover{opacity:1}
    `;
    document.head.appendChild(s);
  }
  function toast(t) {
    estilo(); let c = document.getElementById('y-toast');
    if (!c) { c = document.createElement('div'); c.id = 'y-toast'; document.body.appendChild(c); }
    const d = document.createElement('div'); d.innerHTML = t; c.appendChild(d); while (c.children.length > 3) c.firstChild.remove();
    setTimeout(() => d.remove(), 3500);
  }

  /* ---------- Estatísticas, conquistas, API principal ---------- */
  function checarConquistas() {
    for (const c of CONQS) {
      if (P.conq[c.id]) continue;
      let v = c.ev === 'nivel' ? nivel() : c.ev === 'streak' ? P.streak.n : (P.stats[c.ev] || 0);
      if (v >= c.alvo) { P.conq[c.id] = c.nome; toast('🏆 ' + c.nome); P.moedas += c.r; P.xp += c.r; }
    }
  }
  function ganhar(moedas, xp, motivo) {
    const n0 = nivel(); xp = xp == null ? moedas : xp;
    P.moedas += moedas; P.xp += xp; P.stats.moedas_total = (P.stats.moedas_total || 0) + Math.max(0, moedas);
    if (P.passe.mes === mesAtual()) P.passe.xp += xp;
    checarConquistas(); salvar();
    if (moedas > 0) toast('🪙 +' + moedas + ' Yauri Coins' + (motivo ? ' — ' + motivo : ''));
    if (nivel() > n0) toast('⬆ Nível ' + nivel() + '!');
  }
  function evento(nome, v) {
    gerarMissoes(); v = v == null ? 1 : v; let mudou = false;
    const defE = POOL.find(p => p.ev === nome);
    P.stats[nome] = (defE && defE.max) ? Math.max(P.stats[nome] || 0, v) : (P.stats[nome] || 0) + v;
    for (const m of P.missoes.lista) {
      const def = POOL.find(p => p.id === m.i); if (!def || m.feito || def.ev !== nome) continue;
      m.prog = def.max ? Math.max(m.prog, v) : m.prog + v; mudou = true;
      if (m.prog >= def.alvo) { m.feito = 1; m.prog = def.alvo; salvar(); toast('✅ Missão: ' + def.t); ganhar(def.r, def.r, 'missão'); }
    }
    if (!P.sem.feito) {
      const w = semanal();
      if (w.d.ev === nome) {
        P.sem.prog = w.d.max ? Math.max(P.sem.prog, v) : P.sem.prog + v; mudou = true;
        if (P.sem.prog >= w.alvo) { P.sem.feito = 1; P.sem.prog = w.alvo; salvar(); toast('🏅 Desafio da semana concluído!'); ganhar(w.r, w.r, 'desafio semanal'); darRaro(); }
      }
    }
    checarConquistas(); if (mudou) salvar(); else salvar();
  }
  function conquista(id, nome, coins) {
    if (P.conq[id]) return; P.conq[id] = nome; salvar(); toast('🏆 ' + nome); if (coins) ganhar(coins, coins);
  }
  function recorde(id, nomeJogo, valor, menorMelhor) {
    if (valor == null || isNaN(valor)) return;
    const l = P.rec[id] || (P.rec[id] = { nome: nomeJogo, top: [], menor: !!menorMelhor });
    l.top.push({ n: P.nome, v: valor, d: hoje() });
    l.top.sort((a, b) => menorMelhor ? a.v - b.v : b.v - a.v); l.top = l.top.slice(0, 5); salvar();
  }
  function darRaro() {
    const livres = RAROS.filter(id => !P.itens[id]);
    if (!livres.length) { ganhar(300, 0, 'colecionador!'); return null; }
    const id = livres[Math.floor(Math.random() * livres.length)]; P.itens[id] = 1; salvar();
    toast('✨ ITEM RARO: ' + item(id).nome); chuva('✨ ' + item(id).nome, 2); return id;
  }
  const eq = (cat) => item(P.eq[cat] && tem(P.eq[cat]) ? P.eq[cat] : PADROES[cat]) || null;
  function comprar(id) { const it = item(id); if (!it || it.preco < 0 || tem(id) || P.moedas < it.preco) return false; P.moedas -= it.preco; P.itens[id] = 1; P.eq[it.cat] = id; salvar(); aplicarCosmeticos(); return true; }
  function equipar(id) { const it = item(id); if (!it || !tem(id)) return; P.eq[it.cat] = id; salvar(); aplicarCosmeticos(); }

  /* ---------- Cosméticos globais ---------- */
  function aplicarCosmeticos() {
    estilo();
    const c = eq('cursor');
    let st = document.getElementById('y-cursor');
    if (!st) { st = document.createElement('style'); st.id = 'y-cursor'; document.head.appendChild(st); }
    if (c && c.d.e) {
      const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32'><text y='24' font-size='24'>${c.d.e}</text></svg>`;
      st.textContent = `html,body,canvas,button,a,.card{cursor:url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}") 4 4,auto !important}`;
    } else st.textContent = '';
    if (document.body && document.body.hasAttribute('data-ytema')) {
      const t = eq('tema').d; document.body.style.setProperty('--bg', t.bg); document.body.style.setProperty('--ac', t.ac);
    }
    document.body.classList.toggle('yauri-modo', modoYauri());
  }
  const modoYauri = () => { try { return sessionStorage.getItem('yauri_modo') === '1'; } catch (e) { return false; } };

  /* ---------- Som ---------- */
  let ac = null;
  function beep(f, d, tipo, vol) {
    if (P.mudo) return;
    try {
      if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = tipo || 'square'; o.frequency.value = f; g.gain.value = (vol || 0.08) * P.vol * 2;
      o.connect(g); g.connect(ac.destination); o.start(); g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + (d || 0.1)); o.stop(ac.currentTime + (d || 0.1) + 0.02);
    } catch (e) { /* sem áudio */ }
  }

  /* ---------- 2) Salvamento no pendrive ---------- */
  let dirH = null, ultimoGravado = '', ultimaGravacao = 0, erroSync = '';
  function idb() { return new Promise((res, rej) => { const r = indexedDB.open('yauri_fs', 1); r.onupgradeneeded = () => r.result.createObjectStore('k'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
  async function idbGet(k) { const db = await idb(); return new Promise((res) => { const q = db.transaction('k').objectStore('k').get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); }); }
  async function idbSet(k, v) { const db = await idb(); return new Promise((res) => { const t = db.transaction('k', 'readwrite'); t.objectStore('k').put(v, k); t.oncomplete = () => res(); t.onerror = () => res(); }); }
  function snapshot() {
    const dados = {};
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (PREFIXOS.test(k)) dados[k] = localStorage.getItem(k); } } catch (e) { /* ok */ }
    return dados;
  }
  async function permissao(h, pedir) {
    if (!h || !h.queryPermission) return false;
    try { let p = await h.queryPermission({ mode: 'readwrite' }); if (p === 'granted') return true; if (pedir) { p = await h.requestPermission({ mode: 'readwrite' }); return p === 'granted'; } } catch (e) { /* ok */ }
    return false;
  }
  async function gravar(forcar, pedir) {
    if (!dirH) return false;
    const dados = snapshot(); const chave = JSON.stringify(dados);
    if (!forcar && chave === ultimoGravado) return true;
    if (!(await permissao(dirH, pedir))) { SYNC_OK = false; atualizarChip(); return false; }
    try {
      const pasta = dirH.name === 'dados' ? dirH : await dirH.getDirectoryHandle('dados', { create: true });
      const f = await pasta.getFileHandle('progresso.js', { create: true });
      const w = await f.createWritable(); const ts = Date.now();
      await w.write('/* Progresso do YauriGames — não apague. */\nwindow.YAURI_SAVE=' + JSON.stringify({ ts, dados }) + ';\n'); await w.close();
      try { localStorage.setItem('yauri_sync_ts', String(ts)); } catch (e) { /* ok */ }
      ultimoGravado = chave; ultimaGravacao = ts; SYNC_OK = true; erroSync = ''; atualizarChip(); return true;
    } catch (e) { erroSync = String(e && e.message || e); SYNC_OK = false; atualizarChip(); return false; }
  }
  async function conectarPasta() {
    if (!window.showDirectoryPicker) { toast('Seu navegador não permite. Use Chrome ou Edge, ou o botão Exportar.'); return false; }
    try {
      dirH = await window.showDirectoryPicker({ mode: 'readwrite', id: 'yauripen' }); await idbSet('dir', dirH);
      const ok = await gravar(true, true); toast(ok ? '💾 Pendrive conectado! Progresso salvo.' : '⚠ Não consegui gravar: ' + erroSync); return ok;
    } catch (e) { return false; }
  }
  async function exportar() {
    const ts = Date.now(); const txt = '/* Progresso do YauriGames */\nwindow.YAURI_SAVE=' + JSON.stringify({ ts, dados: snapshot() }) + ';\n';
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'application/javascript' })); a.download = 'progresso.js'; document.body.appendChild(a); a.click(); a.remove();
    try { localStorage.setItem('yauri_sync_ts', String(ts)); } catch (e) { /* ok */ }
    toast('📥 Arquivo progresso.js baixado. Copie para a pasta dados/ do pendrive.');
  }
  function importar(txt) {
    try { const m = txt.slice(txt.indexOf('{'), txt.lastIndexOf('}') + 1); const o = JSON.parse(m); if (!o.dados) throw 0; restaurar(o); P = ler(); salvar(); toast('✅ Progresso importado!'); return true; } catch (e) { toast('Arquivo inválido'); return false; }
  }
  async function iniciarSync() {
    try { dirH = await idbGet('dir'); } catch (e) { dirH = null; }
    if (dirH) {
      const ok = await permissao(dirH, false); SYNC_OK = ok ? true : null; atualizarChip();
      if (!ok) document.addEventListener('pointerdown', async function pedirP() { document.removeEventListener('pointerdown', pedirP); if (await permissao(dirH, true)) { SYNC_OK = true; gravar(true); atualizarChip(); } }, { once: true });
    } else { try { if (!sessionStorage.getItem('yauri_avisou') && !window.YAURI_SEM_CHIP) { sessionStorage.setItem('yauri_avisou', '1'); setTimeout(() => toast('💾 Conecte seu pendrive: Perfil → Config → Salvar no pendrive'), 2500); } } catch (e) { /* ok */ } }
    setInterval(() => { if (dirH) gravar(false, false); }, 15000);
    document.addEventListener('visibilitychange', () => { if (document.hidden && dirH) gravar(false, false); });
    addEventListener('pagehide', () => { if (dirH) gravar(false, false); });
  }

  /* ---------- Chip fixo e janela ---------- */
  function atualizarChip() {
    const c = document.getElementById('y-chip'); if (!c) return;
    const ic = !dirH ? '' : SYNC_OK ? '<span title="Salvo no pendrive">💾</span>' : '<span title="Pendrive sem permissão">⚠️</span>';
    c.innerHTML = `${eq('avatar').d.e} <span>🪙 ${P.moedas}</span> <span>Nv ${nivel()}</span>${ic}${P.streak.n > 1 ? `<span>🔥${P.streak.n}</span>` : ''}`;
  }
  function posChip(c) {
    const p = (() => { try { return JSON.parse(localStorage.getItem('yauri_chipPos')); } catch (e) { return null; } })();
    c.style.left = c.style.right = c.style.top = c.style.bottom = 'auto'; c.style.transform = '';
    if (p && p.x != null) { c.style.left = Math.max(0, Math.min(innerWidth - 60, p.x)) + 'px'; c.style.top = Math.max(0, Math.min(innerHeight - 30, p.y)) + 'px'; return; }
    const k = window.YAURI_CHIP_POS || 'tr';
    if (k === 'tr') { c.style.right = '10px'; c.style.top = '10px'; } else if (k === 'tl') { c.style.left = '10px'; c.style.top = '10px'; }
    else if (k === 'bl') { c.style.left = '10px'; c.style.bottom = '10px'; } else if (k === 'br') { c.style.right = '10px'; c.style.bottom = '10px'; }
    else { c.style.left = '50%'; c.style.bottom = '8px'; c.style.transform = 'translateX(-50%)'; }
  }
  function criarChip() {
    if (window.YAURI_SEM_CHIP || document.getElementById('y-chip')) return;
    const c = document.createElement('div'); c.id = 'y-chip'; c.title = 'Clique: perfil, missões, baú, passe e loja · Arraste para mover';
    document.body.appendChild(c); posChip(c); atualizarChip();
    let ini = null, moveu = false;
    c.addEventListener('pointerdown', (e) => { const r = c.getBoundingClientRect(); ini = { dx: e.clientX - r.left, dy: e.clientY - r.top, x: e.clientX, y: e.clientY }; moveu = false; c.setPointerCapture(e.pointerId); });
    c.addEventListener('pointermove', (e) => { if (!ini) return; if (Math.abs(e.clientX - ini.x) + Math.abs(e.clientY - ini.y) > 5) moveu = true; if (moveu) { c.style.right = c.style.bottom = 'auto'; c.style.transform = ''; c.style.left = (e.clientX - ini.dx) + 'px'; c.style.top = (e.clientY - ini.dy) + 'px'; } });
    c.addEventListener('pointerup', (e) => { if (!ini) return; if (moveu) { try { localStorage.setItem('yauri_chipPos', JSON.stringify({ x: parseInt(c.style.left), y: parseInt(c.style.top) })); } catch (er) { /* ok */ } } else abrir('perfil'); ini = null; });
    c.addEventListener('dblclick', () => { try { localStorage.removeItem('yauri_chipPos'); } catch (e) { /* ok */ } posChip(c); });
  }
  let aba = 'perfil';
  function abrir(a) {
    estilo(); aba = a || aba;
    let ov = document.getElementById('y-ov');
    if (!ov) {
      ov = document.createElement('div'); ov.id = 'y-ov';
      ov.innerHTML = '<div id="y-box"><div id="y-tabs"></div><div id="y-body"></div></div>';
      ov.onclick = (e) => { if (e.target === ov) fechar(); }; document.body.appendChild(ov);
    }
    ov.classList.add('on'); desenharJanela();
  }
  function fechar() { const ov = document.getElementById('y-ov'); if (ov) ov.classList.remove('on'); }
  const NOMEPASSE = (l) => l % 10 === 0 ? '✨ Raro + ' + (30 + l * 5) + '🪙' : l % 5 === 0 ? '✨ Raro' : '🪙 ' + (30 + l * 5);
  function desenharJanela() {
    const tabs = [['perfil', '🙂 Perfil'], ['missoes', '📅 Missões'], ['conq', '🏆 Conquistas'], ['bau', '🎁 Baú'], ['passe', '🎟 Passe'], ['loja', '🛒 Loja'], ['rank', '📊 Ranking'], ['config', '⚙ Config']];
    document.getElementById('y-tabs').innerHTML = tabs.map(t => `<button data-a="${t[0]}" class="${aba === t[0] ? 'on' : ''}">${t[1]}</button>`).join('') + '<button class="x">✕</button>';
    document.querySelectorAll('#y-tabs button[data-a]').forEach(b => b.onclick = () => { aba = b.dataset.a; desenharJanela(); });
    document.querySelector('#y-tabs .x').onclick = fechar;
    const corpo = document.getElementById('y-body'); gerarMissoes();
    if (aba === 'perfil') {
      const n = nivel(), base = 40 * (n - 1) * (n - 1), prox = 40 * n * n, pct = Math.min(100, (P.xp - base) / (prox - base) * 100);
      corpo.innerHTML = `<div style="display:flex;gap:14px;align-items:center"><div style="font-size:56px">${eq('avatar').d.e}</div><div style="flex:1"><input id="y-nome" value="${P.nome.replace(/"/g, '')}" maxlength="24" style="background:#12151b;border:1px solid #333;color:#fff;padding:6px 10px;border-radius:6px;font-size:18px;font-weight:800;width:100%"><div style="color:#ffd700;font-weight:700;margin-top:4px">${eq('titulo').nome}</div></div></div>
      <div style="margin-top:14px">Nível <b>${n}</b> · ${P.xp} XP<div class="y-bar"><div style="width:${pct}%"></div></div></div>
      <div style="margin-top:10px;font-size:20px">🪙 <b>${P.moedas}</b> Yauri Coins &nbsp; 🔥 sequência: <b>${P.streak.n}</b> dia(s)</div>
      <div style="margin-top:12px;color:#aab;font-size:13px">🏆 ${Object.keys(P.conq).length} conquistas · ✨ ${RAROS.filter(r => P.itens[r]).length}/${RAROS.length} itens raros</div>
      <div style="margin-top:10px;color:#889;font-size:13px">Dica: tem easter eggs escondidos por aí… tente o código clássico dos anos 80 e clique no logo do menu. 🧀 Às vezes tem um queijinho escondido em alguma página.</div>`;
      document.getElementById('y-nome').onchange = (e) => { P.nome = e.target.value || 'Guilherme Yauri'; salvar(); };
    } else if (aba === 'missoes') {
      const w = semanal();
      corpo.innerHTML = '<div style="font-weight:800;margin-bottom:6px">Missões de hoje (renovam todo dia)</div>' + P.missoes.lista.map(m => {
        const d = POOL.find(p => p.id === m.i);
        return `<div class="y-msn ${m.feito ? 'ok' : ''}"><div style="display:flex;justify-content:space-between"><b>${d.t}</b><span>🪙 ${d.r}</span></div><div class="y-bar"><div style="width:${Math.min(100, m.prog / d.alvo * 100)}%"></div></div><small>${m.feito ? '✅ Concluída!' : m.prog + ' / ' + d.alvo}</small></div>`;
      }).join('') + `<div style="font-weight:800;margin:14px 0 6px">🏅 Desafio da semana</div><div class="y-msn ${P.sem.feito ? 'ok' : ''}"><div style="display:flex;justify-content:space-between"><b>${w.d.t.replace(/\d+/, n => n * 6)}</b><span>🪙 ${w.r} + ✨ raro</span></div><div class="y-bar"><div style="width:${Math.min(100, P.sem.prog / w.alvo * 100)}%"></div></div><small>${P.sem.feito ? '✅ Concluído!' : P.sem.prog + ' / ' + w.alvo}</small></div>`;
    } else if (aba === 'conq') {
      const feitas = CONQS.filter(c => P.conq[c.id]).length;
      corpo.innerHTML = `<div style="font-weight:800;margin-bottom:6px">${feitas + Object.keys(SECRETAS).filter(k => P.conq[k]).length} conquistas desbloqueadas</div>` +
        CONQS.map(c => { const v = c.ev === 'nivel' ? nivel() : c.ev === 'streak' ? P.streak.n : (P.stats[c.ev] || 0), ok = P.conq[c.id]; return `<div class="y-it" style="${ok ? 'outline:1px solid #4ade80' : ''}"><span>${ok ? '🏆' : '🔒'} ${c.nome}<div class="y-bar"><div style="width:${Math.min(100, v / c.alvo * 100)}%"></div></div></span><b>🪙 ${c.r}</b></div>`; }).join('') +
        '<div style="font-weight:800;margin:12px 0 6px">Secretas</div>' + Object.keys(SECRETAS).map(k => `<span class="y-chipc ${P.conq[k] ? '' : 'n'}">${P.conq[k] ? '🏆 ' + SECRETAS[k] : '❓ ???'}</span>`).join('');
    } else if (aba === 'bau') {
      const pode = P.bau !== hoje();
      corpo.innerHTML = `<div style="text-align:center"><div class="y-bau" id="y-bau">${pode ? '🎁' : '📭'}</div><div id="y-bau-t" style="font-size:18px;font-weight:800">${pode ? 'Clique no baú para abrir!' : 'Você já abriu o baú de hoje. Volte amanhã!'}</div>
      <div style="color:#889;font-size:13px;margin-top:10px">Chances: moedas (comum e raro), item ✨ raro (10%) e épico com raro + 500 moedas (5%).<br>🔥 Sequência atual: ${P.streak.n} dia(s). Entrar todo dia aumenta o bônus diário.</div></div>`;
      if (pode) document.getElementById('y-bau').onclick = () => {
        const b = document.getElementById('y-bau');
        if (P.bau === hoje() || b.dataset.aberto) return; // trava: só abre uma vez por dia
        b.dataset.aberto = '1'; b.onclick = null; b.style.cursor = 'default';
        b.classList.add('abre'); P.bau = hoje(); salvar(); beep(500, .1);
        setTimeout(() => {
          const r = Math.random(); let t;
          if (r < .55) { const c = 40 + Math.floor(Math.random() * 60); ganhar(c, c, 'baú'); t = '🪙 ' + c + ' moedas'; }
          else if (r < .85) { const c = 100 + Math.floor(Math.random() * 120); ganhar(c, c, 'baú'); t = '🪙 ' + c + ' moedas (RARO!)'; }
          else if (r < .95) { const id = darRaro(); t = id ? '✨ ' + item(id).nome : '🪙 300 moedas'; }
          else { ganhar(500, 200, 'baú ÉPICO'); const id = darRaro(); t = '💎 ÉPICO! 500 moedas' + (id ? ' + ' + item(id).nome : ''); }
          b.textContent = '✨'; document.getElementById('y-bau-t').textContent = 'Você ganhou: ' + t; beep(900, .2, 'sine'); atualizarChip();
        }, 650);
      };
    } else if (aba === 'passe') {
      const lv = Math.min(30, Math.floor(P.passe.xp / 100));
      let h = `<div style="font-weight:800">🎟 Passe da temporada (${P.passe.mes}) — nível ${lv}/30</div><div style="color:#889;font-size:13px">Todo XP que você ganha vale pro passe. Reinicia todo mês.</div><div class="y-bar"><div style="width:${Math.min(100, (P.passe.xp % 100) * (lv >= 30 ? 0 : 1))}%"></div></div><div class="y-pg" style="margin-top:10px">`;
      for (let l = 1; l <= 30; l++) { const feito = P.passe.res[l], alc = l <= lv; h += `<div class="${feito ? 'ok' : alc ? 'pr' : ''}"><b>${l}</b><br>${NOMEPASSE(l)}<br>${feito ? '✅' : alc ? `<button class="y-b" data-p="${l}" style="padding:2px 8px;margin-top:3px">Pegar</button>` : '🔒'}</div>`; }
      corpo.innerHTML = h + '</div>';
      corpo.querySelectorAll('[data-p]').forEach(b => b.onclick = () => {
        const l = +b.dataset.p; if (P.passe.res[l]) return; P.passe.res[l] = 1; salvar();
        ganhar(l % 5 === 0 && l % 10 !== 0 ? 0 : 30 + l * 5, 0, 'passe'); if (l % 5 === 0) darRaro(); if (l === 30) { P.itens.tit_6 = 1; toast('🎖 Título: Veterano da Temporada'); salvar(); } desenharJanela();
      });
    } else if (aba === 'loja') {
      let h = `<div style="margin-bottom:8px">Você tem <b>🪙 ${P.moedas}</b> · ✨ itens raros só saem de baú, passe, desafio semanal e conquistas</div>`;
      for (const cat in CATS) {
        h += `<div style="font-weight:800;margin-top:10px">${CATS[cat]}</div>`;
        ITENS.filter(i => i.cat === cat).forEach(i => {
          const meu = tem(i.id), usando = eq(cat) && eq(cat).id === i.id;
          if (i.preco < 0 && !meu) { h += `<div class="y-it" style="opacity:.5"><span>❓ ??? (item raro)</span><button class="y-b eq" disabled>🔒</button></div>`; return; }
          h += `<div class="y-it"><span>${i.nome}</span>${usando ? '<button class="y-b eq" disabled>Em uso</button>' : meu ? `<button class="y-b" data-e="${i.id}">Equipar</button>` : `<button class="y-b go" data-c="${i.id}" ${P.moedas < i.preco ? 'disabled' : ''}>🪙 ${i.preco}</button>`}</div>`;
        });
      }
      corpo.innerHTML = h;
      corpo.querySelectorAll('[data-c]').forEach(b => b.onclick = () => { if (comprar(b.dataset.c)) { toast('Comprado!'); desenharJanela(); } });
      corpo.querySelectorAll('[data-e]').forEach(b => b.onclick = () => { equipar(b.dataset.e); desenharJanela(); });
    } else if (aba === 'rank') {
      const ids = Object.keys(P.rec);
      corpo.innerHTML = '<div style="font-weight:800;margin-bottom:6px">📊 Seus recordes (mude o nome no Perfil antes de jogar para disputar com amigos)</div>' + (ids.length ? ids.map(id => { const r = P.rec[id]; return `<div class="y-msn"><b>${r.nome}</b>${r.top.map((t, i) => `<div style="display:flex;justify-content:space-between;font-size:14px"><span>${['🥇', '🥈', '🥉', '4º', '5º'][i]} ${t.n}</span><span><b>${t.v}</b> <small style="color:#889">${t.d}</small></span></div>`).join('')}</div>`; }).join('') : 'Jogue algumas partidas e os recordes aparecem aqui.');
    } else {
      const stat = !window.showDirectoryPicker ? '⚠ Este navegador não permite gravar na pasta (use Chrome ou Edge). Use Exportar/Importar.' : dirH ? (SYNC_OK ? '✅ Pasta conectada e salvando' + (ultimaGravacao ? ' (último: ' + new Date(ultimaGravacao).toLocaleTimeString() + ')' : '') : '⚠ Pasta conectada, mas falta permissão: clique em qualquer lugar da página e aceite o aviso do navegador.' + (erroSync ? ' (' + erroSync + ')' : '')) : '❌ Nenhuma pasta conectada ainda';
      corpo.innerHTML = `<div class="y-msn"><b>💾 Salvar no pendrive</b><div style="font-size:13px;color:#aab;margin:6px 0">Escolha a pasta <b>YauriGames</b> que está no seu pendrive. O progresso (moedas, itens, recordes, cidade, partidas…) é gravado em <code>dados/progresso.js</code> e carregado sozinho em qualquer computador que abrir o pendrive.</div><div style="margin-bottom:8px">${stat}</div>
      <button class="y-b" id="y-con">📁 ${dirH ? 'Trocar pasta' : 'Conectar pasta do pendrive'}</button> <button class="y-b" id="y-gr" ${dirH ? '' : 'disabled'}>Salvar agora</button></div>
      <div class="y-msn"><b>Plano B (qualquer navegador)</b><div style="font-size:13px;color:#aab;margin:6px 0">Exportar baixa o <code>progresso.js</code>: copie para a pasta <code>dados</code> do pendrive. Importar lê um arquivo desses.</div><button class="y-b" id="y-exp">📥 Exportar</button> <button class="y-b" id="y-imp">📤 Importar</button><input type="file" id="y-file" accept=".js,.json,.txt" style="display:none"></div>
      <div class="y-it"><span>🔊 Volume dos jogos</span><input type="range" id="y-vol" min="0" max="1" step="0.05" value="${P.vol}"></div>
      <div class="y-it"><span>🔇 Mudo</span><input type="checkbox" id="y-mudo" ${P.mudo ? 'checked' : ''}></div>
      <div class="y-it"><span>Modo chefe: aperte <b>\`</b> (crase) para esconder o jogo</span></div>
      <div class="y-it"><span>Apagar perfil, moedas e cosméticos</span><button class="y-b" style="background:#8b2d2d" id="y-zero">Apagar</button></div>`;
      document.getElementById('y-con').onclick = async () => { await conectarPasta(); desenharJanela(); };
      document.getElementById('y-gr').onclick = async () => { const ok = await gravar(true, true); toast(ok ? '💾 Salvo!' : '⚠ Falhou: ' + erroSync); desenharJanela(); };
      document.getElementById('y-exp').onclick = exportar;
      document.getElementById('y-imp').onclick = () => document.getElementById('y-file').click();
      document.getElementById('y-file').onchange = (e) => { const f = e.target.files[0]; if (f) f.text().then(t => { if (importar(t)) desenharJanela(); }); };
      document.getElementById('y-vol').oninput = (e) => { P.vol = +e.target.value; salvar(); beep(660, .08); };
      document.getElementById('y-mudo').onchange = (e) => { P.mudo = e.target.checked; salvar(); };
      document.getElementById('y-zero').onclick = () => { if (confirm('Apagar TUDO do perfil?')) { P = novo(); salvar(); aplicarCosmeticos(); desenharJanela(); } };
    }
  }

  /* ---------- Easter eggs ---------- */
  function chuva(texto, seg) {
    estilo();
    for (let i = 0; i < 40; i++) setTimeout(() => {
      const d = document.createElement('div'); d.className = 'y-chuva'; d.textContent = texto || 'Guilherme Yauri';
      d.style.left = Math.random() * 90 + 'vw'; d.style.animationDuration = (3 + Math.random() * 3) + 's'; d.style.fontSize = (14 + Math.random() * 20) + 'px';
      document.body.appendChild(d); setTimeout(() => d.remove(), 6500);
    }, i * (seg ? seg * 1000 / 40 : 120));
  }
  const KONAMI = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
  let ki = 0, digitado = '';
  function aoTeclar(e) {
    if (e.target && /INPUT|TEXTAREA/.test(e.target.tagName)) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    ki = (k === KONAMI[ki]) ? ki + 1 : (k === KONAMI[0] ? 1 : 0);
    if (ki === KONAMI.length) { ki = 0; chuva('Guilherme Yauri 👑'); conquista('konami', 'Código secreto! (Konami)', 100); }
    if (e.key.length === 1) {
      digitado = (digitado + k).slice(-8);
      if (digitado.endsWith('yauri')) {
        let on = !modoYauri(); try { sessionStorage.setItem('yauri_modo', on ? '1' : '0'); } catch (er) { /* ok */ }
        aplicarCosmeticos(); toast(on ? '😎 MODO YAURI ATIVADO' : 'Modo Yauri desativado'); if (on) { marcas(); conquista('yauri', 'Modo Yauri', 50); }
      }
      if (digitado.endsWith('guizin')) { toast('👑 Senhor Supremo do Universo detectado'); conquista('guizin', 'Senhor Supremo', 75); chuva('Senhor Supremo do Universo', 3); }
    }
    if (e.key === '`' || e.key === '´') alternarChefe();
  }
  function marcas() {
    let n = 0; const t = setInterval(() => {
      if (!modoYauri() || ++n > 400) return clearInterval(t);
      const d = document.createElement('div'); d.id = 'y-marca'; d.textContent = 'Guilherme Yauri'; d.style.left = Math.random() * 85 + 'vw'; d.style.top = (10 + Math.random() * 80) + 'vh';
      document.body.appendChild(d); setTimeout(() => d.remove(), 4000);
    }, 2500);
  }
  function alternarChefe() {
    estilo(); let c = document.getElementById('y-chefe');
    if (!c) {
      c = document.createElement('div'); c.id = 'y-chefe';
      c.innerHTML = '<div class="barra">📄 Redação ENEM — rascunho final.docx — Documentos</div><div class="pg"><h2>A importância da educação digital no Brasil contemporâneo</h2><p>Em primeiro lugar, é fundamental destacar que o acesso à tecnologia transformou profundamente as relações sociais no país. Nesse sentido, o desenvolvimento de competências digitais torna-se indispensável para a formação cidadã.</p><p>Ademais, a desigualdade de acesso à internet ainda representa um entrave significativo, o que reforça a necessidade de políticas públicas eficazes. Portanto, cabe ao Estado, em parceria com as instituições de ensino, promover a inclusão digital, a fim de garantir…</p></div>';
      document.body.appendChild(c);
    }
    const on = c.style.display !== 'block'; c.style.display = on ? 'block' : 'none';
    if (on) { conquista('chefe', 'Modo chefe usado', 20); document.title = 'Documento — Google Docs'; }
  }
  function sala() {
    estilo(); conquista('logo7', 'Sala secreta encontrada!', 100);
    const ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:#000e;z-index:9990;display:flex;align-items:center;justify-content:center;color:#fff;font-family:system-ui;text-align:center;padding:20px';
    ov.innerHTML = '<div><div style="font-size:70px">👑</div><h1 style="color:#ffd700;margin:6px 0">SALA SECRETA</h1><p style="font-size:18px">Feito pelo <b>Senhor Supremo do Universo</b><br>Guilherme Yauri — IFSP Catanduva</p><p style="color:#aab">Programação: Claude + muita ideia do Guizin.<br>Nego frutinha não achou esta sala. 😎</p><button class="y-b" style="font-size:16px;padding:10px 22px">Voltar</button></div>';
    const fecha = () => ov.remove(); ov.querySelector('button').onclick = fecha; ov.onclick = (e) => { if (e.target === ov) fecha(); }; document.addEventListener('keydown', function esc(e) { if (e.key === 'Escape') { fecha(); document.removeEventListener('keydown', esc); } }); document.body.appendChild(ov); chuva('Guilherme Yauri', 4);
  }
  function queijoEscondido() {
    if (window.YAURI_SEM_CHIP || Math.random() > 0.25) return;
    const q = document.createElement('div'); q.id = 'y-queijo'; q.textContent = '🧀';
    q.style.left = (Math.random() * 90 + 2) + 'vw'; q.style.top = (Math.random() * 85 + 8) + 'vh';
    q.onclick = (e) => { e.stopPropagation(); q.remove(); evento('queijos'); ganhar(15, 10, 'queijo escondido!'); beep(900, .15, 'sine'); };
    document.body.appendChild(q);
  }

  /* ---------- Início ---------- */
  function iniciar() {
    estilo(); gerarMissoes(); aplicarCosmeticos(); criarChip();
    document.addEventListener('keydown', aoTeclar);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fechar(); });
    document.addEventListener('pointerdown', () => { try { if (ac && ac.state === 'suspended') ac.resume(); } catch (e) { /* ok */ } }, { once: true });
    if (modoYauri()) marcas();
    // sequência diária + bônus
    const hj = diaNum(new Date());
    if (P.ultimoDia !== hoje()) {
      const ult = P.streak.ult ? +P.streak.ult : 0;
      P.streak.n = (ult && hj - ult === 1) ? P.streak.n + 1 : 1; P.streak.ult = String(hj); P.ultimoDia = hoje(); salvar();
      const b = 25 + 15 * (Math.min(P.streak.n, 7) - 1) + (P.streak.n % 7 === 0 ? 100 : 0);
      setTimeout(() => { ganhar(b, 10, '🔥 dia ' + P.streak.n + ' seguido'); checarConquistas(); salvar(); }, 800);
    }
    queijoEscondido(); iniciarSync();
  }
  window.Yauri = {
    ganhar, evento, conquista, toast, eq, tem, comprar, equipar, abrir, beep, chuva, sala, modoYauri, recorde,
    frase: () => FRASES[Math.floor(Math.random() * FRASES.length)], perfil: () => P, ITENS, POOL, nivel, darRaro,
    sync: { snapshot, gravar, restaurar, importar, exportar, conectarPasta, setHandle: (h) => { dirH = h; }, get ok() { return SYNC_OK; } },
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
