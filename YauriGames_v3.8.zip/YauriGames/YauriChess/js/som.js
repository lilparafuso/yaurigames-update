/* som.js — sons simples gerados pelo navegador (WebAudio), sem arquivos de áudio. */
window.Som = (function () {
  let ctx = null;
  let ativo = true;
  function pegar() {
    if (!ctx) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ctx = null; } }
    if (ctx && ctx.state === 'suspended') ctx.resume();
    return ctx;
  }
  // Toca um "toc" curto: frequência, duração, volume, tipo de onda
  function tom(freq, dur, vol, tipo, atraso) {
    const c = pegar(); if (!c || !ativo) return;
    const t0 = c.currentTime + (atraso || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = tipo || 'sine'; o.frequency.setValueAtTime(freq, t0);
    o.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.5), t0 + dur);
    g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(c.destination); o.start(t0); o.stop(t0 + dur + 0.02);
  }
  function ruido(dur, vol) {
    const c = pegar(); if (!c || !ativo) return;
    const n = Math.floor(c.sampleRate * dur), buf = c.createBuffer(1, n, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = c.createBufferSource(), g = c.createGain(), f = c.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = 1800; g.gain.value = vol;
    s.buffer = buf; s.connect(f); f.connect(g); g.connect(c.destination); s.start();
  }
  return {
    ligar(v) { ativo = !!v; },
    mover() { tom(260, 0.09, 0.35, 'triangle'); ruido(0.05, 0.25); },
    capturar() { tom(180, 0.14, 0.45, 'triangle'); ruido(0.12, 0.5); },
    xeque() { tom(520, 0.12, 0.3, 'square'); tom(390, 0.18, 0.3, 'square', 0.1); },
    roque() { tom(260, 0.09, 0.3, 'triangle'); tom(300, 0.09, 0.3, 'triangle', 0.1); },
    erro() { tom(150, 0.25, 0.3, 'sawtooth'); },
    inicio() { tom(440, 0.12, 0.25, 'sine'); tom(660, 0.18, 0.25, 'sine', 0.12); },
    fim() { tom(523, 0.2, 0.3, 'sine'); tom(392, 0.2, 0.3, 'sine', 0.2); tom(330, 0.35, 0.3, 'sine', 0.4); },
    acordar() { pegar(); },
  };
})();
