/* ============================================================
   motor.js — conversa com o Stockfish (o "cérebro" do xadrez)
   ------------------------------------------------------------
   Problema: abrindo o jogo direto do pendrive (file://), o navegador
   NÃO deixa carregar um Worker nem um arquivo .wasm de outro arquivo.
   Solução: o Stockfish está dentro de arquivos .js em formato texto
   (base64). Aqui a gente decodifica, cria "arquivos virtuais" (Blob)
   e inicia o Worker a partir deles. Tudo funciona offline.
   ============================================================ */

(function () {
  // Converte texto base64 em bytes
  function b64ParaBytes(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  // Carrega um arquivo .js de engine/ sob demanda (usado só no plano B)
  function carregarScript(src) {
    return new Promise((ok, erro) => {
      const s = document.createElement('script');
      s.src = src;
      s.onload = ok;
      s.onerror = () => erro(new Error('Falha ao carregar ' + src));
      document.head.appendChild(s);
    });
  }

  // Cria o Worker do Stockfish (versão rápida WASM).
  // O navegador não deixa o worker "buscar" o .wasm em file://, então a gente
  // entrega o .wasm já dentro do próprio script do worker (em base64) e troca
  // o "fetch" do Stockfish por uma função nossa que devolve esses bytes.
  function criarWorkerWasm() {
    const prefixo =
      'self.WASM_B64="' + window.SF_WASM + '";\n' +
      'self.__buscarWasm=function(){var b=atob(self.WASM_B64),u=new Uint8Array(b.length);' +
      'for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);' +
      'return Promise.resolve(new Response(u,{status:200,headers:{"Content-Type":"application/wasm"}}));};\n';
    const corpo = atob(window.SF_JS);
    const url = URL.createObjectURL(new Blob([prefixo, corpo], { type: 'text/javascript' }));
    return new Worker(url);
  }

  // Plano B: versão em JavaScript puro (mais lenta e fraca, mas roda em qualquer navegador)
  async function criarWorkerAsm() {
    if (!window.SF_ASM) await carregarScript('engine/sf-asm.js');
    const jsUrl = URL.createObjectURL(new Blob([b64ParaBytes(window.SF_ASM)], { type: 'text/javascript' }));
    return new Worker(jsUrl);
  }

  // Valor de mate usado nas contas (um mate em N vale quase 10000 centipeões)
  const VALOR_MATE = 10000;

  class Motor {
    constructor(nome) {
      this.nome = nome;
      this.worker = null;
      this.pronto = null;       // Promise que resolve quando o motor está pronto
      this.tipo = '?';          // 'wasm' ou 'asm'
      this.fila = Promise.resolve();
      this.trabalhoAtual = null;
    }

    // Inicia o motor (tenta WASM; se falhar, cai para ASM)
    iniciar() {
      if (this.pronto) return this.pronto;
      this.pronto = (async () => {
        try {
          this.worker = criarWorkerWasm();
          this.tipo = 'wasm';
          await this._handshake(12000);
        } catch (e) {
          console.warn('[motor] WASM falhou, usando plano B (ASM):', e);
          if (this.worker) this.worker.terminate();
          this.worker = await criarWorkerAsm();
          this.tipo = 'asm';
          await this._handshake(30000);
        }
        this.worker.onmessage = (ev) => this._aoReceber(String(ev.data));
        return true;
      })();
      return this.pronto;
    }

    // Manda "uci" e espera "uciok" + "readyok"
    _handshake(limiteMs) {
      return new Promise((ok, erro) => {
        const w = this.worker;
        const timer = setTimeout(() => erro(new Error('Motor demorou demais para iniciar')), limiteMs);
        w.onerror = (e) => { clearTimeout(timer); erro(new Error('Erro no worker: ' + (e.message || e))); };
        w.onmessage = (ev) => {
          const linha = String(ev.data);
          if (linha.startsWith('uciok')) w.postMessage('isready');
          else if (linha.startsWith('readyok')) { clearTimeout(timer); w.onerror = null; ok(); }
        };
        w.postMessage('uci');
      });
    }

    enviar(cmd) { this.worker.postMessage(cmd); }

    // Recebe cada linha que o Stockfish escreve
    _aoReceber(linha) {
      const t = this.trabalhoAtual;
      if (!t) return;
      if (linha.startsWith('info') && linha.includes(' pv ')) {
        // Exemplo: info depth 12 seldepth 18 multipv 1 score cp 34 nodes ... pv e2e4 e7e5
        if (/ (lowerbound|upperbound) /.test(linha)) return; // ignora resultados parciais
        const m = linha.match(/depth (\d+).*? multipv (\d+) score (cp|mate) (-?\d+).*? pv (.+)$/);
        const m2 = m || linha.match(/depth (\d+).*?()score (cp|mate) (-?\d+).*? pv (.+)$/);
        if (!m2) return;
        const prof = +m2[1];
        const mpv = m2[2] ? +m2[2] : 1;
        const tipo = m2[3];
        const val = +m2[4];
        const pv = m2[5].trim().split(/\s+/);
        t.linhas[mpv] = {
          mov: pv[0],
          pv,
          cp: tipo === 'cp' ? val : null,
          mate: tipo === 'mate' ? val : null,
          prof,
        };
      } else if (linha.startsWith('bestmove')) {
        const mov = linha.split(/\s+/)[1];
        const lista = Object.keys(t.linhas).map(Number).sort((a, b) => a - b).map(k => t.linhas[k]);
        this.trabalhoAtual = null;
        t.resolver({ melhor: mov === '(none)' ? null : mov, linhas: lista });
      }
    }

    /* Pede uma análise.
       opcoes: { profundidade, tempoMs, multipv, elo (limita a força), skill }
       Retorna: { melhor: 'e2e4', linhas: [{mov, cp, mate, pv, prof}] }
       cp/mate sempre do ponto de vista de QUEM ESTÁ PARA JOGAR. */
    analisar(fen, opcoes = {}) {
      const rodar = async () => {
        await this.iniciar();
        return new Promise((resolver) => {
          this.trabalhoAtual = { linhas: {}, resolver };
          this.enviar('ucinewgame');
          this.enviar('setoption name MultiPV value ' + (opcoes.multipv || 1));
          if (opcoes.elo) {
            this.enviar('setoption name UCI_LimitStrength value true');
            this.enviar('setoption name UCI_Elo value ' + opcoes.elo);
          } else {
            this.enviar('setoption name UCI_LimitStrength value false');
          }
          this.enviar('setoption name Skill Level value ' + (opcoes.skill != null ? opcoes.skill : 20));
          this.enviar('position fen ' + fen);
          let go = 'go';
          if (opcoes.profundidade) go += ' depth ' + opcoes.profundidade;
          if (opcoes.tempoMs) go += ' movetime ' + Math.round(opcoes.tempoMs);
          if (!opcoes.profundidade && !opcoes.tempoMs) go += ' depth 10';
          this.enviar(go);
        });
      };
      // Um pedido por vez (fila)
      const p = this.fila.then(rodar, rodar);
      this.fila = p.catch(() => {});
      return p;
    }

    // Interrompe o cálculo atual (o resultado parcial ainda é devolvido)
    parar() {
      if (this.trabalhoAtual) this.enviar('stop');
    }
  }

  window.Motor = Motor;
  window.VALOR_MATE = VALOR_MATE;
})();
