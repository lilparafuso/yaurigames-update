/* aberturas.js — pequeno "livro" de aberturas (lances em SAN, sem + e #).
   Serve para mostrar o nome da abertura e marcar lances de teoria. */
window.ABERTURAS = [
  ['e4', 'Abertura do Peão do Rei'],
  ['d4', 'Abertura do Peão da Dama'],
  ['c4', 'Abertura Inglesa'],
  ['Nf3', 'Abertura Réti'],
  ['f4', 'Abertura Bird'],
  ['b3', 'Abertura Larsen'],
  ['g3', 'Abertura Catalã/Hungara (g3)'],
  ['e4 e5', 'Jogo Aberto'],
  ['e4 e5 Nf3', 'Jogo do Cavalo do Rei'],
  ['e4 e5 Nf3 Nc6', 'Jogo de Cavalo (Nf3 Nc6)'],
  ['e4 e5 Nf3 Nc6 Bb5', 'Ruy Lopez (Abertura Espanhola)'],
  ['e4 e5 Nf3 Nc6 Bb5 a6', 'Ruy Lopez: Variante Morphy'],
  ['e4 e5 Nf3 Nc6 Bb5 Nf6', 'Ruy Lopez: Defesa Berlim'],
  ['e4 e5 Nf3 Nc6 Bc4', 'Jogo Italiano'],
  ['e4 e5 Nf3 Nc6 Bc4 Bc5', 'Giuoco Piano'],
  ['e4 e5 Nf3 Nc6 Bc4 Nf6', 'Defesa dos Dois Cavalos'],
  ['e4 e5 Nf3 Nc6 d4', 'Abertura Escocesa'],
  ['e4 e5 Nf3 Nc6 d4 exd4 Nxd4', 'Abertura Escocesa: Nxd4'],
  ['e4 e5 Nf3 Nc6 Nc3 Nf6', 'Jogo dos Quatro Cavalos'],
  ['e4 e5 Nf3 Nf6', 'Defesa Russa (Petrov)'],
  ['e4 e5 Nf3 d6', 'Defesa Philidor'],
  ['e4 e5 f4', 'Gambito do Rei'],
  ['e4 e5 Bc4', 'Abertura do Bispo'],
  ['e4 e5 Nc3', 'Abertura Vienense'],
  ['e4 e5 d4', 'Gambito do Centro'],
  ['e4 c5', 'Defesa Siciliana'],
  ['e4 c5 Nf3 d6', 'Siciliana: Variante ...d6'],
  ['e4 c5 Nf3 Nc6', 'Siciliana: Variante ...Nc6'],
  ['e4 c5 Nf3 e6', 'Siciliana: Variante ...e6'],
  ['e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6', 'Siciliana: Variante Najdorf'],
  ['e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6', 'Siciliana: Variante do Dragão'],
  ['e4 c5 c3', 'Siciliana: Variante Alapin'],
  ['e4 c5 Nc3', 'Siciliana Fechada'],
  ['e4 e6', 'Defesa Francesa'],
  ['e4 e6 d4 d5', 'Defesa Francesa: Linha Principal'],
  ['e4 e6 d4 d5 e5', 'Francesa: Variante do Avanço'],
  ['e4 e6 d4 d5 Nc3 Bb4', 'Francesa: Variante Winawer'],
  ['e4 e6 d4 d5 Nd2', 'Francesa: Variante Tarrasch'],
  ['e4 c6', 'Defesa Caro-Kann'],
  ['e4 c6 d4 d5 e5', 'Caro-Kann: Variante do Avanço'],
  ['e4 c6 d4 d5 Nc3 dxe4', 'Caro-Kann: Variante Clássica'],
  ['e4 d5', 'Defesa Escandinava'],
  ['e4 d5 exd5 Qxd5', 'Escandinava: Dama Central'],
  ['e4 d6', 'Defesa Pirc'],
  ['e4 g6', 'Defesa Moderna'],
  ['e4 Nf6', 'Defesa Alekhine'],
  ['d4 d5', 'Jogo do Peão da Dama'],
  ['d4 d5 c4', 'Gambito da Dama'],
  ['d4 d5 c4 e6', 'Gambito da Dama Recusado'],
  ['d4 d5 c4 dxc4', 'Gambito da Dama Aceito'],
  ['d4 d5 c4 c6', 'Defesa Eslava'],
  ['d4 d5 Bf4', 'Sistema Londres'],
  ['d4 d5 Nf3 Nf6 Bf4', 'Sistema Londres'],
  ['d4 Nf6', 'Defesa Índia'],
  ['d4 Nf6 c4 g6', 'Defesa Índia do Rei'],
  ['d4 Nf6 c4 e6 Nc3 Bb4', 'Defesa Nimzo-Índia'],
  ['d4 Nf6 c4 e6 Nf3 b6', 'Defesa Índia da Dama'],
  ['d4 Nf6 Bg5', 'Ataque Trompowsky'],
  ['d4 f5', 'Defesa Holandesa'],
  ['c4 e5', 'Inglesa: Siciliana Invertida'],
  ['Nf3 d5', 'Abertura Réti: ...d5'],
  ['Nf3 d5 g3', 'Abertura Réti: Fianqueto do Rei'],
];

// Dada a lista de lances (SAN) jogados, devolve { nome, emLivro }
window.acharAbertura = function (sans) {
  const limpos = sans.map(s => s.replace(/[+#!?]/g, ''));
  let nome = null, emLivro = false;
  for (const [linha, n] of window.ABERTURAS) {
    const l = linha.split(' ');
    if (l.length > limpos.length) {
      // a linha é mais longa que a partida: ainda "no livro" se a partida for um prefixo dela
      if (l.slice(0, limpos.length).join(' ') === limpos.join(' ')) emLivro = true;
      continue;
    }
    if (l.join(' ') === limpos.slice(0, l.length).join(' ')) {
      nome = n;
      if (l.length === limpos.length) emLivro = true;
    }
  }
  return { nome, emLivro };
};
