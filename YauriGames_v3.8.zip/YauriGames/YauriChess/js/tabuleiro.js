/* ============================================================
   tabuleiro.js — desenha o tabuleiro e cuida do mouse/toque
   (arrastar e soltar, clicar-clicar, animação, setas e selos)
   Ele NÃO conhece as regras: quem decide se o lance vale é o app.
   ============================================================ */

(function () {
  const NS = 'http://www.w3.org/2000/svg';

  class Tabuleiro {
    /* raiz: elemento onde o tabuleiro será criado
       opcoes.lancesDe(casa)  -> [{to, captura}] lances legais da peça
       opcoes.aoMover(de, para) -> o app tenta o lance (pode abrir a promoção)
       opcoes.podeSelecionar(casa, peca) -> true se o jogador pode mexer nessa peça agora */
    constructor(raiz, opcoes) {
      this.raiz = raiz;
      this.op = opcoes;
      this.orientacao = 'w';
      this.pecas = new Map();         // casa -> elemento da peça
      this.selecionada = null;
      this.mostrarLegais = true;
      this.ultimo = null;             // {from,to}
      this.casaXeque = null;
      this.destaques = [];            // casas extras destacadas
      this.arrastando = null;
      this.montar();
    }

    montar() {
      this.raiz.innerHTML = '';
      this.raiz.classList.add('tabuleiro');
      this.camadaCasas = document.createElement('div'); this.camadaCasas.className = 'camada casas';
      this.camadaMarcas = document.createElement('div'); this.camadaMarcas.className = 'camada marcas';
      this.camadaPecas = document.createElement('div'); this.camadaPecas.className = 'camada pecas';
      this.svg = document.createElementNS(NS, 'svg');
      this.svg.setAttribute('viewBox', '0 0 800 800'); this.svg.setAttribute('class', 'camada setas');
      this.camadaSelos = document.createElement('div'); this.camadaSelos.className = 'camada selos';
      this.raiz.append(this.camadaCasas, this.camadaMarcas, this.svg, this.camadaPecas, this.camadaSelos);
      this.casaEls = {};
      for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) {
        const sq = 'abcdefgh'[f] + (8 - r);
        const d = document.createElement('div');
        d.className = 'casa ' + ((r + f) % 2 === 0 ? 'clara' : 'escura');
        d.dataset.sq = sq;
        this.camadaCasas.appendChild(d);
        this.casaEls[sq] = d;
      }
      this.raiz.addEventListener('pointerdown', (e) => this.aoApertar(e));
      window.addEventListener('pointermove', (e) => this.aoMexer(e));
      window.addEventListener('pointerup', (e) => this.aoSoltar(e));
      this.raiz.addEventListener('contextmenu', (e) => e.preventDefault());
      this.atualizarCoordenadas();
    }

    /* ----- posição de cada casa na tela (em %) ----- */
    posicao(sq) {
      const f = sq.charCodeAt(0) - 97, r = 8 - parseInt(sq[1], 10);
      const col = this.orientacao === 'w' ? f : 7 - f;
      const lin = this.orientacao === 'w' ? r : 7 - r;
      return { x: col * 12.5, y: lin * 12.5, col, lin };
    }
    casaDe(col, lin) {
      const f = this.orientacao === 'w' ? col : 7 - col;
      const r = this.orientacao === 'w' ? lin : 7 - lin;
      return 'abcdefgh'[f] + (8 - r);
    }
    casaNoPonto(x, y) {
      const rc = this.raiz.getBoundingClientRect();
      const col = Math.floor((x - rc.left) / rc.width * 8), lin = Math.floor((y - rc.top) / rc.height * 8);
      if (col < 0 || col > 7 || lin < 0 || lin > 7) return null;
      return this.casaDe(col, lin);
    }

    // Reorganiza as casas conforme a orientação (brancas embaixo ou pretas embaixo)
    atualizarCoordenadas() {
      this.camadaCasas.innerHTML = '';
      for (let lin = 0; lin < 8; lin++) for (let col = 0; col < 8; col++) {
        const sq = this.casaDe(col, lin);
        const d = this.casaEls[sq];
        d.innerHTML = '';
        if (col === 0) { const n = document.createElement('span'); n.className = 'coord num'; n.textContent = sq[1]; d.appendChild(n); }
        if (lin === 7) { const l = document.createElement('span'); l.className = 'coord let'; l.textContent = sq[0]; d.appendChild(l); }
        this.camadaCasas.appendChild(d);
      }
    }

    virar() {
      this.orientacao = this.orientacao === 'w' ? 'b' : 'w';
      this.atualizarCoordenadas();
      this.reposicionar();
      this.desenharMarcas();
      this.reposicionarSelos();
      if (this._setas) this.desenharSetas(this._setas);
    }
    definirOrientacao(o) { if (o !== this.orientacao) this.virar(); }

    /* ----- peças ----- */
    criarPeca(tipoCor, sq) {
      const el = document.createElement('div');
      el.className = 'peca';
      el.dataset.tipo = tipoCor;
      el.style.backgroundImage = 'url("' + window.PECAS[tipoCor] + '")';
      const p = this.posicao(sq);
      el.style.left = p.x + '%'; el.style.top = p.y + '%';
      this.camadaPecas.appendChild(el);
      return el;
    }
    posicionar(el, sq) {
      const p = this.posicao(sq);
      el.style.left = p.x + '%'; el.style.top = p.y + '%';
    }
    reposicionar() {
      this.pecas.forEach((el, sq) => { el.classList.add('sem-anim'); this.posicionar(el, sq); });
      requestAnimationFrame(() => this.pecas.forEach(el => el.classList.remove('sem-anim')));
    }

    /* Define a posição mostrada. tab = chess.board() (matriz 8x8).
       animar: se true, as peças deslizam até a nova casa. */
    definir(tab, animar) {
      const alvo = new Map();   // casa -> 'wp'...
      for (const linha of tab) for (const p of linha) if (p) alvo.set(p.square, p.color + p.type);
      const novas = [];
      // 1) peças que continuam no mesmo lugar ficam como estão
      const sobraram = new Map(this.pecas);
      for (const [sq, tc] of alvo) {
        const el = this.pecas.get(sq);
        if (el && el.dataset.tipo === tc) { sobraram.delete(sq); } else novas.push([sq, tc]);
      }
      // 2) as que mudaram de casa são "reaproveitadas" (para animar)
      const pecasNovas = new Map();
      for (const [sq, el] of this.pecas) if (!sobraram.has(sq)) pecasNovas.set(sq, el);
      for (const [sq, tc] of novas) {
        let melhor = null, dist = 1e9;
        for (const [oldSq, el] of sobraram) {
          if (el.dataset.tipo !== tc) continue;
          const d = Math.abs(oldSq.charCodeAt(0) - sq.charCodeAt(0)) + Math.abs(oldSq[1] - sq[1]);
          if (d < dist) { dist = d; melhor = oldSq; }
        }
        if (melhor && animar) {
          const el = sobraram.get(melhor); sobraram.delete(melhor);
          el.classList.remove('sem-anim');
          this.posicionar(el, sq);
          pecasNovas.set(sq, el);
        } else {
          const el = this.criarPeca(tc, sq);
          pecasNovas.set(sq, el);
        }
      }
      // 3) o que sobrou saiu do tabuleiro (capturada ou desfeita)
      for (const el of sobraram.values()) el.remove();
      this.pecas = pecasNovas;
      this.pecas.forEach((el, sq) => { el.style.zIndex = ''; });
    }

    /* ----- marcações (último lance, casa selecionada, xeque, bolinhas) ----- */
    desenharMarcas() {
      this.camadaMarcas.innerHTML = '';
      const add = (sq, cls) => {
        const d = document.createElement('div');
        d.className = 'marca ' + cls;
        const p = this.posicao(sq);
        d.style.left = p.x + '%'; d.style.top = p.y + '%';
        this.camadaMarcas.appendChild(d);
        return d;
      };
      if (this.ultimo) { add(this.ultimo.from, 'ultimo'); add(this.ultimo.to, 'ultimo'); }
      this.destaques.forEach(d => add(d.sq, d.cls));
      if (this.casaXeque) add(this.casaXeque, 'xeque');
      if (this.selecionada) {
        add(this.selecionada, 'selecionada');
        if (this.mostrarLegais) for (const l of this.op.lancesDe(this.selecionada)) add(l.to, l.captura ? 'captura' : 'ponto');
      }
    }

    /* ----- setas de dica ----- */
    desenharSetas(lista) {
      this._setas = lista;
      this.svg.innerHTML = '';
      if (!lista || !lista.length) return;
      const defs = document.createElementNS(NS, 'defs');
      defs.innerHTML = '<marker id="ponta" markerWidth="4" markerHeight="4" refX="2.2" refY="2" orient="auto"><path d="M0,0 L4,2 L0,4 z" fill="rgba(129,182,76,.95)"/></marker>';
      this.svg.appendChild(defs);
      for (const s of lista) {
        const a = this.posicao(s.de), b = this.posicao(s.para);
        const x1 = a.x * 8 + 50, y1 = a.y * 8 + 50, x2 = b.x * 8 + 50, y2 = b.y * 8 + 50;
        const dx = x2 - x1, dy = y2 - y1, len = Math.hypot(dx, dy) || 1;
        const rec = 26; // recua um pouco para a ponta não cobrir a casa
        const l = document.createElementNS(NS, 'line');
        l.setAttribute('x1', x1); l.setAttribute('y1', y1);
        l.setAttribute('x2', x2 - dx / len * rec); l.setAttribute('y2', y2 - dy / len * rec);
        l.setAttribute('stroke', 'rgba(129,182,76,.85)'); l.setAttribute('stroke-width', 16);
        l.setAttribute('stroke-linecap', 'round'); l.setAttribute('marker-end', 'url(#ponta)');
        this.svg.appendChild(l);
      }
    }
    limparSetas() { this._setas = null; this.svg.innerHTML = ''; }

    /* ----- selo do treinador (ex.: "??" no canto da casa) ----- */
    mostrarSelo(sq, simbolo, cor) {
      this._selo = { sq, simbolo, cor };
      this.reposicionarSelos();
    }
    reposicionarSelos() {
      this.camadaSelos.innerHTML = '';
      if (!this._selo) return;
      const { sq, simbolo, cor } = this._selo;
      const p = this.posicao(sq);
      const d = document.createElement('div');
      d.className = 'selo'; d.textContent = simbolo; d.style.background = cor;
      d.style.left = (p.x + 12.5) + '%'; d.style.top = p.y + '%';
      this.camadaSelos.appendChild(d);
    }
    limparSelo() { this._selo = null; this.camadaSelos.innerHTML = ''; }

    /* ----- interação ----- */
    selecionar(sq) {
      this.selecionada = sq;
      this.desenharMarcas();
    }
    desselecionar() { this.selecionada = null; this.desenharMarcas(); }

    aoApertar(e) {
      if (e.button === 2) { this.desselecionar(); return; }
      if (e.target.closest('.promocao')) return;
      const sq = this.casaNoPonto(e.clientX, e.clientY);
      if (!sq) return;
      // Já tem uma peça selecionada e clicou num destino legal -> move
      if (this.selecionada && this.selecionada !== sq) {
        const legal = this.op.lancesDe(this.selecionada).some(l => l.to === sq);
        if (legal) { const de = this.selecionada; this.selecionada = null; this.desenharMarcas(); this.op.aoMover(de, sq); return; }
      }
      const el = this.pecas.get(sq);
      if (el && this.op.podeSelecionar(sq, el.dataset.tipo)) {
        const jaSel = this.selecionada === sq;
        this.selecionada = sq;
        this.desenharMarcas();
        // começa a arrastar
        e.preventDefault();
        this.arrastando = { sq, el, jaSel, moveu: false, x0: e.clientX, y0: e.clientY };
        el.classList.add('arrastando');
        this.moverArrasto(e.clientX, e.clientY);
        try { this.raiz.setPointerCapture(e.pointerId); } catch (err) { /* ok */ }
      } else {
        this.desselecionar();
      }
    }
    moverArrasto(x, y) {
      const a = this.arrastando; if (!a) return;
      const rc = this.raiz.getBoundingClientRect();
      const tam = rc.width / 8;
      a.el.style.left = ((x - rc.left - tam / 2) / rc.width * 100) + '%';
      a.el.style.top = ((y - rc.top - tam / 2) / rc.height * 100) + '%';
    }
    aoMexer(e) {
      const a = this.arrastando; if (!a) return;
      if (Math.hypot(e.clientX - a.x0, e.clientY - a.y0) > 4) a.moveu = true;
      this.moverArrasto(e.clientX, e.clientY);
    }
    aoSoltar(e) {
      const a = this.arrastando; if (!a) return;
      this.arrastando = null;
      a.el.classList.remove('arrastando');
      const destino = this.casaNoPonto(e.clientX, e.clientY);
      // volta a peça para a casa dela (se o lance for válido, o app atualiza o tabuleiro)
      a.el.classList.add('sem-anim'); this.posicionar(a.el, a.sq);
      requestAnimationFrame(() => a.el.classList.remove('sem-anim'));
      if (a.moveu && destino && destino !== a.sq) {
        const legal = this.op.lancesDe(a.sq).some(l => l.to === destino);
        if (legal) { this.selecionada = null; this.desenharMarcas(); this.op.aoMover(a.sq, destino, true); return; }
        this.desselecionar();
      } else if (!a.moveu && a.jaSel) {
        this.desselecionar();   // clicou de novo na mesma peça: desmarca
      }
    }

    /* ----- escolha de peça na promoção ----- */
    mostrarPromocao(cor, sqDestino, escolher, cancelar) {
      this.fecharPromocao();
      const p = this.posicao(sqDestino);
      const caixa = document.createElement('div');
      caixa.className = 'promocao';
      const naBase = p.lin > 3;     // se o destino está embaixo, a caixa sobe
      caixa.style.left = p.x + '%';
      caixa.style.top = (naBase ? p.y - 37.5 : p.y) + '%';
      for (const t of ['q', 'n', 'r', 'b']) {
        const b = document.createElement('button');
        b.style.backgroundImage = 'url("' + window.PECAS[cor + t] + '")';
        b.title = { q: 'Dama', n: 'Cavalo', r: 'Torre', b: 'Bispo' }[t];
        b.onclick = (ev) => { ev.stopPropagation(); this.fecharPromocao(); escolher(t); };
        caixa.appendChild(b);
      }
      const fundo = document.createElement('div');
      fundo.className = 'promocao-fundo';
      fundo.onclick = () => { this.fecharPromocao(); if (cancelar) cancelar(); };
      this.raiz.append(fundo, caixa);
      this._promo = [fundo, caixa];
    }
    fecharPromocao() { if (this._promo) { this._promo.forEach(e => e.remove()); this._promo = null; } }

    // Tudo de uma vez a partir do estado do jogo
    atualizar({ tab, ultimo, casaXeque, animar }) {
      this.selecionada = null;
      this.ultimo = ultimo || null;
      this.casaXeque = casaXeque || null;
      this.definir(tab, animar);
      this.desenharMarcas();
    }
  }

  window.Tabuleiro = Tabuleiro;
})();
