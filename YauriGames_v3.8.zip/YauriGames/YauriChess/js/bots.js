/* bots.js — os adversários do computador, do iniciante ao nível máximo.
   Como a força é ajustada:
   - Bots fracos (elo < 1350): o Stockfish olha só alguns lances à frente (profundidade baixa)
     e escolhe entre os melhores candidatos com sorteio. Quanto maior "temp", mais erros.
   - Bots fortes (elo >= 1350): usam o limitador oficial de força do Stockfish (UCI_Elo).
   - "Máximo": Stockfish sem limite. */
window.BOTS = [
  { id: 'pipoca', nome: 'Pipoca', elo: 400, avatar: '🐣', desc: 'Acabou de aprender como as peças andam.',
    cfg: { profundidade: 1, multipv: 8, temp: 450 },
    falas: { inicio: ['Piu! Vamos jogar?', 'Eu sei mexer o cavalo… acho.'], vitoria: ['Ganhei?! Piu!'], derrota: ['Ah, você é bom demais!'], empate: ['Empatou! Legal!'] } },
  { id: 'dona-maria', nome: 'Dona Maria', elo: 700, avatar: '👵', desc: 'Joga xadrez na pracinha todo domingo.',
    cfg: { profundidade: 1, multipv: 8, temp: 260 },
    falas: { inicio: ['Vem, meu bem, vamos jogar.'], vitoria: ['Tome um cafezinho, querido.'], derrota: ['Você joga bem, hein!'], empate: ['Boa partida, meu filho.'] } },
  { id: 'tonhao', nome: 'Tonhão', elo: 1000, avatar: '🐻', desc: 'Gosta de atacar sem pensar muito.',
    cfg: { profundidade: 2, multipv: 6, temp: 150 },
    falas: { inicio: ['Bora que bora!'], vitoria: ['Rolou o baile!'], derrota: ['Quero revanche!'], empate: ['Hmm, empate.'] } },
  { id: 'julia', nome: 'Júlia', elo: 1300, avatar: '🦊', desc: 'Esperta, mas ainda cai em algumas armadilhas.',
    cfg: { profundidade: 3, multipv: 6, temp: 80 },
    falas: { inicio: ['Boa sorte!'], vitoria: ['GG!'], derrota: ['Boa jogada, parabéns!'], empate: ['Empate justo.'] } },
  { id: 'guizin', nome: 'Guizin', elo: 1450, avatar: '😎', desc: 'O criador dos jogos. Malandro oficializado pelo guetto.',
    cfg: { elo: 1450, tempoMs: 500 },
    falas: { inicio: ['Bora, nego! Guilherme Yauri não perdoa.', 'Cheguei no IFSP Catanduva e já tô ganhando.'], vitoria: ['Nego frutinha não passa de mim!', 'Senhor Supremo do Universo vence de novo.'], derrota: ['Perdi?! Nem eu acredito… respeito, malandro.', 'Você é fera, tem que ser oficializado pelo guetto.'], empate: ['Empate… foi por pouco, nego.'] } },
  { id: 'carlos', nome: 'Professor Carlos', elo: 1600, avatar: '🧔', desc: 'Joga com calma e sabe a teoria.',
    cfg: { elo: 1600, tempoMs: 600 },
    falas: { inicio: ['Vamos aprender juntos.'], vitoria: ['Revise essa partida depois.'], derrota: ['Excelente! Você aprendeu bem.'], empate: ['Resultado equilibrado.'] } },
  { id: 'rafa', nome: 'Capitã Rafa', elo: 1900, avatar: '🦅', desc: 'Agressiva e boa de tática.',
    cfg: { elo: 1900, tempoMs: 700 },
    falas: { inicio: ['Prepare-se!'], vitoria: ['Xeque-mate no seu plano!'], derrota: ['Respeito! Jogou muito.'], empate: ['Foi duro, mas empatamos.'] } },
  { id: 'yuri', nome: 'Mestre Yuri', elo: 2200, avatar: '🐉', desc: 'Nível de mestre. Não perdoa erros.',
    cfg: { elo: 2200, tempoMs: 900 },
    falas: { inicio: ['Mostre o que sabe.'], vitoria: ['Estude os finais.'], derrota: ['Impressionante.'], empate: ['Bom empate.'] } },
  { id: 'helena', nome: 'Dra. Helena', elo: 2500, avatar: '🧠', desc: 'Calcula variações longas com precisão.',
    cfg: { elo: 2500, tempoMs: 1000 },
    falas: { inicio: ['Concentração.'], vitoria: ['Previsível.'], derrota: ['Raríssimo. Parabéns.'], empate: ['Defesa sólida.'] } },
  { id: 'tita', nome: 'Titã', elo: 2800, avatar: '🤖', desc: 'Praticamente um supercomputador.',
    cfg: { elo: 2800, tempoMs: 1200 },
    falas: { inicio: ['Iniciando partida.'], vitoria: ['Processamento concluído.'], derrota: ['Erro… impossível.'], empate: ['Resultado: empate.'] } },
  { id: 'maximo', nome: 'Máximo', elo: 3200, avatar: '👑', desc: 'Força total do Stockfish. Boa sorte!',
    cfg: { tempoMs: 1500 },
    falas: { inicio: ['Não há esperança.'], vitoria: ['Como esperado.'], derrota: ['Como?!'], empate: ['Hmm.'] } },
  { id: 'supremo', nome: 'Senhor Supremo', elo: 3200, avatar: '👑', desc: 'CHEFE FINAL. Guilherme Yauri em forma suprema.',
    cfg: { tempoMs: 2500 },
    falas: { inicio: ['Eu sou o Senhor Supremo do Universo. Ajoelhe.', 'Ninguém vence Guilherme Yauri.'], vitoria: ['Previsível. Voltem quando forem oficializados.'], derrota: ['Impossível… você é o novo Senhor Supremo?!'], empate: ['Nem o universo decide quem é maior.'] } },
];

// Escolhe o lance do bot. Devolve a notação UCI (ex.: "e2e4").
window.escolherLanceBot = async function (motor, bot, fen, tempoRestanteMs) {
  const cfg = bot.cfg;
  if (cfg.elo || cfg.tempoMs) {
    // bot forte: limitador de força (ou força total)
    let tms = cfg.tempoMs || 800;
    if (tempoRestanteMs != null) tms = Math.max(150, Math.min(tms, tempoRestanteMs / 25));
    const r = await motor.analisar(fen, { tempoMs: tms, elo: cfg.elo || 0 });
    return r.melhor;
  }
  // bot fraco: profundidade baixa + sorteio entre candidatos
  const r = await motor.analisar(fen, { profundidade: cfg.profundidade, multipv: cfg.multipv });
  const ls = r.linhas.filter(l => l.mov);
  if (!ls.length) return r.melhor;
  const pont = (l) => l.mate != null ? (l.mate > 0 ? 10000 - l.mate : -10000 - l.mate) : l.cp;
  const topo = pont(ls[0]);
  const pesos = ls.map(l => Math.exp(-Math.max(0, topo - pont(l)) / cfg.temp));
  let soma = pesos.reduce((a, b) => a + b, 0), x = Math.random() * soma;
  for (let i = 0; i < ls.length; i++) { x -= pesos[i]; if (x <= 0) return ls[i].mov; }
  return ls[0].mov;
};
