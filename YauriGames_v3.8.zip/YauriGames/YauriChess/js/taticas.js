/* ============================================================
   taticas.js — treino de táticas: problemas prontos (mate em 1, mate em 2,
   ganhar material). Os problemas foram escolhidos e conferidos pelo Stockfish.
   ============================================================ */

(function () {
  const { Chess } = window.ChessLib;
  const App = window.App;
  const $ = App.$;

  let tab = null, P = null, idx = 0, chess = null, passo = 0, travado = false, dicaPasso = 0, resolvido = false;

  const DICAS = {
    'Mate em 1': 'Procure um xeque que o rei não consiga evitar.',
    'Mate em 2': 'Procure um xeque ou um lance que ameace mate logo em seguida.',
    'Ganhe material': 'Procure uma captura, um garfo ou uma ameaça dupla.',
  };
  const nomeLado = (c) => (c === 'w' ? 'as brancas' : 'as pretas');

  function iniciarUI() {
    tab = new window.Tabuleiro($('tab-tatica'), {
      lancesDe: (sq) => {
        const v = {};
        for (const m of chess.moves({ square: sq, verbose: true })) v[m.to] = { to: m.to, captura: !!m.captured };
        return Object.values(v);
      },
      podeSelecionar: (sq, tc) => !travado && !resolvido && chess && tc[0] === chess.turn(),
      aoMover: tentar,
    });
    $('t-prox').onclick = () => carregar((idx + 1) % window.PROBLEMAS.length);
    $('t-dica').onclick = dica;
    $('t-solucao').onclick = solucao;
  }

  function feitos() { return App.ler('taticas', { feitos: [] }).feitos; }

  function entrar() {
    if (!P) {
      const f = feitos();
      let i = window.PROBLEMAS.findIndex((_, k) => !f.includes(k));
      carregar(i < 0 ? 0 : i);
    }
  }

  function carregar(i) {
    idx = i; P = window.PROBLEMAS[i];
    chess = new Chess(P.fen);
    passo = 0; travado = false; dicaPasso = 0; resolvido = false;
    tab.limparSetas(); tab.limparSelo(); tab.destaques = [];
    tab.definirOrientacao(chess.turn());
    tab.atualizar({ tab: chess.board(), ultimo: null, casaXeque: null, animar: false });
    $('t-tema').textContent = '🧩 ' + P.tema;
    $('t-vez').textContent = 'Jogam ' + nomeLado(chess.turn()) + '. Encontre o melhor lance!';
    feedback('', '');
    $('t-prog').textContent = `Problema ${i + 1} de ${window.PROBLEMAS.length} · Resolvidos: ${feitos().length}`;
  }
  function feedback(txt, cls) { const f = $('t-feedback'); f.textContent = txt || ' '; f.className = 'feedback ' + (cls || ''); }

  function tentar(de, para) {
    const cand = chess.moves({ square: de, verbose: true }).filter(m => m.to === para);
    if (!cand.length) return;
    if (cand[0].promotion) {
      travado = true;
      tab.mostrarPromocao(chess.turn(), para, (p) => { travado = false; verificar(de, para, p); }, () => { travado = false; tab.atualizar({ tab: chess.board(), ultimo: null, animar: false }); });
      return;
    }
    verificar(de, para, undefined);
  }

  function verificar(de, para, promo) {
    const uci = de + para + (promo || '');
    const fen0 = chess.fen();
    const m = chess.move({ from: de, to: para, promotion: promo });
    const mate = chess.isCheckmate();
    let certo;
    if (passo === 0) certo = mate || Object.prototype.hasOwnProperty.call(P.sols, uci);
    else certo = mate;      // segundo passo (mate em 2): qualquer lance que dê mate
    window.Som[m.captured ? 'capturar' : 'mover']();
    tab.limparSetas(); tab.destaques = [];
    tab.atualizar({ tab: chess.board(), ultimo: { from: de, to: para }, casaXeque: chess.inCheck() ? rei(chess.turn()) : null, animar: true });
    if (!certo) {
      travado = true;
      feedback('Não é o lance certo. Tente de novo!', 'ruim');
      window.Som.erro();
      setTimeout(() => { chess.load(fen0); tab.atualizar({ tab: chess.board(), ultimo: null, animar: true }); travado = false; }, 800);
      return;
    }
    if (mate) return resolver();
    if (P.tema === 'Mate em 2' && passo === 0) {
      // o adversário responde e o jogador precisa dar o mate
      travado = true;
      const resp = P.sols[uci];
      feedback('Boa! Agora termine com o xeque-mate.', 'ok');
      setTimeout(() => {
        if (resp) {
          const r = chess.move({ from: resp.slice(0, 2), to: resp.slice(2, 4), promotion: resp[4] });
          window.Som[r.captured ? 'capturar' : 'mover']();
          tab.atualizar({ tab: chess.board(), ultimo: { from: r.from, to: r.to }, casaXeque: chess.inCheck() ? rei(chess.turn()) : null, animar: true });
        }
        passo = 1; travado = false;
      }, 650);
      return;
    }
    resolver();
  }
  function rei(cor) { for (const l of chess.board()) for (const p of l) if (p && p.type === 'k' && p.color === cor) return p.square; return null; }

  function resolver() {
    resolvido = true; travado = true;
    feedback('✓ Correto! Muito bem!', 'ok');
    window.Som.xeque();
    const d = App.ler('taticas', { feitos: [] });
    if (!d.feitos.includes(idx)) { d.feitos.push(idx); App.salvar('taticas', d); }
    $('t-prog').textContent = `Problema ${idx + 1} de ${window.PROBLEMAS.length} · Resolvidos: ${d.feitos.length}`;
  }

  function primeiroLance() {
    // no passo 1 (mate em 2), a solução é qualquer lance que dê mate
    if (passo === 1) {
      for (const m of chess.moves({ verbose: true })) { const c = new Chess(chess.fen()); c.move(m.san); if (c.isCheckmate()) return m.from + m.to + (m.promotion || ''); }
    }
    return Object.keys(P.sols)[0];
  }
  function dica() {
    if (resolvido) return;
    const uci = primeiroLance();
    if (dicaPasso === 0) {
      dicaPasso = 1; feedback('💡 ' + DICAS[P.tema], '');
      tab.destaques = [{ sq: uci.slice(0, 2), cls: 'dica' }]; tab.desenharMarcas();
    } else {
      feedback('💡 Mexa a peça marcada para a casa indicada.', '');
      tab.desenharSetas([{ de: uci.slice(0, 2), para: uci.slice(2, 4) }]);
    }
  }
  function solucao() {
    if (resolvido) return;
    const uci = primeiroLance();
    const san = window.Coach.sanDe(chess.fen(), uci);
    tab.desenharSetas([{ de: uci.slice(0, 2), para: uci.slice(2, 4) }]);
    feedback('Solução: ' + san + (P.tema === 'Mate em 2' && passo === 0 ? ' (depois dê o mate)' : ''), '');
  }

  window.Taticas = { iniciarUI, entrar };
})();
