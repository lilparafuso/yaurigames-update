/* ============================================================
   coach.js — o TREINADOR (sem IA externa!)
   ------------------------------------------------------------
   Como funciona:
   1) O Stockfish avalia cada posição (quem está melhor e qual o melhor lance).
   2) Comparando a avaliação ANTES e DEPOIS do seu lance, a gente descobre
      se foi um lance brilhante, bom, erro, capivarada etc.
   3) Regras simples (peça pendurada, garfo, cravada, xeque...) explicam
      o motivo com frases em português.
   ============================================================ */

(function () {
  const { Chess } = window.ChessLib;

  const VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };
  const NOME = { p: 'peão', n: 'cavalo', b: 'bispo', r: 'torre', q: 'dama', k: 'rei' };
  const FEM = { p: false, n: false, b: false, r: true, q: true, k: false };
  const art = (t) => (FEM[t] ? 'a' : 'o');          // "o cavalo" / "a dama"
  const dele = (t) => (FEM[t] ? 'sua' : 'seu');     // "seu cavalo" / "sua dama"
  const sorteio = (lista) => lista[Math.floor(Math.random() * lista.length)];
  const maiuscula = (s) => s.charAt(0).toUpperCase() + s.slice(1);

  /* ---------- Avaliação em "chance de vitória" ---------- */

  // Converte centipeões (100 = 1 peão) em chance de vitória de 0 a 100
  function winPct(cp) {
    return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1);
  }
  // Transforma uma linha do motor (cp ou mate) em um número único
  function pontuacao(linha) {
    if (!linha) return 0;
    if (linha.mate != null) {
      if (linha.mate === 0) return -10000;
      return linha.mate > 0 ? 10000 - linha.mate : -10000 - linha.mate;
    }
    return linha.cp;
  }
  // Mesma ideia, mas visto pelas brancas (o motor sempre fala de quem joga)
  function pontuacaoBrancas(linha, fen) {
    const v = pontuacao(linha);
    return fen.split(' ')[1] === 'w' ? v : -v;
  }
  // Texto para a barra de avaliação (+1.3 / M3)
  function textoAval(pontBrancas) {
    if (Math.abs(pontBrancas) >= 9000) {
      const n = 10000 - Math.abs(pontBrancas);
      return (pontBrancas > 0 ? '' : '-') + 'M' + n;
    }
    const v = (pontBrancas / 100).toFixed(1);
    return (pontBrancas > 0 ? '+' : '') + v;
  }

  /* ---------- Analisador (com memória para não repetir contas) ---------- */

  class Analisador {
    constructor(motor) {
      this.motor = motor;
      this.cache = new Map();
      this.profundidade = 12;
    }
    chave(fen) { return fen.split(' ').slice(0, 4).join(' '); }

    // Devolve { linhas:[{mov,cp,mate,pv}], melhor, terminal }
    avaliar(fen) {
      const k = this.chave(fen);
      if (this.cache.has(k)) return this.cache.get(k);
      const c = new Chess(fen);
      let p;
      if (c.isGameOver()) {
        // Posição final: mate (quem joga perdeu) ou empate
        p = Promise.resolve({
          terminal: true, melhor: null,
          linhas: [{ mov: null, pv: [], cp: c.isCheckmate() ? null : 0, mate: c.isCheckmate() ? 0 : null }],
        });
      } else {
        p = this.motor.analisar(fen, { profundidade: this.profundidade, tempoMs: 1500, multipv: 2 });
      }
      this.cache.set(k, p);
      return p;
    }
    jaTem(fen) { return this.cache.has(this.chave(fen)); }
    limpar() { this.cache.clear(); }
  }

  /* ---------- Geometria do tabuleiro ---------- */

  const DIAG = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
  const RETAS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const CAVALO = [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]];
  const dentro = (a, b) => a >= 0 && a < 8 && b >= 0 && b < 8;
  const nomeCasa = (r, f) => 'abcdefgh'[f] + (8 - r);
  const posCasa = (sq) => [8 - parseInt(sq[1], 10), sq.charCodeAt(0) - 97]; // [linha, coluna]

  // Casas que uma peça (na casa sq) ataca. Retorna [[linha,coluna],...]
  function casasAtacadas(tab, sq) {
    const [r, f] = posCasa(sq);
    const p = tab[r][f];
    if (!p) return [];
    const res = [];
    const desliza = (dirs, longe) => {
      for (const [dr, df] of dirs) {
        let a = r + dr, b = f + df;
        while (dentro(a, b)) {
          res.push([a, b]);
          if (tab[a][b] || !longe) break;
          a += dr; b += df;
        }
      }
    };
    switch (p.type) {
      case 'n': for (const [dr, df] of CAVALO) if (dentro(r + dr, f + df)) res.push([r + dr, f + df]); break;
      case 'p': { const d = p.color === 'w' ? -1 : 1; for (const df of [-1, 1]) if (dentro(r + d, f + df)) res.push([r + d, f + df]); break; }
      case 'b': desliza(DIAG, true); break;
      case 'r': desliza(RETAS, true); break;
      case 'q': desliza(DIAG.concat(RETAS), true); break;
      case 'k': desliza(DIAG.concat(RETAS), false); break;
    }
    return res;
  }

  // Peças de uma cor que estão em perigo (atacadas e sem defesa, ou atacadas por peça menor)
  function pecasEmPerigo(c, cor) {
    const outra = cor === 'w' ? 'b' : 'w';
    const lista = [];
    for (const linha of c.board()) for (const p of linha) {
      if (!p || p.color !== cor || p.type === 'k') continue;
      const atac = c.attackers(p.square, outra);
      if (!atac.length) continue;
      const def = c.attackers(p.square, cor);
      const menor = Math.min(...atac.map(s => VAL[c.get(s).type]));
      if (!def.length) lista.push({ sq: p.square, tipo: p.type, pendurada: true });
      else if (menor < VAL[p.type]) lista.push({ sq: p.square, tipo: p.type, pendurada: false });
    }
    return lista.sort((a, b) => VAL[b.tipo] - VAL[a.tipo]);
  }

  // Garfo: a peça que acabou de mover ataca 2+ peças valiosas/desprotegidas?
  function acharGarfo(c, sq, cor) {
    const tab = c.board();
    const eu = c.get(sq);
    if (!eu || eu.type === 'k') return null;
    const alvos = [];
    for (const [a, b] of casasAtacadas(tab, sq)) {
      const q = tab[a][b];
      if (!q || q.color === cor) continue;
      const s = nomeCasa(a, b);
      if (q.type === 'k') { alvos.push({ sq: s, tipo: 'k' }); continue; }
      if (q.type === 'p') continue;
      const protegido = c.attackers(s, q.color).length > 0;
      if (VAL[q.type] > VAL[eu.type] || !protegido) alvos.push({ sq: s, tipo: q.type });
    }
    return alvos.length >= 2 ? alvos : null;
  }

  // Cravada/espeto: bispo, torre ou dama olhando para duas peças inimigas na mesma linha
  function acharCravada(c, sq, cor) {
    const tab = c.board();
    const [r, f] = posCasa(sq);
    const eu = tab[r][f];
    if (!eu || !['b', 'r', 'q'].includes(eu.type)) return null;
    const dirs = eu.type === 'b' ? DIAG : eu.type === 'r' ? RETAS : DIAG.concat(RETAS);
    for (const [dr, df] of dirs) {
      let a = r + dr, b = f + df, A = null;
      while (dentro(a, b)) {
        const q = tab[a][b];
        if (q) {
          if (q.color === cor) break;
          if (!A) A = { q, sq: nomeCasa(a, b) };
          else {
            if (A.q.type !== 'p' && (q.type === 'k' || VAL[q.type] > VAL[A.q.type])) return { tipo: 'cravada', frente: A, atras: { q, sq: nomeCasa(a, b) } };
            if (VAL[A.q.type] > VAL[q.type] && q.type !== 'p') return { tipo: 'espeto', frente: A, atras: { q, sq: nomeCasa(a, b) } };
            break;
          }
        }
        a += dr; b += df;
      }
    }
    return null;
  }

  // O lance entrega material de propósito (sacrifício)?
  function ehSacrificio(c0, mov) {
    const c = new Chess(c0.fen());
    const m = c.move({ from: mov.from, to: mov.to, promotion: mov.promotion });
    if (!m || m.piece === 'p' || m.piece === 'k') return false;
    const outra = m.color === 'w' ? 'b' : 'w';
    const atac = c.attackers(m.to, outra);
    if (!atac.length) return false;
    const menor = Math.min(...atac.map(s => VAL[c.get(s).type]));
    const ganho = m.captured ? VAL[m.captured] : 0;
    const def = c.attackers(m.to, m.color).length > 0;
    const saldo = ganho - (def ? Math.max(0, VAL[m.piece] - menor) : VAL[m.piece]);
    return saldo <= -2;
  }

  /* ---------- Descrever um lance em português ---------- */

  // Explica o que um lance faz. Usado nas dicas e nos comentários.
  function descreverLance(fen, uci, linhaMotor) {
    const c = new Chess(fen);
    let m;
    try { m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] }); } catch (e) { return ''; }
    if (!m) return '';
    const cor = m.color;
    const antes = new Chess(fen);
    const frases = [];
    const numero = parseInt(fen.split(' ')[5], 10) || 1;

    if (m.san.endsWith('#')) return 'dá xeque-mate!';
    if (linhaMotor && linhaMotor.mate > 0 && linhaMotor.mate <= 6) frases.push('leva a um xeque-mate forçado em ' + linhaMotor.mate + (linhaMotor.mate === 1 ? ' lance' : ' lances'));

    if (m.flags.includes('k') || m.flags.includes('q')) frases.push('faz o roque: protege o rei e coloca a torre em jogo');
    if (m.promotion) frases.push('promove o peão a ' + NOME[m.promotion]);
    if (m.captured) {
      const defendida = antes.attackers(m.to, cor === 'w' ? 'b' : 'w').length > 0;
      let t = 'captura ' + art(m.captured) + ' ' + NOME[m.captured] + ' em ' + m.to;
      if (!defendida) t += ', que estava sem proteção';
      else if (VAL[m.captured] > VAL[m.piece]) t += ', ganhando material';
      else if (VAL[m.captured] === VAL[m.piece]) t += ' (troca de peças iguais)';
      frases.push(t);
    }
    if (m.san.endsWith('+') && !m.captured) frases.push('dá xeque ao rei');
    else if (m.san.endsWith('+')) frases.push('e ainda dá xeque');

    const garfo = acharGarfo(c, m.to, cor);
    if (garfo) frases.push('faz um garfo: ataca ' + garfo.map(g => art(g.tipo) + ' ' + NOME[g.tipo] + ' em ' + g.sq).join(' e '));
    const crav = acharCravada(c, m.to, cor);
    if (crav && !garfo) {
      if (crav.tipo === 'cravada') frases.push('crava ' + art(crav.frente.q.type) + ' ' + NOME[crav.frente.q.type] + ' em ' + crav.frente.sq + ' contra ' + art(crav.atras.q.type) + ' ' + NOME[crav.atras.q.type]);
      else frases.push('ataca ' + art(crav.frente.q.type) + ' ' + NOME[crav.frente.q.type] + ' em ' + crav.frente.sq + ', e atrás dela está ' + art(crav.atras.q.type) + ' ' + NOME[crav.atras.q.type]);
    }

    // Tirar uma peça do ataque / proteger peça em perigo
    const perigoAntes = pecasEmPerigo(new Chess(fen), cor);
    const perigoDepois = pecasEmPerigo(c, cor);
    if (!m.captured && perigoAntes.length) {
      const p0 = perigoAntes[0];
      if (p0.sq === m.from && !perigoDepois.some(x => x.sq === m.to)) frases.push('tira ' + art(p0.tipo) + ' ' + NOME[p0.tipo] + ' de ' + p0.sq + ' do ataque');
      else if (!perigoDepois.some(x => x.sq === p0.sq)) frases.push('protege ' + dele(p0.tipo) + ' ' + NOME[p0.tipo] + ' em ' + p0.sq);
    }

    // Ameaças criadas: a peça movida ataca algo desprotegido?
    if (!garfo && !m.captured) {
      const tab = c.board();
      const alvos = [];
      for (const [a, b] of casasAtacadas(tab, m.to)) {
        const q = tab[a][b];
        if (!q || q.color === cor || q.type === 'k') continue;
        const s = nomeCasa(a, b);
        if (!c.attackers(s, q.color).length && q.type !== 'p') alvos.push({ s, t: q.type });
        else if (VAL[q.type] > VAL[m.piece] && q.type !== 'p') alvos.push({ s, t: q.type });
      }
      if (alvos.length && !frases.some(f => f.includes('xeque'))) frases.push('ameaça ' + art(alvos[0].t) + ' ' + NOME[alvos[0].t] + ' em ' + alvos[0].s);
    }

    // Princípios gerais da abertura
    if (!frases.length) {
      if (numero <= 12) {
        if ((m.piece === 'n' || m.piece === 'b') && (m.from[1] === '1' || m.from[1] === '8')) frases.push('desenvolve ' + art(m.piece) + ' ' + NOME[m.piece] + ' para uma casa ativa');
        else if (m.piece === 'p' && ['d4', 'e4', 'd5', 'e5'].includes(m.to)) frases.push('ocupa o centro com um peão');
        else if (m.piece === 'p' && ['c4', 'c5', 'f4', 'f5'].includes(m.to)) frases.push('luta pelo centro');
        else if (m.piece === 'r' && ['d', 'e'].includes(m.to[0])) frases.push('coloca a torre numa coluna central');
      }
      if (!frases.length) {
        if (m.piece === 'k') frases.push('melhora a segurança do rei');
        else if (m.piece === 'p') frases.push('avança o peão para ganhar espaço');
        else if (m.piece === 'r') frases.push('ativa a torre');
        else frases.push('melhora a posição ' + (FEM[m.piece] ? 'da ' : 'do ') + NOME[m.piece]);
      }
    }
    return frases.join(', ');
  }

  /* ---------- Classificação dos lances ---------- */

  const CLASSES = {
    brilhante:  { nome: 'Brilhante',  simbolo: '!!', cor: '#26c2a3' },
    otimo:      { nome: 'Ótimo',      simbolo: '!',  cor: '#749bbf' },
    melhor:     { nome: 'Melhor',     simbolo: '★',  cor: '#81b64c' },
    teoria:     { nome: 'Teoria',     simbolo: '📖', cor: '#a88865' },
    bom:        { nome: 'Bom',        simbolo: '✓',  cor: '#95b776' },
    imprecisao: { nome: 'Imprecisão', simbolo: '?!', cor: '#f7c631' },
    erro:       { nome: 'Erro',       simbolo: '?',  cor: '#e58f2a' },
    capivarada: { nome: 'Capivarada', simbolo: '??', cor: '#ca3431' },
  };

  // Compara a posição antes e depois do lance e dá a nota
  function classificar({ c0, mov, antes, depois, livro }) {
    const mel = antes.linhas[0];
    const eBest = pontuacao(mel);
    const eAfter = -pontuacao(depois.linhas[0]);
    const wBest = winPct(eBest), wAfter = winPct(eAfter);
    const perda = Math.max(0, wBest - wAfter);
    const uci = mov.from + mov.to + (mov.promotion || '');
    const ehMelhor = mel && mel.mov === uci;

    let classe;
    if (ehMelhor || perda <= 0.4) classe = 'melhor';
    else if (perda <= 5) classe = 'bom';
    else if (perda <= 10) classe = 'imprecisao';
    else if (perda <= 20) classe = 'erro';
    else classe = 'capivarada';

    // Em posições já decididas, não pune tanto
    if (['imprecisao', 'erro', 'capivarada'].includes(classe)) {
      if (wBest >= 93 && wAfter >= 75) classe = 'bom';
      else if (wBest <= 7 && wAfter <= 12) classe = 'bom';
    }
    if (ehMelhor || perda <= 1) {
      const seg = antes.linhas[1];
      if (seg && ehMelhor) {
        const difSeg = wBest - winPct(pontuacao(seg));
        if (difSeg >= 12 && wBest > 20 && wBest < 97) classe = 'otimo';
        if (mel.mate > 0 && seg.mate == null && mel.mate <= 6) classe = 'otimo';
      }
      if (wBest < 92 && wAfter > 45 && ehSacrificio(c0, mov)) classe = 'brilhante';
    }
    if (livro && ['melhor', 'bom'].includes(classe)) classe = 'teoria';

    const acc = Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * perda) - 3.1669));
    return { classe, perda, wBest, wAfter, acc, uciMelhor: mel ? mel.mov : null };
  }

  /* ---------- Frases do treinador ---------- */

  const FRASES = {
    brilhante: [
      '{san} é um lance BRILHANTE! Você entregou material, mas o motor confirma que compensa.',
      'Que lance! {san} é um sacrifício brilhante.',
    ],
    otimo: [
      '{san} é um ótimo lance, quase o único que mantém sua posição forte.',
      'Boa descoberta! {san} era difícil de achar.',
      '{san}: ótimo lance, exatamente o que a posição pedia.',
    ],
    melhor: [
      '{san} é o melhor lance da posição.',
      '{san}: é exatamente o que o motor jogaria.',
      'Perfeito! {san} é o lance mais forte aqui.',
    ],
    teoria: [
      '{san} é um lance de teoria da abertura{abertura}.',
      'Lance de livro: {san}{abertura}.',
    ],
    bom: [
      '{san} é um bom lance.',
      '{san}: lance sólido.',
      'Bom lance! {san} mantém a posição saudável.',
    ],
    imprecisao: [
      '{san} é uma imprecisão.',
      '{san} não é ruim, mas dá para melhorar.',
    ],
    erro: [
      '{san} é um erro.',
      'Opa, {san} piora sua posição.',
    ],
    capivarada: [
      '{san} é uma capivarada!',
      'Ixi… {san} é uma capivarada séria.',
      'Cuidado! {san} joga a posição fora.',
    ],
  };

  // Monta o texto do treinador para um lance já classificado.
  // ctx: { fenAntes, mov, antes, depois, nota, abertura, souEu }
  function comentarLance(ctx) {
    const { fenAntes, mov, antes, depois, nota } = ctx;
    const c0 = new Chess(fenAntes);
    const c1 = new Chess(fenAntes); c1.move({ from: mov.from, to: mov.to, promotion: mov.promotion });
    const san = mov.san;
    const cor = mov.color;
    const partes = [];

    let abert = ctx.abertura ? ': ' + ctx.abertura : '';
    partes.push(sorteio(FRASES[nota.classe]).replace('{san}', san).replace('{abertura}', abert));

    const melhorSan = nota.uciMelhor ? sanDe(fenAntes, nota.uciMelhor) : null;
    const ruins = ['imprecisao', 'erro', 'capivarada'];

    if (ruins.includes(nota.classe)) {
      // Por que foi ruim?
      const resp = depois.linhas[0];
      const respMov = resp && resp.mov;
      const mateContra = resp && resp.mate != null && resp.mate > 0 && resp.mate <= 5;
      if (mateContra) partes.push('Agora o adversário tem xeque-mate em ' + resp.mate + (resp.mate === 1 ? ' lance' : ' lances') + '.');
      else if (respMov) {
        const alvo = c1.get(respMov.slice(2, 4));
        if (alvo && alvo.color === cor) {
          const defendida = c1.attackers(respMov.slice(2, 4), cor).length > 0;
          partes.push('O adversário pode capturar ' + dele(alvo.type) + ' ' + NOME[alvo.type] + ' em ' + respMov.slice(2, 4) + (defendida ? ' (com troca desfavorável).' : ', que ficou sem proteção.'));
        }
      }
      const pend = pecasEmPerigo(c1, cor).filter(p => p.pendurada);
      if (pend.length && partes.length < 2) partes.push(maiuscula(dele(pend[0].tipo)) + ' ' + NOME[pend[0].tipo] + ' em ' + pend[0].sq + ' ficou pendurada.');
      if (melhorSan) {
        const desc = descreverLance(fenAntes, nota.uciMelhor, antes.linhas[0]);
        partes.push('O melhor era ' + melhorSan + (desc ? ', que ' + desc : '') + '.');
      }
      if (partes.length < 3) partes.push('Sua chance de vitória foi de ' + Math.round(nota.wBest) + '% para ' + Math.round(nota.wAfter) + '%.');
    } else if (['melhor', 'otimo', 'brilhante', 'bom'].includes(nota.classe)) {
      const desc = descreverLance(fenAntes, mov.from + mov.to + (mov.promotion || ''), antes.linhas[0] && antes.linhas[0].mov === (mov.from + mov.to + (mov.promotion || '')) ? antes.linhas[0] : null);
      if (desc) partes.push(maiuscula(desc) + '.');
      if (nota.classe === 'bom' && melhorSan && nota.perda > 1.5) partes.push('Mas ' + melhorSan + ' era um pouco mais forte.');
    }
    return partes.join(' ');
  }

  // Converte "e2e4" em "e4" a partir de uma posição
  function sanDe(fen, uci) {
    try {
      const c = new Chess(fen);
      const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
      return m ? m.san : uci;
    } catch (e) { return uci; }
  }

  // Alertas sobre o que o adversário está ameaçando (para a vez do jogador)
  function alertas(fen, analise) {
    const c = new Chess(fen);
    const cor = c.turn();
    const out = [];
    if (c.inCheck()) out.push('Você está em xeque!');
    const l0 = analise && analise.linhas && analise.linhas[0];
    if (l0 && l0.mate != null && l0.mate < 0 && l0.mate >= -3) out.push('Perigo: o adversário ameaça xeque-mate em ' + Math.abs(l0.mate) + (Math.abs(l0.mate) === 1 ? ' lance' : ' lances') + '. Defenda-se!');
    else if (l0 && l0.mate != null && l0.mate > 0 && l0.mate <= 4) out.push('Você tem xeque-mate em ' + l0.mate + (l0.mate === 1 ? ' lance' : ' lances') + '! Procure por ele.');
    const perigo = pecasEmPerigo(c, cor).filter(p => VAL[p.tipo] >= 3);
    if (perigo.length) {
      const p = perigo[0];
      out.push('Atenção: ' + dele(p.tipo) + ' ' + NOME[p.tipo] + ' em ' + p.sq + (p.pendurada ? ' está atacad' + (FEM[p.tipo] ? 'a' : 'o') + ' e sem proteção.' : ' pode ser trocad' + (FEM[p.tipo] ? 'a' : 'o') + ' por uma peça menor.'));
    }
    return out;
  }

  // Resumo da situação (para o painel)
  function resumoPosicao(pontBrancas, minhaCor) {
    const minha = minhaCor === 'w' ? pontBrancas : -pontBrancas;
    if (Math.abs(minha) >= 9000) return minha > 0 ? 'Você tem mate forçado!' : 'O adversário tem mate forçado.';
    if (minha > 500) return 'Você está com vantagem decisiva.';
    if (minha > 200) return 'Você está bem melhor.';
    if (minha > 60) return 'Você tem uma pequena vantagem.';
    if (minha >= -60) return 'A posição está equilibrada.';
    if (minha >= -200) return 'O adversário tem uma pequena vantagem.';
    if (minha >= -500) return 'O adversário está bem melhor.';
    return 'Sua posição está difícil.';
  }

  // Material no tabuleiro: { w, b }
  function material(c) {
    const m = { w: 0, b: 0 };
    for (const linha of c.board()) for (const p of linha) if (p && p.type !== 'k') m[p.color] += VAL[p.type];
    return m;
  }

  window.Coach = {
    Analisador, classificar, comentarLance, descreverLance, alertas, resumoPosicao,
    winPct, pontuacao, pontuacaoBrancas, textoAval, material, pecasEmPerigo, sanDe,
    CLASSES, VAL, NOME,
  };
})();
