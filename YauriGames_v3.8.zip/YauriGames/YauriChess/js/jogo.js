/* ============================================================
   jogo.js — a partida: lances, relógio, bot, treinador, fim de jogo
   ============================================================ */

(function () {
  const { Chess } = window.ChessLib;
  const App = window.App;
  const $ = App.$;
  const Coach = window.Coach;

  let J = null;           // a partida atual (ou null)
  let tab = null;         // o tabuleiro desenhado na tela
  let relogioTimer = null;
  const dormir = (ms) => new Promise(r => setTimeout(r, ms));
  const CORES_NOME = { w: 'Brancas', b: 'Pretas' };

  /* ---------- Criação da interface (uma vez só) ---------- */
  function iniciarUI() {
    tab = new window.Tabuleiro($('tabuleiro'), {
      lancesDe: lancesDe,
      podeSelecionar: podeSelecionar,
      aoMover: tentarMover,
    });
    $('b-virar').onclick = () => { tab.virar(); renderJogadores(); renderRelogios(); renderAval(); };
    $('b-dica').onclick = pedirDica;
    $('b-desfazer').onclick = desfazerBotao;
    $('b-empate').onclick = pedirEmpate;
    $('b-desistir').onclick = () => { if (J && !J.fim) App.confirmar('Desistir?', 'Você perde esta partida.', () => desistir()); };
    $('b-menu').onclick = () => App.mostrarTela('jogar');
    $('chk-coach').onchange = (e) => {
      if (!J) return;
      J.cfg.treinador = e.target.checked;
      renderTudo(false);
      if (J.cfg.treinador) mensagemSituacao();
    };
    $('f-fechar').onclick = () => App.fechar('m-fim');
    $('f-nova').onclick = () => { App.fechar('m-fim'); if (J) App.novaPartidaMesmoBot(J.cfg); };
    $('f-revisar').onclick = () => { App.fechar('m-fim'); window.Revisao.abrirDaPartida(J); };
    App.aoMudarCfg = () => { if (tab) { tab.mostrarLegais = App.cfg.legais; } if (J) renderAval(); };
    tab.mostrarLegais = App.cfg.legais;
  }

  /* ---------- Regras do tabuleiro para o desenho ---------- */
  function lancesDe(sq) {
    if (!J) return [];
    const vistos = {};
    for (const m of J.chess.moves({ square: sq, verbose: true })) vistos[m.to] = vistos[m.to] || { to: m.to, captura: !!m.captured || m.flags.includes('e') };
    return Object.values(vistos);
  }
  function suaVez() {
    return J && !J.fim && (J.cfg.modo === 'local' || J.chess.turn() === J.cfg.corUsuario);
  }
  function podeSelecionar(sq, tipoCor) {
    return suaVez() && !J.pausadoPromocao && tipoCor[0] === J.chess.turn();
  }
  function tentarMover(de, para) {
    if (!suaVez()) return;
    const candidatos = J.chess.moves({ square: de, verbose: true }).filter(m => m.to === para);
    if (!candidatos.length) return;
    if (candidatos[0].promotion) {
      J.pausadoPromocao = true;
      tab.mostrarPromocao(J.chess.turn(), para,
        (p) => { J.pausadoPromocao = false; executar(de, para, p, false); },
        () => { J.pausadoPromocao = false; renderTabuleiro(false); });
      return;
    }
    executar(de, para, undefined, false);
  }

  /* ---------- Começar / continuar ---------- */
  function iniciar(cfg) {
    pararTudo();
    J = {
      cfg, chess: new Chess(), jogadas: [], fens: [], pontuacoes: {},
      relogios: cfg.tempo ? { w: cfg.tempo.base, b: cfg.tempo.base } : null,
      relogioOn: false, ultimoTick: 0, fim: null, geracao: 0, pensando: false,
      dicasUsadas: 0, dicaPasso: 0, id: Date.now(), msgs: [],
    };
    J.fens.push(J.chess.fen());
    App.analisador.limpar();
    $('coach-msgs').innerHTML = '';
    tab.limparSetas(); tab.limparSelo(); tab.destaques = [];
    tab.definirOrientacao(cfg.corUsuario);
    $('chk-coach').checked = cfg.treinador;
    App.mostrarTela('jogo');
    renderTudo(false);
    window.Som.inicio();
    if (cfg.modo === 'bot') {
      falaBot('inicio');
      if (cfg.treinador) msg('info', 'Treinador ligado! Eu comento seus lances e posso dar dicas. Boa partida!');
    }
    iniciarRelogio();
    salvarAtual();
    verificarVezDoBot();
    mensagemSituacao();
  }

  function continuar() {
    if (J && !J.fim) { App.mostrarTela('jogo'); return; }
    const s = App.ler('partida_atual', null);
    if (!s) return;
    pararTudo();
    const cfg = Object.assign({}, s.cfg);
    if (cfg.botId) cfg.bot = window.BOTS.find(b => b.id === cfg.botId) || null;
    J = {
      cfg, chess: new Chess(), jogadas: [], fens: [], pontuacoes: {},
      relogios: s.relogios, relogioOn: !!s.relogioOn, ultimoTick: performance.now(), fim: null, geracao: 0, pensando: false,
      dicasUsadas: s.dicasUsadas || 0, dicaPasso: 0, id: s.id || Date.now(), msgs: [],
    };
    J.fens.push(J.chess.fen());
    for (const j of s.jogadas) {
      const fenAntes = J.chess.fen();
      const m = J.chess.move({ from: j.uci.slice(0, 2), to: j.uci.slice(2, 4), promotion: j.uci[4] });
      J.jogadas.push({ uci: j.uci, san: m.san, mov: m, fenAntes, fenDepois: J.chess.fen(), nota: j.nota || null, comentario: j.comentario || '' });
      J.fens.push(J.chess.fen());
    }
    $('coach-msgs').innerHTML = '';
    tab.limparSetas(); tab.limparSelo();
    tab.definirOrientacao(cfg.corUsuario);
    $('chk-coach').checked = cfg.treinador;
    App.mostrarTela('jogo');
    renderTudo(false);
    iniciarRelogio();
    // completa análises que faltavam
    J.jogadas.forEach((_, i) => analisarLance(i, true));
    verificarVezDoBot();
    mensagemSituacao();
  }

  function pararTudo() {
    if (J) { J.geracao++; J.fim = J.fim || { cancelada: true }; }
    clearInterval(relogioTimer);
    if (App.motorBot) App.motorBot.parar();
  }

  function salvarAtual() {
    if (!J || J.fim) { if (J && J.fim) App.apagar('partida_atual'); return; }
    App.salvar('partida_atual', {
      id: J.id,
      cfg: { modo: J.cfg.modo, botId: J.cfg.bot ? J.cfg.bot.id : null, corUsuario: J.cfg.corUsuario, tempo: J.cfg.tempo, treinador: J.cfg.treinador },
      relogios: J.relogios, relogioOn: J.relogioOn, dicasUsadas: J.dicasUsadas,
      jogadas: J.jogadas.map(j => ({ uci: j.uci, nota: j.nota, comentario: j.comentario })),
    });
  }

  /* ---------- Fazer um lance ---------- */
  function executar(de, para, promo, porBot) {
    if (!J || J.fim) return;
    const fenAntes = J.chess.fen();
    let m;
    try { m = J.chess.move({ from: de, to: para, promotion: promo }); } catch (e) { return; }
    if (!m) return;
    const i = J.jogadas.length;
    const uci = m.from + m.to + (m.promotion || '');
    J.jogadas.push({ uci, san: m.san, mov: m, fenAntes, fenDepois: J.chess.fen(), nota: null, comentario: '' });
    J.fens.push(J.chess.fen());
    J.dicaPasso = 0;
    tab.limparSetas(); tab.limparSelo(); tab.destaques = [];

    // relógio: começa depois que cada lado jogou uma vez
    if (J.relogios) {
      if (J.relogioOn) { J.relogios[m.color] += J.cfg.tempo.inc; }
      if (J.jogadas.length >= 2) { J.relogioOn = true; }
      J.ultimoTick = performance.now();
    }

    // som
    if (m.san.includes('#') || m.san.includes('+')) window.Som.xeque();
    else if (m.flags.includes('k') || m.flags.includes('q')) window.Som.roque();
    else if (m.captured) window.Som.capturar();
    else window.Som.mover();

    renderTudo(true);
    analisarLance(i, false);
    salvarAtual();
    if (!verificarFim()) verificarVezDoBot();
  }

  /* ---------- Vez do computador ---------- */
  async function verificarVezDoBot() {
    if (!J || J.fim || J.cfg.modo !== 'bot') return;
    if (J.chess.turn() === J.cfg.corUsuario) return;
    if (J.pensando) return;
    if (!App.motorPronto) { await App.motorBot.iniciar().catch(() => {}); }
    const g = J.geracao;
    J.pensando = true;
    const t0 = performance.now();
    const restante = J.relogios ? J.relogios[J.chess.turn()] : null;
    let uci;
    try { uci = await window.escolherLanceBot(App.motorBot, J.cfg.bot, J.chess.fen(), restante); } catch (e) { console.warn(e); uci = null; }
    if (g !== J.geracao) return;
    // pequena pausa "humana" antes de jogar
    const alvo = restante != null && restante < 15000 ? 150 : 450 + Math.random() * 900;
    const falta = alvo - (performance.now() - t0);
    if (falta > 0) await dormir(falta);
    if (g !== J.geracao || J.fim) return;
    J.pensando = false;
    if (!uci) { const ms = J.chess.moves({ verbose: true }); if (!ms.length) return; uci = ms[0].from + ms[0].to + (ms[0].promotion || ''); }
    executar(uci.slice(0, 2), uci.slice(2, 4), uci[4], true);
  }

  /* ---------- Análise e treinador ---------- */
  async function analisarLance(i, silencioso) {
    const g = J.geracao;
    const jog = J.jogadas[i];
    const fa = J.fens[i], fd = J.fens[i + 1];
    let antes, depois;
    try { [antes, depois] = await Promise.all([App.analisador.avaliar(fa), App.analisador.avaliar(fd)]); } catch (e) { return; }
    if (g !== J.geracao || J.jogadas[i] !== jog) return;

    J.pontuacoes[i + 1] = Coach.pontuacaoBrancas(depois.linhas[0], fd);
    if (i === 0) J.pontuacoes[0] = Coach.pontuacaoBrancas(antes.linhas[0], fa);
    if (!jog.nota) {
      const sans = J.jogadas.slice(0, i + 1).map(j => j.san);
      const ab = window.acharAbertura(sans);
      const nota = Coach.classificar({ c0: new Chess(fa), mov: jog.mov, antes, depois, livro: ab.emLivro && i < 16 });
      jog.nota = { classe: nota.classe, perda: nota.perda, wBest: nota.wBest, wAfter: nota.wAfter, acc: nota.acc, uciMelhor: nota.uciMelhor };
      jog.comentario = Coach.comentarLance({ fenAntes: fa, mov: jog.mov, antes, depois, nota, abertura: ab.nome });
    }
    const ehUltimo = i === J.jogadas.length - 1;
    if (!silencioso && ehUltimo) {
      renderAval();
      mostrarFeedbackLance(i, antes, depois);
    }
    renderLances();
    if (J.fim) salvarHistorico();
    salvarAtual();
  }

  function mostrarFeedbackLance(i, antes, depois) {
    const jog = J.jogadas[i];
    if (!J.cfg.treinador || !jog.nota) return;
    const cl = Coach.CLASSES[jog.nota.classe];
    const meu = J.cfg.modo === 'local' || jog.mov.color === J.cfg.corUsuario;
    tab.mostrarSelo(jog.mov.to, cl.simbolo, cl.cor);
    if (meu) {
      const ruim = ['erro', 'capivarada'].includes(jog.nota.classe);
      const botao = ruim && J.cfg.modo === 'bot' ? { texto: '↩ Desfazer e tentar de novo', fn: () => desfazerAteAntes(i) } : null;
      msg('lance', `<span class="tag" style="background:${cl.cor}">${cl.simbolo} ${cl.nome}</span>${jog.comentario}`, { cor: cl.cor, botao });
      if (ruim) window.Som.erro();
    } else {
      // lance do adversário: explica e alerta sobre ameaças
      let txt = `<b>${J.cfg.bot ? J.cfg.bot.nome : 'Adversário'}</b> jogou <b>${jog.san}</b>`;
      const d = Coach.descreverLance(J.fens[i], jog.uci, antes.linhas[0] && antes.linhas[0].mov === jog.uci ? antes.linhas[0] : null);
      if (d) txt += ': ' + d + '.';
      if (['erro', 'capivarada'].includes(jog.nota.classe)) txt += ' <b>Foi um erro dele!</b> Procure aproveitar.';
      msg('info', txt);
      for (const a of Coach.alertas(J.fens[i + 1], depois)) msg('alerta', a);
    }
    mensagemSituacao();
  }

  function mensagemSituacao() {
    const el = $('situacao');
    if (!J || !J.cfg.treinador) { el.textContent = ''; return; }
    const ult = J.jogadas.length;
    const p = J.pontuacoes[ult];
    el.textContent = p == null ? 'Analisando a posição…' : Coach.resumoPosicao(p, J.cfg.modo === 'local' ? 'w' : J.cfg.corUsuario);
  }

  // Adiciona mensagem no painel do treinador
  function msg(tipo, html, opc) {
    const box = $('coach-msgs');
    [...box.children].forEach(c => c.classList.add('velha'));
    const d = document.createElement('div');
    d.className = 'msg ' + (tipo === 'lance' ? '' : tipo);
    if (opc && opc.cor) d.style.borderLeftColor = opc.cor;
    d.innerHTML = html;
    if (opc && opc.botao) {
      const b = document.createElement('button');
      b.className = 'btn pequeno acao'; b.textContent = opc.botao.texto; b.onclick = opc.botao.fn;
      d.appendChild(b);
    }
    box.prepend(d);
    while (box.children.length > 8) box.lastChild.remove();
    box.scrollTop = 0;
    return d;
  }

  async function pedirDica() {
    if (!J || J.fim || !suaVez()) return;
    if (!J.cfg.treinador) { msg('info', 'Ligue o treinador para pedir dicas.'); return; }
    const limite = App.cfg.dicas;
    if (J.dicaPasso === 0 && J.dicasUsadas >= limite) { msg('info', limite === 0 ? 'As dicas estão desligadas nas configurações.' : `Você já usou suas ${limite} dicas nesta partida.`); return; }
    const fen = J.chess.fen();
    const pensando = msg('info', 'Pensando…');
    const an = await App.analisador.avaliar(fen);
    pensando.remove();
    if (!suaVez() || J.chess.fen() !== fen) return;
    const melhor = an.linhas[0];
    if (!melhor || !melhor.mov) return;
    const de = melhor.mov.slice(0, 2), para = melhor.mov.slice(2, 4);
    if (J.dicaPasso === 0) {
      J.dicasUsadas++; J.dicaPasso = 1;
      tab.destaques = [{ sq: de, cls: 'dica' }]; tab.desenharMarcas();
      msg('dica', `💡 <b>Dica:</b> mexa na peça marcada em ${de}. (Clique em Dica de novo para ver o lance completo.)`);
    } else {
      J.dicaPasso = 2;
      tab.destaques = [{ sq: de, cls: 'dica' }, { sq: para, cls: 'dica' }]; tab.desenharMarcas();
      tab.desenharSetas([{ de, para }]);
      const san = Coach.sanDe(fen, melhor.mov);
      const desc = Coach.descreverLance(fen, melhor.mov, melhor);
      msg('dica', `💡 <b>Melhor lance: ${san}</b>${desc ? ' — ' + desc + '.' : '.'}`);
    }
    renderBotoes();
  }

  /* ---------- Desfazer ---------- */
  function desfazerPlies(n) {
    if (!J || J.fim) return;
    J.geracao++; J.pensando = false; App.motorBot.parar();
    for (let k = 0; k < n && J.jogadas.length; k++) {
      J.chess.undo(); J.jogadas.pop(); J.fens.pop();
    }
    J.dicaPasso = 0;
    for (const k of Object.keys(J.pontuacoes)) if (+k > J.jogadas.length) delete J.pontuacoes[k];
    tab.limparSetas(); tab.limparSelo(); tab.destaques = [];
    renderTudo(false);
    salvarAtual();
    mensagemSituacao();
    verificarVezDoBot();
  }
  function desfazerBotao() {
    if (!J || J.fim || !J.jogadas.length) return;
    let n = 1;
    if (J.cfg.modo === 'bot' && J.chess.turn() === J.cfg.corUsuario) n = Math.min(2, J.jogadas.length);
    if (J.cfg.modo === 'bot') {
      // não deixa desfazer o lance do bot se o usuário ainda nem jogou (ex.: você de pretas)
      const meus = J.jogadas.filter(j => j.mov.color === J.cfg.corUsuario).length;
      if (!meus) return;
    }
    desfazerPlies(n);
  }
  function desfazerAteAntes(i) {
    if (!J || J.fim) return;
    desfazerPlies(J.jogadas.length - i);
    msg('info', 'Lance desfeito. Tente outro caminho!');
  }

  /* ---------- Empate e desistência ---------- */
  async function pedirEmpate() {
    if (!J || J.fim) return;
    if (J.cfg.modo === 'local') { App.confirmar('Empate?', 'Os dois jogadores concordam com o empate?', () => terminar({ vencedor: null, motivo: 'Empate por acordo' })); return; }
    const an = await App.analisador.avaliar(J.chess.fen());
    const pontBot = J.chess.turn() === J.cfg.corUsuario ? -Coach.pontuacao(an.linhas[0]) : Coach.pontuacao(an.linhas[0]);
    const aceita = pontBot < 40 && J.jogadas.length >= 20 || pontBot < -150;
    if (aceita) terminar({ vencedor: null, motivo: 'Empate por acordo' });
    else msg('info', `${J.cfg.bot.avatar} ${J.cfg.bot.nome} recusou o empate. Ele acha que está melhor!`);
  }
  function desistir() { terminar({ vencedor: J.cfg.modo === 'local' ? (J.chess.turn() === 'w' ? 'b' : 'w') : (J.cfg.corUsuario === 'w' ? 'b' : 'w'), motivo: 'Desistência' }); }

  /* ---------- Fim de jogo ---------- */
  function verificarFim() {
    const c = J.chess;
    if (c.isCheckmate()) { terminar({ vencedor: c.turn() === 'w' ? 'b' : 'w', motivo: 'Xeque-mate' }); return true; }
    if (c.isStalemate()) { terminar({ vencedor: null, motivo: 'Empate por afogamento' }); return true; }
    if (c.isInsufficientMaterial()) { terminar({ vencedor: null, motivo: 'Empate por material insuficiente' }); return true; }
    if (c.isThreefoldRepetition()) { terminar({ vencedor: null, motivo: 'Empate por repetição de posição' }); return true; }
    if (c.isDrawByFiftyMoves()) { terminar({ vencedor: null, motivo: 'Empate pela regra dos 50 lances' }); return true; }
    return false;
  }

  function terminar(res) {
    if (!J || J.fim) return;
    J.fim = res; J.geracao++; J.pensando = false;
    App.motorBot.parar();
    clearInterval(relogioTimer);
    tab.destaques = []; tab.desenharMarcas();
    window.Som.fim();
    App.apagar('partida_atual');

    let titulo, sub = res.motivo;
    if (J.cfg.modo === 'bot') {
      const eu = J.cfg.corUsuario;
      if (res.vencedor === eu) { titulo = '🏆 Você venceu!'; App.registrarResultado(J.cfg.bot.id, 'v'); falaBot('derrota');
        if (window.Yauri) { Yauri.evento('xadrez_vitoria'); Yauri.ganhar(Math.max(10, Math.round(J.cfg.bot.elo / 30)), 30, 'vitória contra ' + J.cfg.bot.nome); if (J.cfg.bot.id === 'supremo') Yauri.conquista('supremo', 'Derrotou o Senhor Supremo!', 300); if (J.cfg.bot.id === 'guizin') Yauri.conquista('guizin_bot', 'Venceu o Guizin', 60); } }
      else if (res.vencedor) { titulo = 'Você perdeu'; App.registrarResultado(J.cfg.bot.id, 'd'); falaBot('vitoria'); }
      else { titulo = 'Empate'; App.registrarResultado(J.cfg.bot.id, 'e'); falaBot('empate'); }
    } else {
      titulo = res.vencedor ? `${CORES_NOME[res.vencedor]} venceram!` : 'Empate';
    }
    $('f-titulo').textContent = titulo; $('f-sub').textContent = sub;
    renderTudo(false);
    App.abrir('m-fim');
    salvarHistoricoQuandoPronto();
    msg('info', 'Partida terminada. Clique em <b>Revisar partida</b> para ver a análise completa.');
  }

  // Salva a partida no histórico (de novo a cada análise que termina, para guardar as notas)
  function salvarHistorico() {
    if (!J || !J.fim || J.fim.cancelada) return;
    const hist = App.ler('historico', []).filter(h => h.id !== J.id);
    hist.unshift({
      id: J.id, data: Date.now(), modo: J.cfg.modo, botId: J.cfg.bot ? J.cfg.bot.id : null,
      corUsuario: J.cfg.corUsuario, resultado: J.fim,
      jogadas: J.jogadas.map(j => ({ uci: j.uci, san: j.san, nota: j.nota, comentario: j.comentario })),
    });
    App.salvar('historico', hist.slice(0, 20));
  }
  async function salvarHistoricoQuandoPronto() {
    salvarHistorico();
    const id = J.id;
    await Promise.all(J.fens.map(f => App.analisador.avaliar(f).catch(() => null)));
    await dormir(400);
    if (J && J.id === id) salvarHistorico();
  }

  /* ---------- Relógio ---------- */
  function iniciarRelogio() {
    clearInterval(relogioTimer);
    if (!J.relogios) { renderRelogios(); return; }
    J.ultimoTick = performance.now();
    relogioTimer = setInterval(() => {
      if (!J || J.fim) return;
      const agora = performance.now();
      if (J.relogioOn) {
        const lado = J.chess.turn();
        J.relogios[lado] -= agora - J.ultimoTick;
        if (J.relogios[lado] <= 0) {
          J.relogios[lado] = 0; renderRelogios();
          terminar({ vencedor: lado === 'w' ? 'b' : 'w', motivo: 'Tempo esgotado' });
          return;
        }
      }
      J.ultimoTick = agora;
      renderRelogios();
    }, 100);
  }
  function fmt(ms) {
    if (ms < 10000) return (ms / 1000).toFixed(1);
    const s = Math.ceil(ms / 1000);
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }

  /* ---------- Desenho da tela ---------- */
  function falaBot(tipo) {
    if (!J || !J.cfg.bot) return;
    const lista = J.cfg.bot.falas[tipo]; if (!lista) return;
    msg('info', `${J.cfg.bot.avatar} <b>${J.cfg.bot.nome}:</b> “${lista[Math.floor(Math.random() * lista.length)]}”`);
  }

  function casaDoRei(cor) {
    for (const l of J.chess.board()) for (const p of l) if (p && p.type === 'k' && p.color === cor) return p.square;
    return null;
  }
  function renderTabuleiro(animar) {
    const ult = J.jogadas[J.jogadas.length - 1];
    tab.atualizar({
      tab: J.chess.board(),
      ultimo: ult ? { from: ult.mov.from, to: ult.mov.to } : null,
      casaXeque: J.chess.inCheck() ? casaDoRei(J.chess.turn()) : null,
      animar,
    });
  }
  function renderTudo(animar) {
    if (!J) return;
    renderTabuleiro(animar);
    renderJogadores();
    renderRelogios();
    renderLances();
    renderAval();
    renderBotoes();
    const ab = window.acharAbertura(J.jogadas.map(j => j.san));
    $('abertura').innerHTML = ab.nome ? `Abertura: <b>${ab.nome}</b>` : '&nbsp;';
  }

  const INICIAL = { p: 8, n: 2, b: 2, r: 2, q: 1 };
  function capturadas() {
    // peças que cada cor perdeu
    const falta = { w: {}, b: {} };
    const cont = { w: { p: 0, n: 0, b: 0, r: 0, q: 0 }, b: { p: 0, n: 0, b: 0, r: 0, q: 0 } };
    for (const l of J.chess.board()) for (const p of l) if (p && p.type !== 'k') cont[p.color][p.type]++;
    for (const c of ['w', 'b']) for (const t in INICIAL) falta[c][t] = Math.max(0, INICIAL[t] - cont[c][t]);
    return falta;
  }
  function renderJogadores() {
    const topoCor = tab.orientacao === 'w' ? 'b' : 'w';
    const baixoCor = topoCor === 'w' ? 'b' : 'w';
    const falta = capturadas();
    const mat = Coach.material(J.chess);
    const nomeDe = (cor) => {
      if (J.cfg.modo === 'local') return { av: cor === 'w' ? '⬜' : '⬛', nome: CORES_NOME[cor], sub: '' };
      if (cor === J.cfg.corUsuario) return { av: '🙂', nome: 'Você', sub: '' };
      return { av: J.cfg.bot.avatar, nome: J.cfg.bot.nome, sub: ` (${J.cfg.bot.elo})` };
    };
    const montar = (el, cor) => {
      const outra = cor === 'w' ? 'b' : 'w';
      const n = nomeDe(cor);
      // peças que ESTA cor capturou = peças que a outra cor perdeu
      let icones = '';
      for (const t of ['q', 'r', 'b', 'n', 'p']) for (let k = 0; k < falta[outra][t]; k++) icones += `<i style="background-image:url('${window.PECAS[outra + t]}')"></i>`;
      const vant = mat[cor] - mat[outra];
      el.innerHTML = `<div class="av">${n.av}</div><div class="info"><div class="nome">${n.nome}<small>${n.sub}</small></div><div class="capt">${icones}${vant > 0 ? `<b>+${vant}</b>` : ''}</div></div><div class="relogio" data-cor="${cor}" style="${J.relogios ? '' : 'display:none'}"></div>`;
    };
    montar($('jog-topo'), topoCor);
    montar($('jog-baixo'), baixoCor);
  }
  function renderRelogios() {
    if (!J || !J.relogios) return;
    document.querySelectorAll('#tela-jogo .relogio').forEach(el => {
      const cor = el.dataset.cor;
      const ms = J.relogios[cor];
      el.textContent = fmt(ms);
      el.classList.toggle('ativo', !J.fim && J.relogioOn && J.chess.turn() === cor);
      el.classList.toggle('baixo', ms < 10000);
    });
  }
  function renderLances() {
    const box = $('lances');
    const sans = J.jogadas;
    let html = '';
    for (let i = 0; i < sans.length; i += 2) {
      const cel = (j) => {
        if (!j) return '<div class="lance"></div>';
        let bola = '';
        if (J.cfg.treinador && j.nota) bola = `<span class="bola" style="background:${Coach.CLASSES[j.nota.classe].cor}"></span>`;
        return `<div class="lance">${bola}${j.san}</div>`;
      };
      html += `<div class="linha"><div class="num">${i / 2 + 1}.</div>${cel(sans[i])}${cel(sans[i + 1])}</div>`;
    }
    box.innerHTML = html;
    box.scrollTop = box.scrollHeight;
  }
  function renderAval() {
    const col = $('aval');
    if (!J) return;
    const mostrar = J.cfg.treinador && App.cfg.aval;
    col.style.visibility = mostrar ? 'visible' : 'hidden';
    const p = J.pontuacoes[J.jogadas.length];
    col.classList.toggle('invertida', tab.orientacao === 'b');
    col.classList.toggle('vazia', p == null);
    const alto = $('aval-alto'), baixo = $('aval-baixo');
    alto.textContent = ''; baixo.textContent = '';
    if (p == null) return;
    col.querySelector('.branco').style.height = Coach.winPct(p) + '%';
    const txt = Coach.textoAval(p).replace('-', '');
    const brancaEmbaixo = tab.orientacao === 'w';
    const lideraBranca = p >= 0;
    // texto fica na ponta da cor que está melhor
    const embaixo = lideraBranca === brancaEmbaixo;
    (embaixo ? baixo : alto).textContent = txt;
  }
  function renderBotoes() {
    const fim = !J || J.fim;
    $('b-dica').disabled = fim || !suaVez() || !J.cfg.treinador;
    const limite = App.cfg.dicas;
    $('b-dica').textContent = '💡 Dica' + (J && limite < 99 ? ` (${Math.max(0, limite - J.dicasUsadas)})` : '');
    $('b-desfazer').disabled = fim || !J.jogadas.length;
    $('b-empate').disabled = fim;
    $('b-desistir').disabled = fim;
  }

  window.Jogo = { iniciarUI, iniciar, continuar, temPartida: () => !!(J && !J.fim), atual: () => J };
})();
