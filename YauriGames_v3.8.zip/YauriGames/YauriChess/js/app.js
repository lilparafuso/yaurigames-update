/* ============================================================
   app.js — parte comum do programa:
   salvar dados, configurações, trocar de tela, menu de bots,
   janelinhas (modais) e inicialização dos motores.
   ============================================================ */

(function () {
  const { Chess } = window.ChessLib;
  const App = (window.App = {});
  const $ = (id) => document.getElementById(id);
  App.$ = $;

  /* ---------- Salvar/ler dados (localStorage com plano B na memória) ---------- */
  const memoria = {};
  App.ler = function (chave, padrao) {
    try {
      const v = localStorage.getItem('xadrez_' + chave);
      if (v != null) return JSON.parse(v);
    } catch (e) { /* localStorage bloqueado: segue sem salvar */ }
    return chave in memoria ? memoria[chave] : padrao;
  };
  App.salvar = function (chave, valor) {
    memoria[chave] = valor;
    try { localStorage.setItem('xadrez_' + chave, JSON.stringify(valor)); } catch (e) { /* ignora */ }
  };
  App.apagar = function (chave) {
    delete memoria[chave];
    try { localStorage.removeItem('xadrez_' + chave); } catch (e) { /* ignora */ }
  };

  /* ---------- Configurações ---------- */
  const PADRAO = { tema: 'verde', som: true, legais: true, aval: true, treinador: true, dicas: 99, prof: 12 };
  App.cfg = Object.assign({}, PADRAO, App.ler('cfg', {}));
  App.aplicarCfg = function () {
    document.body.classList.remove('tema-verde', 'tema-marrom', 'tema-azul', 'tema-roxo', 'tema-dourado');
    if ((App.cfg.tema === 'roxo' && !(window.Yauri && Yauri.tem('xadrez_roxo'))) || (App.cfg.tema === 'dourado' && !(window.Yauri && Yauri.tem('xadrez_ouro')))) App.cfg.tema = 'verde';
    document.body.classList.add('tema-' + App.cfg.tema);
    window.Som.ligar(App.cfg.som);
    if (App.analisador) App.analisador.profundidade = App.cfg.prof;
    if (App.aoMudarCfg) App.aoMudarCfg();
  };
  App.mudarCfg = function (k, v) { App.cfg[k] = v; App.salvar('cfg', App.cfg); App.aplicarCfg(); };

  /* ---------- Janelinhas (modais) ---------- */
  App.abrir = (id) => $(id).classList.add('aberto');
  App.fechar = (id) => $(id).classList.remove('aberto');
  App.confirmar = function (titulo, texto, aoSim) {
    $('mc-titulo').textContent = titulo; $('mc-texto').textContent = texto;
    App.abrir('m-confirma');
    $('mc-sim').onclick = () => { App.fechar('m-confirma'); aoSim(); };
    $('mc-nao').onclick = () => App.fechar('m-confirma');
  };
  // Liga um grupo de botões "tipo rádio": só um fica selecionado
  App.ligarOpcoes = function (el, valorAtual, aoMudar) {
    const botoes = [...el.querySelectorAll('button')];
    const marcar = (v) => botoes.forEach(b => b.classList.toggle('sel', b.dataset.v === String(v)));
    marcar(valorAtual);
    botoes.forEach(b => b.onclick = () => { marcar(b.dataset.v); if (aoMudar) aoMudar(b.dataset.v); });
    return marcar;
  };

  /* ---------- Trocar de tela ---------- */
  App.telaAtual = 'jogar';
  App.mostrarTela = function (nome) {
    document.querySelectorAll('.tela').forEach(t => t.classList.remove('ativa'));
    $('tela-' + nome).classList.add('ativa');
    document.querySelectorAll('#nav button[data-tela]').forEach(b => b.classList.toggle('ativo', b.dataset.tela === nome || (nome === 'jogo' && b.dataset.tela === 'jogar')));
    App.telaAtual = nome;
    if (nome === 'jogar') App.renderMenu();
    if (nome === 'revisao' && window.Revisao) window.Revisao.mostrarLista();
    if (nome === 'taticas' && window.Taticas) window.Taticas.entrar();
  };

  /* ---------- Reconstruir uma partida a partir dos lances (UCI) ---------- */
  App.reconstruir = function (ucis) {
    const c = new Chess();
    const fens = [c.fen()], movs = [];
    for (const u of ucis) {
      const m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
      movs.push(m); fens.push(c.fen());
    }
    return { fens, movs };
  };

  /* ---------- Estatísticas ---------- */
  App.registrarResultado = function (botId, resultado) {   // 'v' | 'd' | 'e'
    const st = App.ler('stats', {});
    st[botId] = st[botId] || { v: 0, d: 0, e: 0 };
    st[botId][resultado]++;
    App.salvar('stats', st);
  };
  function mostrarStats() {
    const st = App.ler('stats', {});
    let tv = 0, td = 0, te = 0;
    let html = '<table class="stats"><tr><th>Adversário</th><th>V</th><th>E</th><th>D</th></tr>';
    for (const b of window.BOTS) {
      const s = st[b.id]; if (!s) continue;
      tv += s.v; td += s.d; te += s.e;
      html += `<tr><td>${b.avatar} ${b.nome} <small>(${b.elo})</small></td><td>${s.v}</td><td>${s.e}</td><td>${s.d}</td></tr>`;
    }
    html += `<tr><th>Total</th><th>${tv}</th><th>${te}</th><th>${td}</th></tr></table>`;
    if (tv + td + te === 0) html = '<p>Você ainda não terminou nenhuma partida contra o computador.</p>';
    $('stats-corpo').innerHTML = html;
    App.abrir('m-stats');
  }

  /* ---------- Menu de bots ---------- */
  App.renderMenu = function () {
    const st = App.ler('stats', {});
    const grade = $('grade-bots');
    grade.innerHTML = '';
    for (const b of window.BOTS) {
      const s = st[b.id] || { v: 0, d: 0, e: 0 };
      const card = document.createElement('button');
      card.className = 'card-bot';
      card.innerHTML = `<div class="av">${b.avatar}</div><div class="nm">${b.nome}</div><div class="el">Elo ~${b.elo}</div><div class="ds">${b.desc}</div><div class="rec">${s.v}V ${s.e}E ${s.d}D</div>`;
      card.onclick = () => abrirNova({ modo: 'bot', bot: b });
      grade.appendChild(card);
    }
    const salva = App.ler('partida_atual', null);
    $('btn-continuar').style.display = (window.Jogo && window.Jogo.temPartida()) || salva ? '' : 'none';
  };

  /* ---------- Janela "Nova partida" ---------- */
  let nova = null, corEsc = 'w', tempoEsc = '0';
  function abrirNova(base) {
    nova = base;
    $('mn-titulo').textContent = base.modo === 'bot' ? `Jogar contra ${base.bot.avatar} ${base.bot.nome}` : 'Dois jogadores';
    $('mn-linha-coach').style.display = base.modo === 'bot' ? '' : 'none';
    $('mn-coach').checked = App.cfg.treinador;
    corEsc = 'w'; tempoEsc = '0';
    App.ligarOpcoes($('mn-cor'), 'w', v => corEsc = v);
    App.ligarOpcoes($('mn-tempo'), '0', v => tempoEsc = v);
    $('mn-cor').style.display = base.modo === 'bot' ? '' : 'none';
    $('mn-cor').previousElementSibling.style.display = base.modo === 'bot' ? '' : 'none';
    App.abrir('m-nova');
  }
  function comecar() {
    App.fechar('m-nova');
    let cor = corEsc === 'r' ? (Math.random() < 0.5 ? 'w' : 'b') : corEsc;
    let tempo = null;
    if (tempoEsc !== '0') { const [m, i] = tempoEsc.split('+').map(Number); tempo = { base: m * 60000, inc: i * 1000 }; }
    window.Jogo.iniciar({
      modo: nova.modo, bot: nova.bot || null, corUsuario: cor, tempo,
      treinador: nova.modo === 'bot' ? $('mn-coach').checked : false,
    });
  }
  App.novaPartidaMesmoBot = function (cfgAnterior) { abrirNova({ modo: cfgAnterior.modo, bot: cfgAnterior.bot }); };

  /* ---------- Inicialização ---------- */
  function iniciar() {
    // navegação
    document.querySelectorAll('#nav button[data-tela]').forEach(b => b.onclick = () => App.mostrarTela(b.dataset.tela));
    $('btn-stats').onclick = mostrarStats; $('s-ok').onclick = () => App.fechar('m-stats');
    $('mn-cancelar').onclick = () => App.fechar('m-nova'); $('mn-jogar').onclick = comecar;
    $('btn-local').onclick = () => abrirNova({ modo: 'local', bot: null });
    $('btn-continuar').onclick = () => window.Jogo.continuar();

    // configurações
    $('btn-config').onclick = () => {
      const c = App.cfg;
      $('t-roxo').style.display = (window.Yauri && Yauri.tem('xadrez_roxo')) ? '' : 'none';
      $('t-ouro').style.display = (window.Yauri && Yauri.tem('xadrez_ouro')) ? '' : 'none';
      App.ligarOpcoes($('c-tema'), c.tema, v => App.mudarCfg('tema', v));
      App.ligarOpcoes($('c-dicas'), c.dicas, v => App.mudarCfg('dicas', +v));
      App.ligarOpcoes($('c-prof'), c.prof, v => App.mudarCfg('prof', +v));
      $('c-som').checked = c.som; $('c-legais').checked = c.legais; $('c-aval').checked = c.aval; $('c-coach').checked = c.treinador;
      App.abrir('m-config');
    };
    $('c-som').onchange = (e) => { App.mudarCfg('som', e.target.checked); if (e.target.checked) window.Som.mover(); };
    $('c-legais').onchange = (e) => App.mudarCfg('legais', e.target.checked);
    $('c-aval').onchange = (e) => App.mudarCfg('aval', e.target.checked);
    $('c-coach').onchange = (e) => App.mudarCfg('treinador', e.target.checked);
    $('c-ok').onclick = () => App.fechar('m-config');
    $('c-limpar').onclick = () => App.confirmar('Apagar dados?', 'Isso apaga estatísticas, partidas salvas e configurações deste navegador.', () => {
      ['cfg', 'stats', 'historico', 'partida_atual', 'taticas'].forEach(App.apagar);
      App.cfg = Object.assign({}, PADRAO); App.aplicarCfg(); App.renderMenu(); App.fechar('m-config');
    });

    // sons só podem começar depois de um clique do usuário
    document.addEventListener('pointerdown', () => window.Som.acordar(), { once: true });

    // motores (dois: um joga, o outro analisa para o treinador)
    App.motorBot = new window.Motor('bot');
    App.motorAna = new window.Motor('analise');
    App.analisador = new window.Coach.Analisador(App.motorAna);
    App.aplicarCfg();
    Promise.all([App.motorBot.iniciar(), App.motorAna.iniciar()]).then(() => {
      $('motor-status').textContent = 'Motor pronto' + (App.motorBot.tipo === 'asm' ? ' (modo compatível, mais fraco)' : ' ✓');
      App.motorPronto = true;
      document.body.dataset.motor = App.motorBot.tipo;
    }).catch((e) => {
      $('motor-status').textContent = 'Motor indisponível: ' + e.message;
      document.body.dataset.motor = 'erro';
    });

    window.Jogo.iniciarUI();
    window.Revisao.iniciarUI();
    window.Taticas.iniciarUI();
    App.renderMenu();
  }

  window.addEventListener('DOMContentLoaded', iniciar);
})();
