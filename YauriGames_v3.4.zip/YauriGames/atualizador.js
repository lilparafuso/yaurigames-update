/* YauriGames — Atualizador automático (assinado). Só carregado pelo index.html. */
(function () {
  'use strict';
  const PUB = { kty: 'EC', crv: 'P-256', x: '1MtYvTqOocGACdgSE_k0hg1pSoP4kdjFQMr5oq7zdts', y: 'xlZSDqC0AihmdeqRqWOpDEi3zU2YCwOvMKZuttGIPkE' };
  const K_URL = 'yauri_upd_url';
  const INST = window.YAURI_INST || { versao: '0', arquivos: {} };
  const E = { url: '', manifesto: null, pend: [], estado: 'ocioso', msg: '', raiz: null };
  const $ = id => document.getElementById(id);
  const urlSalva = () => (localStorage.getItem(K_URL) || '').replace(/\/+$/, '');
  const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d } return 0 };
  const b64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---- carregar script remoto (funciona em file:// sem CORS) ---- */
  function carregaScript(src, ms) {
    return new Promise((ok, erro) => {
      const s = document.createElement('script'); let fim = false;
      const t = setTimeout(() => { if (!fim) { fim = true; s.remove(); erro(new Error('tempo esgotado')) } }, ms || 15000);
      s.onload = () => { if (!fim) { fim = true; clearTimeout(t); s.remove(); ok() } };
      s.onerror = () => { if (!fim) { fim = true; clearTimeout(t); s.remove(); erro(new Error('não consegui baixar')) } };
      s.src = src; document.head.appendChild(s);
    });
  }
  async function verificaAssinatura(m) {
    if (!m || !m.payload || !m.sig || !window.crypto || !crypto.subtle) return false;
    try {
      const chave = await crypto.subtle.importKey('jwk', PUB, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, chave, b64(m.sig), new TextEncoder().encode(m.payload));
    } catch (e) { return false }
  }
  const caminhoOk = p => typeof p === 'string' && p.length < 200 && !p.startsWith('/') && !p.includes('..') && !p.includes('\\') && !p.includes(':') && !['dados/progresso.js', 'dados/instalado.js', 'Iniciar.bat'].includes(p) && /^[\w\-.\/ ()À-ÿ]+$/.test(p);

  /* ---- procurar atualização ---- */
  async function checar() {
    E.url = urlSalva();
    if (!E.url) { E.estado = 'semurl'; E.msg = 'Configure o endereço das atualizações.'; return render() }
    E.estado = 'checando'; E.msg = 'Procurando atualização...'; render();
    try {
      delete window.YAURI_MANIFESTO;
      await carregaScript(E.url + '/versao.js?t=' + Date.now());
      const m = window.YAURI_MANIFESTO;
      if (!(await verificaAssinatura(m))) { E.estado = 'erro'; E.msg = '⛔ Assinatura inválida! Essa atualização NÃO é sua. Ignorei.'; return render() }
      const p = JSON.parse(m.payload); E.manifesto = p;
      if (cmp(p.versao, INST.versao) <= 0) { E.estado = 'atual'; E.msg = '✅ Você já está na versão mais nova (' + INST.versao + ').'; E.pend = []; return render() }
      E.pend = Object.keys(p.arquivos).filter(k => caminhoOk(k) && INST.arquivos[k] !== p.arquivos[k].h);
      E.estado = 'nova'; E.msg = '🔄 Nova versão ' + p.versao + (p.titulo ? ' — ' + p.titulo : '') + ' (' + E.pend.length + ' arquivo(s) para atualizar)'; render();
    } catch (e) { E.estado = 'erro'; E.msg = '📡 Sem conexão ou endereço errado (' + e.message + ').'; render() }
  }

  /* ---- pasta raiz do pendrive ---- */
  function idb() { return new Promise((ok, er) => { const r = indexedDB.open('yauri_upd', 1); r.onupgradeneeded = () => r.result.createObjectStore('h'); r.onsuccess = () => ok(r.result); r.onerror = () => er(r.error) }) }
  async function idbGet(k) { const d = await idb(); return new Promise(ok => { const q = d.transaction('h').objectStore('h').get(k); q.onsuccess = () => ok(q.result); q.onerror = () => ok(null) }) }
  async function idbSet(k, v) { const d = await idb(); return new Promise(ok => { const t = d.transaction('h', 'readwrite'); t.objectStore('h').put(v, k); t.oncomplete = ok }) }
  async function ehRaiz(h) { try { await h.getFileHandle('index.html'); await h.getFileHandle('shared.js'); return true } catch (e) { return false } }
  async function pegaRaiz() {
    if (!window.showDirectoryPicker) throw new Error('Este navegador não grava em pastas. Use o botão do zip.');
    let h = await idbGet('raiz');
    if (h) { try { if ((await h.queryPermission({ mode: 'readwrite' })) !== 'granted') await h.requestPermission({ mode: 'readwrite' }); if ((await h.queryPermission({ mode: 'readwrite' })) === 'granted' && await ehRaiz(h)) return h } catch (e) { } }
    h = await window.showDirectoryPicker({ id: 'yauri-raiz', mode: 'readwrite' });
    if (!(await ehRaiz(h))) throw new Error('Escolha a pasta do YauriGames (onde está o index.html).');
    await idbSet('raiz', h); return h;
  }
  async function escreve(raiz, caminho, bytes) {
    const partes = caminho.split('/'), nome = partes.pop(); let d = raiz;
    for (const p of partes) d = await d.getDirectoryHandle(p, { create: true });
    const fh = await d.getFileHandle(nome, { create: true }), w = await fh.createWritable(); await w.write(bytes); await w.close();
  }
  async function apaga(raiz, caminho) {
    const partes = caminho.split('/'), nome = partes.pop(); let d = raiz;
    try { for (const p of partes) d = await d.getDirectoryHandle(p); await d.removeEntry(nome) } catch (e) { }
  }

  /* ---- aplicar ---- */
  async function aplicar(raizInjetada) {
    if (E.estado !== 'nova' && E.estado !== 'erro-parcial') return;
    try {
      const raiz = raizInjetada || await pegaRaiz(), p = E.manifesto, novos = Object.assign({}, INST.arquivos);
      E.estado = 'aplicando'; let n = 0;
      for (const rel of E.pend) {
        E.msg = '⬇️ ' + (++n) + '/' + E.pend.length + ' — ' + rel; render();
        const h = p.arquivos[rel].h;
        await carregaScript(E.url + '/f/' + h + '.js', 30000);
        const dado = window.__YF && window.__YF[h]; if (!dado) throw new Error('arquivo não veio: ' + rel);
        const bytes = b64(dado);
        if (hex(await crypto.subtle.digest('SHA-256', bytes)) !== h) throw new Error('arquivo corrompido: ' + rel);
        await escreve(raiz, rel, bytes); novos[rel] = h; delete window.__YF[h];
      }
      for (const rel of (p.remover || [])) if (caminhoOk(rel)) { await apaga(raiz, rel); delete novos[rel] }
      Object.keys(novos).forEach(k => { if (!p.arquivos[k]) delete novos[k] });
      await escreve(raiz, 'dados/instalado.js', new TextEncoder().encode('window.YAURI_INST=' + JSON.stringify({ versao: p.versao, arquivos: novos }) + ';'));
      E.estado = 'pronto'; E.msg = '🎉 Atualizado para a versão ' + p.versao + '! Recarregue a página.'; render();
    } catch (e) {
      if (e && e.name === 'AbortError') { E.estado = 'nova'; E.msg = 'Cancelado. Nada foi alterado.' } else { E.estado = 'erro-parcial'; E.msg = '⚠️ Parou: ' + e.message + '. Tente de novo (continua de onde parou).' }
      render();
    }
  }

  /* ---- interface ---- */
  function monta() {
    const bot = document.createElement('button'); bot.id = 'updBtn'; bot.textContent = '🔄 Atualizações (v' + INST.versao + ')'; bot.onclick = () => { $('updBox').style.display = 'flex'; render() };
    const alvo = document.querySelector('button[onclick="abrirCL()"]'); if (alvo && alvo.parentNode) alvo.parentNode.insertBefore(bot, alvo.nextSibling); else document.body.prepend(bot);
    const barra = document.createElement('div'); barra.id = 'updBarra';
    barra.style.cssText = 'display:none;position:fixed;top:0;left:0;right:0;z-index:99998;background:#1565c0;color:#fff;padding:8px 14px;font-weight:700;text-align:center;cursor:pointer';
    barra.onclick = () => { $('updBox').style.display = 'flex'; render() }; document.body.appendChild(barra);
    const box = document.createElement('div'); box.id = 'updBox';
    box.style.cssText = 'display:none;position:fixed;inset:0;z-index:99999;background:#000b;align-items:center;justify-content:center';
    box.innerHTML = '<div style="background:#14202e;color:#fff;border-radius:14px;padding:18px 22px;width:min(560px,94vw);max-height:88vh;overflow:auto;font-family:system-ui">' +
      '<div style="display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">🔄 Atualizações</h3><button id="updX" style="background:none;border:0;color:#fff;font-size:20px;cursor:pointer">✕</button></div>' +
      '<p style="color:#9ab;font-size:13px">Versão instalada: <b>' + esc(INST.versao) + '</b></p>' +
      '<label style="font-size:13px;color:#9ab">Endereço das atualizações (https://...)</label>' +
      '<div style="display:flex;gap:6px;margin:4px 0 10px"><input id="updUrl" style="flex:1;padding:8px;border-radius:8px;border:1px solid #345;background:#0d1620;color:#fff" placeholder="https://meusite.com/yaurigames-update"><button id="updSalva" class="updb">Salvar</button></div>' +
      '<div id="updMsg" style="font-weight:700;margin:8px 0"></div><div id="updNotas" style="font-size:13px;color:#cde"></div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button id="updProc" class="updb">🔍 Procurar agora</button><button id="updGo" class="updb" style="background:#2e7d32;display:none">⬇️ Atualizar agora</button><a id="updZip" class="updb" style="display:none;text-decoration:none" target="_blank" rel="noopener">📦 Baixar zip</a><button id="updRec" class="updb" style="display:none">↻ Recarregar</button></div>' +
      '<p style="font-size:12px;color:#789;margin-top:12px">Só aceita atualizações <b>assinadas</b> por você. A atualização nunca mexe no seu progresso (dados/progresso.js). Gravar no pendrive exige Chrome/Edge e 1 permissão de pasta.</p></div>';
    document.body.appendChild(box);
    const st = document.createElement('style'); st.textContent = '.updb{background:#1565c0;color:#fff;border:0;border-radius:8px;padding:9px 14px;font-weight:700;cursor:pointer;font-size:14px}'; document.head.appendChild(st);
    $('updX').onclick = () => { box.style.display = 'none' }; box.onclick = e => { if (e.target === box) box.style.display = 'none' };
    $('updUrl').value = urlSalva();
    $('updSalva').onclick = () => { localStorage.setItem(K_URL, $('updUrl').value.trim()); checar() };
    $('updProc').onclick = checar; $('updGo').onclick = () => aplicar(); $('updRec').onclick = () => location.reload();
  }
  function render() {
    if (!$('updMsg')) return;
    $('updMsg').textContent = E.msg || (urlSalva() ? '' : 'Cole o endereço onde as atualizações estão hospedadas.');
    const nova = E.estado === 'nova' || E.estado === 'erro-parcial';
    $('updGo').style.display = nova ? '' : 'none'; $('updRec').style.display = E.estado === 'pronto' ? '' : 'none';
    const p = E.manifesto, z = $('updZip');
    if (nova && p && p.zip) { z.style.display = ''; z.href = E.url + '/' + p.zip } else z.style.display = 'none';
    $('updNotas').innerHTML = (nova || E.estado === 'pronto') && p && p.notas ? '<b>Novidades:</b><ul style="margin:4px 0;padding-left:20px">' + p.notas.map(n => '<li>' + esc(n) + '</li>').join('') + '</ul>' : '';
    const b = $('updBarra'); b.style.display = E.estado === 'nova' ? 'block' : 'none'; if (E.estado === 'nova') b.textContent = E.msg + ' — clique para atualizar';
  }
  function iniciar() { monta(); if (urlSalva() && navigator.onLine !== false) setTimeout(checar, 1500) }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
  window.__upd = { checar, aplicar, get E() { return E }, verificaAssinatura, cmp, caminhoOk };
})();
