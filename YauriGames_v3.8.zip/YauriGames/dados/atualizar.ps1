# YauriGames - atualizador automatico (Windows PowerShell 5.1+). Qualquer erro = simplesmente nao atualiza.
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  # --- endereco das atualizacoes ---
  $url = ''
  $f = Join-Path $PSScriptRoot 'atualizacao.txt'
  if (Test-Path $f) { $url = ((Get-Content $f -Raw -Encoding UTF8) -replace '[\r\n]', '').Trim() }
  if (-not $url) {
    $pj = Join-Path $PSScriptRoot 'progresso.js'
    if (Test-Path $pj) { $t = Get-Content $pj -Raw -Encoding UTF8; if ($t -match '"yauri_upd_url"\s*:\s*"([^"]+)"') { $url = $Matches[1] } }
  }
  $url = $url.TrimEnd('/')
  if (-not $url) { Write-Host '  (sem endereco de atualizacao configurado)'; return }

  # --- versao instalada ---
  $instTxt = Get-Content (Join-Path $PSScriptRoot 'instalado.js') -Raw -Encoding UTF8
  $inst = ($instTxt -replace '^\s*window\.YAURI_INST\s*=\s*', '' -replace ';\s*$', '') | ConvertFrom-Json
  $mapa = @{}
  foreach ($pr in $inst.arquivos.PSObject.Properties) { $mapa[$pr.Name] = [string]$pr.Value }

  # --- manifesto ---
  $r = Invoke-WebRequest -Uri ($url + '/versao.js?t=' + [DateTime]::UtcNow.Ticks) -UseBasicParsing -TimeoutSec 8
  $txt = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
  $m = ($txt -replace '^\s*window\.YAURI_MANIFESTO\s*=\s*', '' -replace ';\s*$', '') | ConvertFrom-Json

  # --- assinatura (ECDSA P-256) ---
  function B64U([string]$s) { $s = $s.Replace('-', '+').Replace('_', '/'); switch ($s.Length % 4) { 2 { $s += '==' } 3 { $s += '=' } }; return [Convert]::FromBase64String($s) }
  $x = B64U '1MtYvTqOocGACdgSE_k0hg1pSoP4kdjFQMr5oq7zdts'
  $y = B64U 'xlZSDqC0AihmdeqRqWOpDEi3zU2YCwOvMKZuttGIPkE'
  $blob = [byte[]]@(0x45,0x43,0x53,0x31,0x20,0,0,0) + $x + $y
  $key = [System.Security.Cryptography.CngKey]::Import($blob, [System.Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
  $ec = New-Object System.Security.Cryptography.ECDsaCng($key)
  $ec.HashAlgorithm = [System.Security.Cryptography.CngAlgorithm]::Sha256
  $ok = $ec.VerifyData([Text.Encoding]::UTF8.GetBytes([string]$m.payload), [Convert]::FromBase64String([string]$m.sig))
  if (-not $ok) { Write-Host '  ASSINATURA INVALIDA - atualizacao ignorada.'; return }

  $p = $m.payload | ConvertFrom-Json
  try { if ([version]$p.versao -le [version]$inst.versao) { Write-Host ('  Ja esta na versao mais nova (' + $inst.versao + ').'); return } } catch { return }

  # --- baixar so o que mudou ---
  $pend = @()
  foreach ($pr in $p.arquivos.PSObject.Properties) {
    $rel = $pr.Name; $h = [string]$pr.Value.h
    if ($rel -notmatch '^[\w\-./ ()]+$' -or $rel.Contains('..') -or $rel.StartsWith('/') -or $rel -eq 'dados/progresso.js' -or $rel -eq 'dados/instalado.js' -or $rel -eq 'Iniciar.bat') { continue }
    if ($mapa[$rel] -ne $h) { $pend += , @($rel, $h) }
  }
  Write-Host ('  Nova versao ' + $p.versao + ' - ' + $pend.Count + ' arquivo(s)...')
  $falhou = 0; $n = 0
  $sha = [Security.Cryptography.SHA256]::Create()
  foreach ($it in $pend) {
    $rel = $it[0]; $h = $it[1]; $n++
    try {
      $rr = Invoke-WebRequest -Uri ($url + '/f/' + $h + '.js') -UseBasicParsing -TimeoutSec 60
      $js = [Text.Encoding]::UTF8.GetString($rr.RawContentStream.ToArray())
      if ($js -notmatch '=\s*"([A-Za-z0-9+/=]*)"\s*;\s*$') { throw 'formato invalido' }
      $bytes = [Convert]::FromBase64String($Matches[1])
      $hh = ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLower()
      if ($hh -ne $h) { throw 'arquivo corrompido' }
      $dest = Join-Path $raiz ($rel -replace '/', '\')
      $dir = Split-Path -Parent $dest
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      [IO.File]::WriteAllBytes($dest + '.novo', $bytes)
      Move-Item -Force ($dest + '.novo') $dest
      $mapa[$rel] = $h
      Write-Host ('  [' + $n + '/' + $pend.Count + '] ' + $rel)
    } catch { $falhou++; Write-Host ('  FALHOU: ' + $rel + ' (' + $_.Exception.Message + ')') }
  }
  foreach ($rel in @($p.remover)) { if ($rel -and $rel -match '^[\w\-./ ()]+$' -and -not $rel.Contains('..')) { Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $raiz ($rel -replace '/', '\')); $mapa.Remove($rel) } }

  # --- gravar instalado.js (se algo falhou, mantem a versao antiga para tentar de novo) ---
  $verFinal = if ($falhou -eq 0) { [string]$p.versao } else { [string]$inst.versao }
  $obj = [ordered]@{ versao = $verFinal; arquivos = $mapa }
  $json = $obj | ConvertTo-Json -Compress -Depth 4
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'instalado.js'), ('window.YAURI_INST=' + $json + ';'), (New-Object Text.UTF8Encoding $false))
  if ($falhou -eq 0) { Write-Host ('  Atualizado para a versao ' + $p.versao + '!') } else { Write-Host '  Atualizacao incompleta; tento de novo na proxima vez.' }
} catch {
  Write-Host ('  (nao consegui atualizar agora: ' + $_.Exception.Message + ')')
}
