@echo off
setlocal
title YauriGames
rem === Endereco das atualizacoes (GitHub Pages). Para trocar, edite a linha abaixo. ===
set "YG_URL=https://lilparafuso.github.io/yaurigames-update"
if exist "%~dp0index.html" (
  for %%I in ("%~dp0.") do set "YG_RAIZ=%%~fI"
) else (
  set "YG_RAIZ=%~dp0YauriGames"
)
set "YG_BASE=%~dp0YauriGames_base.zip"
set "YG_ESTE=%~f0"
echo.
echo   YauriGames - instalando/atualizando... (pode demorar na 1a vez)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:YG_ESTE,[Text.Encoding]::UTF8); $i=$s.LastIndexOf('#PS#'+'START'); Invoke-Expression $s.Substring($i)"
if exist "%YG_RAIZ%\index.html" goto abrir
echo.
echo   Nao consegui instalar o YauriGames agora.
echo   Conecte na internet ou coloque o YauriGames_base.zip ao lado deste arquivo.
echo.
pause
exit /b 1
:abrir
start "" "%YG_RAIZ%\index.html"
exit /b 0
#PS#START
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$raiz = $env:YG_RAIZ
$url = $env:YG_URL
$base = $env:YG_BASE
$dados = Join-Path $raiz 'dados'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

function B64U([string]$s) {
  $s = $s.Replace('-', '+').Replace('_', '/')
  switch ($s.Length % 4) { 2 { $s += '==' } 3 { $s += '=' } }
  return [Convert]::FromBase64String($s)
}

function Test-Assinatura($m) {
  $x = B64U '1MtYvTqOocGACdgSE_k0hg1pSoP4kdjFQMr5oq7zdts'
  $y = B64U 'xlZSDqC0AihmdeqRqWOpDEi3zU2YCwOvMKZuttGIPkE'
  $blob = [byte[]]@(0x45,0x43,0x53,0x31,0x20,0,0,0) + $x + $y
  $key = [System.Security.Cryptography.CngKey]::Import($blob, [System.Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
  $ec = New-Object System.Security.Cryptography.ECDsaCng($key)
  $ec.HashAlgorithm = [System.Security.Cryptography.CngAlgorithm]::Sha256
  return $ec.VerifyData([Text.Encoding]::UTF8.GetBytes([string]$m.payload), [Convert]::FromBase64String([string]$m.sig))
}

function Get-Manifesto([string]$u) {
  $r = Invoke-WebRequest -Uri ($u + '/versao.js?t=' + [DateTime]::UtcNow.Ticks) -UseBasicParsing -TimeoutSec 8
  $txt = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
  $m = ($txt -replace '^\s*window\.YAURI_MANIFESTO\s*=\s*', '' -replace ';\s*$', '') | ConvertFrom-Json
  if (-not (Test-Assinatura $m)) { throw 'ASSINATURA INVALIDA' }
  return ($m.payload | ConvertFrom-Json)
}

function Instalar-Zip([string]$zip) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $tmp = Join-Path $env:TEMP ('yg_' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp -Force | Out-Null
  [IO.Compression.ZipFile]::ExtractToDirectory($zip, $tmp)
  $src = Join-Path $tmp 'YauriGames'
  if (-not (Test-Path (Join-Path $src 'index.html'))) { throw 'zip invalido' }
  New-Item -ItemType Directory -Path $raiz -Force | Out-Null
  Copy-Item -Path (Join-Path $src '*') -Destination $raiz -Recurse -Force
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
}

function Atualizar-Delta([string]$u) {
  $instTxt = Get-Content (Join-Path $dados 'instalado.js') -Raw -Encoding UTF8
  $inst = ($instTxt -replace '^\s*window\.YAURI_INST\s*=\s*', '' -replace ';\s*$', '') | ConvertFrom-Json
  $mapa = @{}
  foreach ($pr in $inst.arquivos.PSObject.Properties) { $mapa[$pr.Name] = [string]$pr.Value }
  $p = Get-Manifesto $u
  if ([version]$p.versao -le [version]$inst.versao) { Write-Host ('  Ja esta na versao mais nova (' + $inst.versao + ').'); return }
  $pend = @()
  foreach ($pr in $p.arquivos.PSObject.Properties) {
    $rel = $pr.Name; $h = [string]$pr.Value.h
    if ($rel -notmatch '^[\w\-./ ()]+$' -or $rel.Contains('..') -or $rel.StartsWith('/') -or $rel -eq 'dados/progresso.js' -or $rel -eq 'dados/instalado.js' -or $rel -eq 'Iniciar.bat') { continue }
    if ($mapa[$rel] -ne $h) { $pend += , @($rel, $h) }
  }
  Write-Host ('  Nova versao ' + $p.versao + ' - ' + $pend.Count + ' arquivo(s)...')
  $falhou = 0; $n = 0
  $sha = [Security.Cryptography.SHA256]::Create()
  foreach ($it in $pend) {
    $rel = $it[0]; $h = $it[1]; $n++
    try {
      $rr = Invoke-WebRequest -Uri ($u + '/f/' + $h + '.js') -UseBasicParsing -TimeoutSec 60
      $js = [Text.Encoding]::UTF8.GetString($rr.RawContentStream.ToArray())
      if ($js -notmatch '=\s*"([A-Za-z0-9+/=]*)"\s*;\s*$') { throw 'formato invalido' }
      $bytes = [Convert]::FromBase64String($Matches[1])
      $hh = ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLower()
      if ($hh -ne $h) { throw 'arquivo corrompido' }
      $dest = Join-Path $raiz ($rel -replace '/', '\')
      $dir = Split-Path -Parent $dest
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      [IO.File]::WriteAllBytes($dest + '.novo', $bytes)
      Move-Item -Force ($dest + '.novo') $dest
      $mapa[$rel] = $h
      Write-Host ('  [' + $n + '/' + $pend.Count + '] ' + $rel)
    } catch { $falhou++; Write-Host ('  FALHOU: ' + $rel + ' (' + $_.Exception.Message + ')') }
  }
  foreach ($rel in @($p.remover)) {
    if ($rel -and $rel -match '^[\w\-./ ()]+$' -and -not $rel.Contains('..')) { Remove-Item -Force -ErrorAction SilentlyContinue (Join-Path $raiz ($rel -replace '/', '\')); $mapa.Remove($rel) }
  }
  $verFinal = if ($falhou -eq 0) { [string]$p.versao } else { [string]$inst.versao }
  $obj = [ordered]@{ versao = $verFinal; arquivos = $mapa }
  $json = $obj | ConvertTo-Json -Compress -Depth 4
  [IO.File]::WriteAllText((Join-Path $dados 'instalado.js'), ('window.YAURI_INST=' + $json + ';'), (New-Object Text.UTF8Encoding $false))
  if ($falhou -eq 0) { Write-Host ('  Atualizado para a versao ' + $p.versao + '!') } else { Write-Host '  Atualizacao incompleta; tento de novo na proxima vez.' }
}

try {
  # endereco: dados\atualizacao.txt (se existir e tiver conteudo) manda sobre o endereco do .bat
  $f = Join-Path $dados 'atualizacao.txt'
  if (Test-Path $f) { $o = ((Get-Content $f -Raw -Encoding UTF8) -replace '[\r\n]', '').Trim(); if ($o) { $url = $o } }
  if ($url) { $url = $url.TrimEnd('/') }
  if ($url -like '*SEU_USUARIO*') { $url = '' }

  $jaTem = Test-Path (Join-Path $raiz 'index.html')
  $rodaDelta = $true
  if (-not $jaTem) {
    $feito = $false
    if ($url) {
      try {
        Write-Host '  Instalando o YauriGames (baixando)...'
        $p = Get-Manifesto $url
        $tmpzip = Join-Path $env:TEMP ('yg_' + [Guid]::NewGuid().ToString('N') + '.zip')
        Invoke-WebRequest -Uri ($url + '/' + $p.zip) -OutFile $tmpzip -UseBasicParsing -TimeoutSec 600
        if ((Get-FileHash $tmpzip -Algorithm SHA256).Hash.ToLower() -ne [string]$p.zipHash) { throw 'zip corrompido' }
        Instalar-Zip $tmpzip
        Remove-Item -Force $tmpzip -ErrorAction SilentlyContinue
        $feito = $true; $rodaDelta = $false
        Write-Host ('  Instalado! Versao ' + $p.versao)
      } catch { Write-Host ('  Nao deu pela internet: ' + $_.Exception.Message) }
    }
    if (-not $feito -and $base -and (Test-Path $base)) {
      Write-Host '  Instalando a partir do YauriGames_base.zip...'
      Instalar-Zip $base
      $feito = $true
    }
    if (-not $feito) { Write-Host '  Sem internet e sem YauriGames_base.zip ao lado deste arquivo.'; return }
  }
  if ($rodaDelta -and $url) { Atualizar-Delta $url }
} catch {
  Write-Host ('  (nao consegui atualizar agora: ' + $_.Exception.Message + ')')
}
