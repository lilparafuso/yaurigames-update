/* ============================================================
   revisao.js — revisão da partida: gráfico de avaliação, precisão,
   contagem de lances e navegação lance a lance com comentários do treinador.
   ============================================================ */

(function () {
  const { Chess } = window.ChessLib;
  const App = window.App;
  const $ = App.$;
  const Coach = window.Coach;

  let tab = null;
  let R = null;       // revisão aberta
  const ORDEM = ['brilhante', 'otimo', 'melhor', 'teoria', 'bom', 'imprecisao', 'erro', 'capivarada'];

  function iniciarUI() {
    tab = new window.Tabuleiro($('r-tabuleiro'), { lancesDe: () => [], podeSelecionar: () => false, aoMover: () => {} });
    $('r-ini').onclick = () => irPara(0);
    $('r-ant').onclick = () => irPara(R.ply - 1);
    $('r-prox').onclick = () => irPara(R.ply + 1);
    $('r-fim').onclick = () => irPara(R.n);
    $('r-virar').onclick = () => { tab.virar(); jogadores(); avalBarra(); };
    $('r-sair').onclick = () => mostrarLista();
    $('r-grafico').onclick = (e) => {
      if (!R) return;
      const rc = e.target.getBoundingClientRect();
      irPara(Math.round((e.clientX - rc.left) / rc.width * R.n));
    };
    window.addEventListener('keydown', (e) => {
      if (App.telaAtual !== 'revisao' || !R || $('rev-detalhe').style.display === 'none') return;
      if (e.key === 'ArrowLeft') { irPara(R.ply - 1); e.preventDefault(); }
      else if (e.key === 'ArrowRight') { irPara(R.ply + 1); e.preventDefault(); }
      else if (e.key === 'Home') irPara(0);
      else if (e.key === 'End') irPara(R.n);
    });
  }

  /* ---------- Lista de partidas salvas ---------- */
  function mostrarLista() {
    R = null;
    $('rev-detalhe').style.display = 'none';
    $('rev-lista').style.display = '';
    const hist = App.ler('historico', []);
    const box = $('hist');
    if (!hist.length) { box.innerHTML = '<p>Nenhuma partida terminada ainda. Jogue uma partida e ela aparece aqui!</p>'; return; }
    box.innerHTML = '';
    hist.forEach((h) => {
      const bot = window.BOTS.find(b => b.id === h.botId);
      const nomeAdv = bot ? `${bot.avatar} ${bot.nome}` : '👥 Dois jogadores';
      let res = 'Empate';
      if (h.resultado.vencedor) res = h.modo === 'local' ? (h.resultado.vencedor === 'w' ? 'Brancas venceram' : 'Pretas venceram') : (h.resultado.vencedor === h.corUsuario ? 'Você venceu' : 'Você perdeu');
      const d = new Date(h.data);
      const el = document.createElement('div'); el.className = 'item';
      el.innerHTML = `<div class="t"><b>Você vs ${nomeAdv}</b> — ${res}<small>${h.resultado.motivo} · ${Math.ceil(h.jogadas.length / 2)} lances · ${d.toLocaleDateString('pt-BR')} ${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</small></div>`;
      const b1 = document.createElement('button'); b1.className = 'btn verde pequeno'; b1.textContent = '📊 Revisar'; b1.onclick = () => abrir(h);
      const b2 = document.createElement('button'); b2.className = 'btn pequeno'; b2.textContent = '🗑'; b2.title = 'Excluir';
      b2.onclick = () => { App.salvar('historico', App.ler('historico', []).filter(x => x.id !== h.id)); mostrarLista(); };
      el.append(b1, b2); box.appendChild(el);
    });
  }

  function abrirDaPartida(J) {
    abrir({
      id: J.id, data: Date.now(), modo: J.cfg.modo, botId: J.cfg.bot ? J.cfg.bot.id : null,
      corUsuario: J.cfg.corUsuario, resultado: J.fim,
      jogadas: J.jogadas.map(j => ({ uci: j.uci, san: j.san, nota: j.nota, comentario: j.comentario })),
    });
  }

  /* ---------- Abrir uma revisão ---------- */
  async function abrir(entry) {
    App.mostrarTela('revisao');
    $('rev-lista').style.display = 'none';
    $('rev-detalhe').style.display = '';
    const { fens, movs } = App.reconstruir(entry.jogadas.map(j => j.uci));
    const n = movs.length;
    R = { entry, fens, movs, n, ply: 0, evals: [], notas: [], coment: [] };
    tab.definirOrientacao(entry.modo === 'local' ? 'w' : entry.corUsuario);
    tab.limparSetas(); tab.limparSelo();
    tab.atualizar({ tab: new Chess(fens[0]).board(), ultimo: null, animar: false });
    jogadores();
    $('r-comentario').textContent = 'Analisando a partida…';
    const meu = R;

    // 1) garante que todas as posições foram analisadas pelo motor
    const res = [];
    for (let k = 0; k <= n; k++) {
      res[k] = await App.analisador.avaliar(fens[k]);
      if (R !== meu) return;
      if (k % 3 === 0) $('r-comentario').textContent = `Analisando a partida… ${k}/${n}`;
    }
    R.evals = res.map((r, k) => Coach.pontuacaoBrancas(r.linhas[0], fens[k]));

    // 2) classifica os lances que ainda não têm nota
    let mudou = false;
    for (let i = 0; i < n; i++) {
      const j = entry.jogadas[i];
      if (!j.nota || j.nota.acc == null) {
        const sans = entry.jogadas.slice(0, i + 1).map(x => x.san);
        const ab = window.acharAbertura(sans);
        const nota = Coach.classificar({ c0: new Chess(fens[i]), mov: movs[i], antes: res[i], depois: res[i + 1], livro: ab.emLivro && i < 16 });
        j.nota = { classe: nota.classe, perda: nota.perda, wBest: nota.wBest, wAfter: nota.wAfter, acc: nota.acc, uciMelhor: nota.uciMelhor };
        j.comentario = Coach.comentarLance({ fenAntes: fens[i], mov: movs[i], antes: res[i], depois: res[i + 1], nota, abertura: ab.nome });
        mudou = true;
      }
    }
    if (mudou) {
      const hist = App.ler('historico', []);
      const pos = hist.findIndex(h => h.id === entry.id);
      if (pos >= 0) { hist[pos] = entry; App.salvar('historico', hist); }
    }
    desenharResumo();
    renderLances();
    desenharGrafico();
    irPara(0);
  }

  /* ---------- Resumo (precisão, contagens, momentos críticos) ---------- */
  function nomeLado(cor) {
    const e = R.entry;
    if (e.modo === 'local') return cor === 'w' ? 'Brancas' : 'Pretas';
    if (cor === e.corUsuario) return 'Você';
    const b = window.BOTS.find(x => x.id === e.botId);
    return b ? b.nome : 'Adversário';
  }
  function desenharResumo() {
    const e = R.entry;
    const acc = { w: [], b: [] };
    const cont = { w: {}, b: {} };
    e.jogadas.forEach((j, i) => {
      const cor = i % 2 === 0 ? 'w' : 'b';
      acc[cor].push(j.nota.acc);
      cont[cor][j.nota.classe] = (cont[cor][j.nota.classe] || 0) + 1;
    });
    const media = (a) => a.length ? (a.reduce((x, y) => x + y, 0) / a.length).toFixed(1) : '–';
    $('r-prec').innerHTML = ['w', 'b'].map(c => `<div><small>${nomeLado(c)}${e.modo === 'local' ? '' : (c === 'w' ? ' (brancas)' : ' (pretas)')}</small><b>${media(acc[c])}%</b><small>precisão</small></div>`).join('');
    let t = '<tr><td></td><td>' + nomeLado('w') + '</td><td>' + nomeLado('b') + '</td></tr>';
    for (const k of ORDEM) {
      const cl = Coach.CLASSES[k];
      t += `<tr><td><span style="color:${cl.cor};font-weight:900">${cl.simbolo}</span> ${cl.nome}</td><td>${cont.w[k] || 0}</td><td>${cont.b[k] || 0}</td></tr>`;
    }
    $('r-classes').innerHTML = t;
    // momentos críticos: maiores quedas
    const piores = e.jogadas.map((j, i) => ({ i, perda: j.nota.perda, j })).filter(x => x.perda >= 10).sort((a, b) => b.perda - a.perda).slice(0, 4);
    $('r-momentos').innerHTML = piores.length
      ? '<b>Momentos críticos</b>' + piores.map(p => {
        const cl = Coach.CLASSES[p.j.nota.classe];
        return `<div class="msg" style="border-left-color:${cl.cor};cursor:pointer" data-ply="${p.i + 1}">Lance ${Math.floor(p.i / 2) + 1}${p.i % 2 ? '…' : '.'} <b>${p.j.san}</b> (${nomeLado(p.i % 2 ? 'b' : 'w')}) — ${cl.nome}, perdeu ${Math.round(p.perda)}% de chance</div>`;
      }).join('')
      : '<b>Momentos críticos</b><div class="msg info">Nenhum erro grave nesta partida. 👏</div>';
    $('r-momentos').querySelectorAll('[data-ply]').forEach(el => el.onclick = () => irPara(+el.dataset.ply));
  }

  function renderLances() {
    const e = R.entry;
    let html = '';
    for (let i = 0; i < e.jogadas.length; i += 2) {
      const cel = (k) => {
        const j = e.jogadas[k]; if (!j) return '<div class="lance"></div>';
        const cl = Coach.CLASSES[j.nota.classe];
        return `<div class="lance clicavel" data-ply="${k + 1}"><span class="bola" style="background:${cl.cor}"></span>${j.san}</div>`;
      };
      html += `<div class="linha"><div class="num">${i / 2 + 1}.</div>${cel(i)}${cel(i + 1)}</div>`;
    }
    $('r-lances').innerHTML = html;
    $('r-lances').querySelectorAll('[data-ply]').forEach(el => el.onclick = () => irPara(+el.dataset.ply));
  }

  function desenharGrafico() {
    const cv = $('r-grafico'), g = cv.getContext('2d');
    const W = cv.width, H = cv.height;
    g.clearRect(0, 0, W, H);
    g.fillStyle = '#403d39'; g.fillRect(0, 0, W, H);
    const n = R.n || 1;
    const x = (k) => (k / n) * W;
    const y = (k) => H * (1 - Coach.winPct(R.evals[k]) / 100);
    g.beginPath(); g.moveTo(0, H);
    for (let k = 0; k <= R.n; k++) g.lineTo(x(k), y(k));
    g.lineTo(W, H); g.closePath(); g.fillStyle = '#e8e8e8'; g.fill();
    g.strokeStyle = '#ffffff55'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, H / 2); g.lineTo(W, H / 2); g.stroke();
    // marcadores de erros
    R.entry.jogadas.forEach((j, i) => {
      if (['erro', 'capivarada'].includes(j.nota.classe)) {
        g.fillStyle = Coach.CLASSES[j.nota.classe].cor;
        g.beginPath(); g.arc(x(i + 1), y(i + 1), 5, 0, 7); g.fill();
      }
    });
    // posição atual
    g.strokeStyle = '#81b64c'; g.lineWidth = 3; g.beginPath(); g.moveTo(x(R.ply), 0); g.lineTo(x(R.ply), H); g.stroke();
  }

  function jogadores() {
    const e = R.entry;
    const topoCor = tab.orientacao === 'w' ? 'b' : 'w';
    const mk = (el, cor) => {
      const bot = window.BOTS.find(b => b.id === e.botId);
      let av = cor === 'w' ? '⬜' : '⬛';
      if (e.modo !== 'local') av = cor === e.corUsuario ? '🙂' : (bot ? bot.avatar : '🤖');
      el.innerHTML = `<div class="av">${av}</div><div class="info"><div class="nome">${nomeLado(cor)}</div></div>`;
    };
    mk($('r-jog-topo'), topoCor); mk($('r-jog-baixo'), topoCor === 'w' ? 'b' : 'w');
  }

  function avalBarra() {
    const col = $('r-aval');
    if (!R || !R.evals.length) { col.classList.add('vazia'); return; }
    const p = R.evals[R.ply];
    col.classList.remove('vazia');
    col.classList.toggle('invertida', tab.orientacao === 'b');
    col.querySelector('.branco').style.height = Coach.winPct(p) + '%';
    const alto = $('r-aval-alto'), baixo = $('r-aval-baixo');
    alto.textContent = ''; baixo.textContent = '';
    const txt = Coach.textoAval(p).replace('-', '');
    ((p >= 0) === (tab.orientacao === 'w') ? baixo : alto).textContent = txt;
  }

  /* ---------- Ir para um lance ---------- */
  function irPara(ply, opc) {
    if (!R || !R.evals.length) return;
    ply = Math.max(0, Math.min(R.n, ply));
    R.ply = ply;
    const c = new Chess(R.fens[ply]);
    const m = ply > 0 ? R.movs[ply - 1] : null;
    let rei = null;
    if (c.inCheck()) for (const l of c.board()) for (const p of l) if (p && p.type === 'k' && p.color === c.turn()) rei = p.square;
    tab.atualizar({ tab: c.board(), ultimo: m ? { from: m.from, to: m.to } : null, casaXeque: rei, animar: true });
    tab.limparSetas(); tab.limparSelo();
    const com = $('r-comentario');
    if (m) {
      const j = R.entry.jogadas[ply - 1];
      const cl = Coach.CLASSES[j.nota.classe];
      tab.mostrarSelo(m.to, cl.simbolo, cl.cor);
      com.style.borderLeftColor = cl.cor;
      com.innerHTML = `<span class="tag" style="background:${cl.cor}">${cl.simbolo} ${cl.nome}</span>${j.comentario}`;
      if (['imprecisao', 'erro', 'capivarada'].includes(j.nota.classe) && j.nota.uciMelhor) {
        const b = document.createElement('button');
        b.className = 'btn pequeno acao'; b.textContent = '👁 Ver o melhor lance';
        b.onclick = () => { irPara(ply - 1); const u = j.nota.uciMelhor; tab.desenharSetas([{ de: u.slice(0, 2), para: u.slice(2, 4) }]); };
        com.appendChild(b);
      }
    } else {
      com.style.borderLeftColor = '';
      com.textContent = ply === 0 ? 'Posição inicial. Use ▶ ou as setas do teclado para avançar.' : '';
    }
    $('r-lances').querySelectorAll('.lance').forEach(el => el.classList.toggle('atual', +el.dataset.ply === ply));
    const atual = $('r-lances').querySelector('.atual'); if (atual) atual.scrollIntoView({ block: 'nearest' });
    avalBarra();
    desenharGrafico();
    window.Som[m ? (m.captured ? 'capturar' : 'mover') : 'mover']();
  }

  window.Revisao = { iniciarUI, mostrarLista, abrirDaPartida };
})();
