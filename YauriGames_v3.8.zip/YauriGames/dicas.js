/* Banco de palavras com dicas para as Palavras Cruzadas (PALAVRA:dica). Sem acentos nas respostas. */
window.DICAS=`
CACHORRO:Melhor amigo do homem
GATO:Felino doméstico que mia
LEAO:Rei da selva
TIGRE:Grande felino listrado
ELEFANTE:Maior animal terrestre
GIRAFA:Animal de pescoço muito longo
MACACO:Primata que gosta de banana
ZEBRA:Cavalo listrado africano
COBRA:Réptil sem patas
JACARE:Réptil do Pantanal
ONCA:Felino pintado brasileiro
TUCANO:Ave de bico grande e colorido
ARARA:Ave colorida que imita voz
PAPAGAIO:Ave que repete o que ouve
CORUJA:Ave noturna símbolo da sabedoria
AGUIA:Ave de rapina de visão aguda
PINGUIM:Ave que não voa e vive no gelo
GALINHA:Ave que bota ovos
PATO:Ave que nada e faz quá
CAVALO:Animal montado por cavaleiros
VACA:Fornece leite
PORCO:Animal da fazenda que faz oinc
OVELHA:Dá lã
BORBOLETA:Inseto de asas coloridas
ABELHA:Inseto que faz mel
FORMIGA:Inseto trabalhador de colônia
ARANHA:Tece teias
BALEIA:Maior mamífero do mundo
GOLFINHO:Mamífero marinho muito inteligente
TUBARAO:Peixe predador de nadadeira dorsal
POLVO:Molusco de oito braços
TARTARUGA:Réptil de casco
SAPO:Anfíbio que coaxa
COELHO:Animal de orelhas longas
RATO:Roedor pequeno
LOBO:Canídeo que uivava para a lua
URSO:Mamífero grande que hiberna
CAMELO:Animal do deserto com corcovas
CANGURU:Marsupial australiano que pula
PANDA:Urso chinês preto e branco
MACA:Fruta de Branca de Neve
BANANA:Fruta amarela dos macacos
LARANJA:Fruta cítrica com suco
UVA:Fruta do vinho
MORANGO:Fruta vermelha com sementes por fora
ABACAXI:Fruta com coroa de folhas
MELANCIA:Fruta grande, verde por fora e vermelha por dentro
MANGA:Fruta tropical alaranjada
LIMAO:Fruta cítrica azeda
MAMAO:Fruta alaranjada boa para a digestão
GOIABA:Fruta de doce típico brasileiro
CAJU:Fruta cuja castanha é a semente
ACEROLA:Fruta rica em vitamina C
COCO:Fruta de água doce e casca dura
TOMATE:Base do molho de macarrão
CENOURA:Raiz alaranjada
BATATA:Tubérculo das fritas
ALFACE:Folha verde da salada
CEBOLA:Faz chorar ao cortar
ALHO:Tempero de dentes
FEIJAO:Par do arroz no prato brasileiro
ARROZ:Grão branco do dia a dia
MACARRAO:Massa italiana
PIZZA:Disco de massa com queijo e molho
QUEIJO:Derivado do leite
PAO:Alimento feito de farinha
LEITE:Bebida branca da vaca
CAFE:Bebida escura e energizante
CHOCOLATE:Doce feito de cacau
BOLO:Sobremesa de aniversário
SORVETE:Doce gelado
BRIGADEIRO:Docinho de festa de chocolate
FAROFA:Acompanhamento de farinha de mandioca
FEIJOADA:Prato de feijão preto com carnes
COXINHA:Salgado em forma de gota
PASTEL:Salgado frito de feira
TAPIOCA:Beiju de goma de mandioca
ACARAJE:Bolinho baiano de feijão fradinho
MANDIOCA:Raiz também chamada aipim
MEL:Produzido pelas abelhas
SAL:Tempero básico branco
ACUCAR:Adoça o café
OVO:Vem da galinha
CABECA:Parte do corpo onde fica o cérebro
CORACAO:Órgão que bombeia sangue
PULMAO:Órgão da respiração
CEREBRO:Órgão do pensamento
ESTOMAGO:Órgão da digestão
FIGADO:Grande órgão que filtra o sangue
RIM:Órgão que filtra a urina
OSSO:Parte do esqueleto
MUSCULO:Tecido que permite o movimento
PELE:Maior órgão do corpo
DENTE:Mastiga o alimento
LINGUA:Sente o sabor
OLHO:Órgão da visão
OUVIDO:Órgão da audição
NARIZ:Órgão do olfato
BOCA:Por onde se come
MAO:Termina o braço
PE:Termina a perna
JOELHO:Articulação da perna
COTOVELO:Articulação do braço
CABELO:Cresce na cabeça
SANGUE:Líquido vermelho das veias
CASA:Moradia
JANELA:Abertura da parede com vidro
PORTA:Entrada de um cômodo
TELHADO:Cobertura da casa
COZINHA:Cômodo onde se prepara a comida
QUARTO:Cômodo onde se dorme
BANHEIRO:Cômodo do chuveiro
SALA:Cômodo de receber visitas
CAMA:Móvel para dormir
MESA:Móvel onde se come
CADEIRA:Móvel para sentar
SOFA:Assento estofado da sala
ARMARIO:Móvel de guardar roupa
GELADEIRA:Eletrodoméstico que conserva alimentos frios
FOGAO:Onde se cozinha
CHUVEIRO:Joga água para o banho
ESPELHO:Mostra seu reflexo
RELOGIO:Marca as horas
LAMPADA:Ilumina o ambiente
VASSOURA:Usada para varrer
TRAVESSEIRO:Apoio da cabeça na cama
COBERTOR:Aquece na cama
CHAVE:Abre a fechadura
GARFO:Talher de dentes
FACA:Talher que corta
COLHER:Talher da sopa
PRATO:Onde se serve a comida
COPO:Recipiente para beber
PANELA:Utensílio de cozinhar
SOL:Estrela que ilumina a Terra
LUA:Satélite natural da Terra
ESTRELA:Pontos brilhantes no céu à noite
PLANETA:Corpo celeste que orbita uma estrela
TERRA:Planeta onde vivemos
MARTE:Planeta vermelho
JUPITER:Maior planeta do Sistema Solar
SATURNO:Planeta dos anéis
VENUS:Planeta mais quente do Sistema Solar
GALAXIA:Conjunto de bilhões de estrelas
COMETA:Corpo de gelo com cauda brilhante
CHUVA:Água que cai das nuvens
NUVEM:Acumulado de vapor no céu
VENTO:Ar em movimento
TROVAO:Barulho após o raio
RAIO:Descarga elétrica na tempestade
ARCOIRIS:Aparece depois da chuva com o sol
NEVE:Água congelada que cai
FURACAO:Tempestade circular violenta
MAR:Grande extensão de água salgada
RIO:Curso natural de água doce
LAGO:Grande poça natural de água cercada de terra
ILHA:Terra cercada de água
MONTANHA:Grande elevação de terra
VULCAO:Montanha que expele lava
DESERTO:Região seca com pouca chuva
FLORESTA:Grande área de árvores
PRAIA:Faixa de areia à beira-mar
CACHOEIRA:Queda d'água
ARVORE:Planta de tronco e galhos
FLOR:Parte colorida da planta
FOLHA:Parte verde da árvore
RAIZ:Parte da planta que fica debaixo da terra
SEMENTE:De onde nasce uma planta
GRAMA:Vegetação rasteira verde
CACTO:Planta do deserto com espinhos
BRASIL:País do Carnaval e do futebol
ARGENTINA:País vizinho do tango
PORTUGAL:País que colonizou o Brasil
FRANCA:País da Torre Eiffel
ITALIA:País em forma de bota
JAPAO:País do sol nascente
CHINA:País mais populoso da Ásia
EGITO:País das pirâmides
INGLATERRA:País do Big Ben
ALEMANHA:País de Berlim
CANADA:País da folha de bordo
MEXICO:País do tacos e dos astecas
AMAZONAS:Maior estado do Brasil
PARANA:Estado da capital Curitiba
BAHIA:Estado de Salvador
MINAS:Estado do pão de queijo
RECIFE:Capital de Pernambuco
BRASILIA:Capital do Brasil
CURITIBA:Capital do Paraná
SALVADOR:Primeira capital do Brasil
MANAUS:Capital do Amazonas
CATANDUVA:Cidade do IFSP deste jogo
PANTANAL:Maior planície alagável do mundo
CERRADO:Bioma do Centro-Oeste
CAATINGA:Bioma do sertão nordestino
AMAZONIA:Maior floresta tropical do mundo
EUROPA:Continente de Paris e Roma
AFRICA:Continente do Saara
ASIA:Maior continente
OCEANIA:Continente da Austrália
AMERICA:Continente do Brasil
ANTARTICA:Continente gelado do Polo Sul
EQUADOR:Linha que divide o globo em hemisférios norte e sul
FUTEBOL:Esporte do gol
BASQUETE:Esporte da cesta
VOLEI:Esporte jogado com rede e bola, sem tocar o chão
TENIS:Esporte com raquete e quadra
NATACAO:Esporte aquático
JUDO:Arte marcial japonesa
BOXE:Esporte de luvas
CORRIDA:Competição de velocidade
MARATONA:Prova de 42 quilômetros
GOLEIRO:Defende o gol
GOL:Objetivo no futebol
ARBITRO:Apita a partida
CAMPEAO:Quem vence a competição
MEDALHA:Prêmio do atleta
TROFEU:Taça de campeão
PENALTI:Cobrança de falta máxima
XADREZ:Jogo de reis, damas e peões
DAMAS:Jogo de peças redondas no tabuleiro
BICICLETA:Veículo de duas rodas e pedais
CARRO:Veículo de quatro rodas
ONIBUS:Transporte coletivo urbano
TREM:Veículo sobre trilhos
AVIAO:Veículo que voa
BARCO:Veículo aquático
NAVIO:Grande embarcação
MOTO:Veículo de duas rodas a motor
CAMINHAO:Veículo de carga pesada
HELICOPTERO:Aeronave de hélice no teto
FOGUETE:Veículo espacial
SEMAFORO:Controla o trânsito com três cores
RODOVIA:Estrada de alta velocidade
PONTE:Liga duas margens
AEROPORTO:Onde os aviões pousam
ESCOLA:Lugar de estudar
PROFESSOR:Quem ensina
ALUNO:Quem aprende
CADERNO:Onde se escreve na aula
LAPIS:Escreve e pode ser apagado
CANETA:Escreve com tinta
BORRACHA:Apaga o lápis
MOCHILA:Carrega o material escolar
LIVRO:Reúne páginas de leitura
BIBLIOTECA:Lugar cheio de livros
PROVA:Avaliação escolar
NOTA:Resultado da avaliação
ENEM:Exame nacional do ensino médio
VESTIBULAR:Prova de entrada para a faculdade
FACULDADE:Ensino superior
MATEMATICA:Disciplina dos números
PORTUGUES:Disciplina da gramática
HISTORIA:Disciplina do passado
GEOGRAFIA:Disciplina dos mapas
FISICA:Estuda a energia e o movimento
QUIMICA:Estuda os elementos e reações
BIOLOGIA:Estuda os seres vivos
FILOSOFIA:Amor pela sabedoria
REDACAO:Texto dissertativo do ENEM
RECREIO:Intervalo da escola
MEDICO:Cuida da saúde
ENFERMEIRO:Auxilia o médico no hospital
PROFESSORA:Ela ensina na sala de aula
ADVOGADO:Defende clientes na Justiça
JUIZ:Decide as sentenças
POLICIAL:Protege a população
BOMBEIRO:Apaga incêndios
PEDREIRO:Constrói paredes
PADEIRO:Faz pão
COZINHEIRO:Prepara refeições
MOTORISTA:Dirige veículos
PILOTO:Comanda o avião
ENGENHEIRO:Projeta construções e máquinas
ARQUITETO:Desenha casas e prédios
DENTISTA:Cuida dos dentes
PROGRAMADOR:Escreve códigos de computador
ARTISTA:Cria obras de arte
CANTOR:Quem canta
JORNALISTA:Escreve notícias
ATOR:Interpreta personagens
FAZENDEIRO:Dono de fazenda
PESCADOR:Quem pesca
COMPUTADOR:Máquina de processar dados
TECLADO:Onde se digita
MOUSE:Aponta e clica na tela
TELA:Mostra imagens do computador
INTERNET:Rede mundial de computadores
CELULAR:Telefone portátil
SITE:Página na internet
EMAIL:Correio eletrônico
SENHA:Protege seu acesso
APLICATIVO:Programa de celular
ROBO:Máquina que imita ações humanas
PROGRAMA:Conjunto de instruções do computador
ARQUIVO:Documento guardado no computador
PENDRIVE:Memória portátil que se espeta no USB
BATERIA:Fonte de energia do celular
CABO:Liga aparelhos
MEMORIA:Guarda informações no computador
INDIO:Povo original do Brasil
CABRAL:Navegador que chegou ao Brasil em 1500
TIRADENTES:Mártir da Inconfidência Mineira
ABOLICAO:Fim da escravidão no Brasil
REPUBLICA:Forma de governo sem rei
IMPERIO:Governo de um imperador
DITADURA:Regime sem liberdade política
DEMOCRACIA:Governo do povo
CONSTITUICAO:Lei maior do país
VOTO:Escolha do eleitor
ELEICAO:Escolha de governantes pelo povo
PRESIDENTE:Chefe do Poder Executivo
SENADO:Câmara alta do Congresso
DEPUTADO:Representante na Câmara
PREFEITO:Chefe do município
GOVERNADOR:Chefe do estado
LEI:Norma criada pelo Poder Legislativo
JUSTICA:Poder que julga
CIDADANIA:Direitos e deveres do cidadão
IMPOSTO:Tributo cobrado pelo governo
BANDEIRA:Símbolo de um país
HINO:Canção símbolo de uma nação
DINHEIRO:Papel usado para comprar
MOEDA:Dinheiro de metal
BANCO:Guarda e empresta dinheiro
SALARIO:Pagamento mensal do trabalho
POUPANCA:Dinheiro guardado
PIX:Pagamento instantâneo brasileiro
MERCADO:Lugar de compras
LOJA:Estabelecimento comercial
FEIRA:Mercado de rua com frutas e verduras
PRECO:Valor de um produto
DESCONTO:Redução do preço
MUSICA:Arte dos sons
VIOLAO:Instrumento de seis cordas
PIANO:Instrumento de teclas pretas e brancas
BATERIA:Instrumento de baquetas
FLAUTA:Instrumento de sopro
VIOLINO:Instrumento de arco
GUITARRA:Instrumento elétrico de cordas
SAMBA:Ritmo brasileiro do Carnaval
FORRO:Ritmo nordestino de festa junina
FUNK:Ritmo das favelas cariocas
TRAP:Estilo musical de batidas graves e letras rimadas
ROCK:Estilo musical de guitarras
BANDA:Grupo musical
CARNAVAL:Festa de fantasias e samba
CINEMA:Sala de filmes
FILME:Obra de cinema
TEATRO:Arte de encenar peças
DANCA:Movimentos ao ritmo da música
PINTURA:Arte de usar tintas
ESCULTURA:Arte de modelar em pedra ou barro
POESIA:Texto em versos
ROMANCE:Livro de narrativa longa
FOTOGRAFIA:Imagem capturada por câmera
QUADRO:Pintura emoldurada
VERDE:Cor da grama
AZUL:Cor do céu
VERMELHO:Cor do sangue
AMARELO:Cor do sol
ROXO:Mistura de azul e vermelho
LARANJA:Cor da cenoura
PRETO:Cor da noite escura
BRANCO:Cor da neve
CINZA:Cor das nuvens de chuva
ROSA:Cor clara de vermelho
MARROM:Cor da terra
ALEGRIA:Sentimento de felicidade
TRISTEZA:Sentimento oposto à alegria
MEDO:Sentimento diante do perigo
RAIVA:Sentimento de fúria
AMOR:Sentimento de carinho profundo
AMIZADE:Relação entre amigos
SAUDADE:Palavra brasileira para a falta de alguém
CORAGEM:Força diante do medo
ESPERANCA:Confiança no futuro
SONHO:O que se vê ao dormir
PAZ:Ausência de guerra
FAMILIA:Pais, filhos e irmãos
MAE:Quem dá à luz
PAI:Genitor
IRMAO:Filho dos mesmos pais
AVO:Pai do seu pai
NETO:Filho do seu filho
TIO:Irmão do seu pai ou da sua mãe
PRIMO:Filho do seu tio
PADRINHO:Escolhido no batizado
AMIGO:Companheiro de confiança
SEGUNDA:Primeiro dia útil da semana
TERCA:Dia depois de segunda
SEXTA:Dia antes do fim de semana
SABADO:Dia de descanso para muitos
DOMINGO:Último dia da semana
JANEIRO:Primeiro mês do ano
FEVEREIRO:Mês mais curto
JUNHO:Mês das festas juninas
DEZEMBRO:Último mês do ano
NATAL:Festa de 25 de dezembro
PASCOA:Festa dos ovos de chocolate
ANIVERSARIO:Dia em que se faz anos
PRIMAVERA:Estação das flores
VERAO:Estação mais quente
OUTONO:Estação das folhas caindo
INVERNO:Estação mais fria
SECULO:Cem anos
ANO:Doze meses
HORA:Sessenta minutos
MINUTO:Sessenta segundos
SEGUNDO:Menor unidade de tempo do relógio
FUTURO:Tempo que ainda virá
PASSADO:Tempo que já foi
PRESENTE:O momento atual
FERRO:Metal enferrujável
OURO:Metal precioso amarelo
PRATA:Metal brilhante das joias claras
COBRE:Metal dos fios elétricos
AGUA:Líquido essencial para a vida
FOGO:Queima e produz calor
AR:O que respiramos
TERREMOTO:Tremor da crosta terrestre
ENERGIA:Capacidade de realizar trabalho
ELETRICIDADE:Corrente que acende lâmpadas
GRAVIDADE:Força que atrai os corpos para a Terra
ATOMO:Menor parte de um elemento químico
CELULA:Unidade básica dos seres vivos
VIRUS:Microrganismo que causa gripe
VACINA:Protege contra doenças
REMEDIO:Medicamento
OXIGENIO:Gás essencial à respiração
CARBONO:Elemento base da vida
HIDROGENIO:Elemento mais leve
FOTOSSINTESE:Processo em que as plantas produzem alimento
CHUVEIRO:Eletrodoméstico do banho
PIPOCA:Milho estourado do cinema
BOLA:Objeto redondo dos esportes
PIPA:Brinquedo que voa com linha
BONECA:Brinquedo de criança
BALAO:Bexiga de festa
PRESENTE:Algo que se dá de aniversário
FESTA:Reunião de comemoração
VIAGEM:Deslocamento para longe
MAPA:Representação de uma região
BUSSOLA:Aponta o norte
PASSAPORTE:Documento de viagem internacional
HOTEL:Hospedagem de viajantes
TURISTA:Quem viaja para conhecer lugares
`;
